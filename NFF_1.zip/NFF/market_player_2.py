import numpy as np
from order_book import OrderBook
from message_objects import *
from ssh_connector import get_remote_file
from sim_data import SimData
from util import get_tick_data_path

nanos_in_sec = 1e9
micros_in_sec = 1e6

class MarketPlayer2:
    
    def __init__(self, date, order_book_id):
        
        self.date = date
        self.order_book_id = order_book_id
        self.file_sink = f'{self.date}-{self.order_book_id}.jsonl'

        self.order_book = OrderBook()
        self.sim_data = SimData(date, order_book_id, self.order_book, 'Bist_Derivative')

        self.exec_delay_window = 200000

        with get_remote_file(get_tick_data_path(self.date, self.order_book_id, 'tick-derivative')) as f:
            lines = f.readlines()

        self.lines = [line.strip() for line in lines]
        self.idx = 0
        print('@End of MarketPlayer2.__init__', date, order_book_id)


    def play_until(self, until):

        line = self.lines[self.idx]

        while self.get_nanos_from_epoch_from_line(line) <= until:
        
            M = line.split(',')
            msg_type = M[0]
            
            if msg_type == 'A':
                obj = Add(M)
                self.on_add(obj)

            elif msg_type == 'D':
                obj = Delete(M)
                self.on_delete(obj)

            elif msg_type == 'E':
                obj = Execute(M)
                self.on_execute(obj)

            elif msg_type == 'T':
                obj = Seconds(M)
                self.on_seconds(obj)

            elif msg_type == 'P':
                obj = Trade(M)
                self.on_trade(obj)

            elif msg_type == 'O':
                obj = State(M)
                self.on_state(obj)
            
            else:
                pass

            self.idx += 1
            line = self.lines[self.idx]
            
    def get_nanos_from_epoch_from_line(self, line):

        if line.startswith('T'):
            time = line[2:] + '000000000'
        else:
            time = line[32:51]
        
        return int(time)


    def on_add(self, add):
        
        self.order_book.on_add(add)
        self.sim_data.update_data('add', add)

    def on_delete(self, delete):

        self.order_book.on_delete(delete)
        self.sim_data.update_data('delete', delete)

    def on_execute(self, execute: Execute):
        
        self.order_book.on_execute(execute)
        self.sim_data.update_data('execute', execute)

    def on_trade(self, trade: Trade):
        self.sim_data.update_data('trade', trade)

    def on_state(self, state: State):
        self.sim_data.update_data('state', state)

    def on_seconds(self, seconds):
        self.sim_data.update_data('seconds', seconds)

    def get_snapshot(self, nanos_from_epoch):
        return self.sim_data.get_snapshot(nanos_from_epoch)

if __name__ == '__main__':

    player = MarketPlayer2('20210129', 9778629)
    player.play_until(1605164403000000000)
