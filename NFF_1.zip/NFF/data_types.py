import numpy as np
import math


class ExponentialMovingSum:
    # init method or constructor
    def __init__(self, last_value, last_update_time, half_life):
        self.last_value = last_value      # initialize with a first value
        self.last_update_time = last_update_time
        self.half_life = half_life
    def update_value(self, value, update_time):
        #print(f"inside update value, update value {value}, update time {update_time}, last update time {self.last_update_time}, last update value {self.last_value}, time difference {(update_time - self.last_update_time)}")
        decay_applied = self.last_value * math.exp((np.log(0.5)/self.half_life)*(update_time - self.last_update_time))
        self.last_value = round(decay_applied + value, 6)
        self.last_update_time = update_time
    def get_last_value(self):
        return round(self.last_value,6)
    def reset(self, value, nanos_from_epoch):
        self.last_value = value
        self.last_update_time = nanos_from_epoch
    def get_last_value_decayed(self, update_time):
        decay_factor = math.exp((np.log(0.5)/self.half_life)*(update_time - self.last_update_time))
        return round(self.last_value * decay_factor,6)

class ExponentialMovingAverage:
    # init method or constructor
    def __init__(self, last_value, last_update_time, half_life):
        self.last_value = last_value      # initialize with a first value
        self.last_update_time = last_update_time
        self.half_life = half_life
    def update_value(self, value, update_time):
        decay_factor = math.exp((np.log(0.5)/self.half_life)*(update_time - self.last_update_time))
        decay_factor = decay_factor / (1 + decay_factor)
        decay_applied_value = self.last_value * decay_factor
        self.last_value = round(decay_applied_value + (1-decay_factor) * value, 6)
        self.last_update_time = update_time
    def reset(self, value, nanos_from_epoch):
        self.last_value = value
        self.last_update_time = nanos_from_epoch
    def get_last_value(self):
        return round(self.last_value,6)
    def get_last_value_decayed(self, update_time):
        decay_factor = math.exp((np.log(0.5)/self.half_life)*(update_time - self.last_update_time))
        return round(self.last_value * decay_factor,6)

class HiLow:
    # init method or constructor
    def __init__(self, hi, lo, freq):
        self.high = hi
        self.low = lo
        self.bucket_frequency = freq
    
    def copy(self):
        return HiLow(self.high,self.low,self.bucket_frequency)