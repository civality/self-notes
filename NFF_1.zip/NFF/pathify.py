import pandas as pd
from stat import S_ISDIR, S_ISREG
from ssh_connector import get_sftp_client


def get_path_table(kind='tick-equity', order_book_id=None, year=None, month=None, day=None, delay=None, half_day=False):
    """
    Returns a dataframe that contains file paths that caller selects
    date: 'yyyymmdd'
    kind: 'bist-equity' or 'bist-derivative'
    """

    path_source = f'path-table.csv'

    if kind == 'tick-equity' or kind == 'tick-derivative':
        df = pd.read_csv(path_source, usecols=['path', 'kind', 'date', 'order_book_id'])
    else:
        raise ValueError(f'Invalid kind {kind}')

    df = df[df['kind'] == kind]

    return df

def write_path_table():

    source_dir = '/mnt/data'
    source_dir_tick_bist_equity = f'{source_dir}/text_parsed/Bist_Equity'
    source_dir_tick_bist_derivative = f'{source_dir}/text_parsed/Bist_Derivative'
    source_dir_bucket_bist_equity = f'{source_dir}/bucket/Bist_Equity'
    source_dir_exec_snap_bist_equity = f'{source_dir}/exec_snap/Bist_Equity'

    #df_tick_bist_equity

    df1 = pd.DataFrame({'path': list(get_path_set(source_dir_tick_bist_equity))}).sort_values(by='path')
    df2 = pd.DataFrame({'path': list(get_path_set(source_dir_tick_bist_derivative))}).sort_values(by='path')
    df3 = pd.DataFrame({'path': list(get_path_set(source_dir_bucket_bist_equity))}).sort_values(by='path')
    df4 = pd.DataFrame({'path': list(get_path_set(source_dir_exec_snap_bist_equity))}).sort_values(by='path')

    df1 = df1[df1['path'].str.endswith('.txt')]
    df2 = df2[df2['path'].str.endswith('.txt')]
    df3 = df3[df3['path'].str.endswith('.csv')]
    df4 = df4[df4['path'].str.endswith('.csv.gz')]

    # other filters
    df2 = df2[~df2['path'].str.contains('.er-files')]


    df1['kind'] = 'tick-equity'
    df2['kind'] = 'tick-derivative'
    df3['kind'] = 'bucket'
    df4['kind'] = 'exec-snap'


    # df1 
    list_path_split = [path.split('.') for path in df1['path'].to_list()]
    list_date = [x[2] for x in list_path_split]
    list_order_book_id = [x[3] for x in list_path_split]
    df1['date'] = list_date
    df1['order_book_id'] = list_order_book_id


    # df2
    list_path_split = [path.split('.') for path in df2['path'].to_list()]
    list_date = [x[2] for x in list_path_split]
    list_order_book_id = [x[3] for x in list_path_split]
    df2['date'] = list_date
    df2['order_book_id'] = list_order_book_id

    # df3 
    list_path_split = [path.split('.') for path in df3['path'].to_list()]
    list_date = [x[1] for x in list_path_split]
    list_order_book_id = [x[2] for x in list_path_split]
    list_window = [x[3] for x in list_path_split]
    df3['date'] = list_date
    df3['order_book_id'] = list_order_book_id
    df3['window'] = list_window

    # df4 
    list_path_split = [path.split('.') for path in df4['path'].to_list()]
    list_date = [x[1] for x in list_path_split]
    list_order_book_id = [x[2] for x in list_path_split]
    list_window = [x[4] for x in list_path_split]
    df4['date'] = list_date
    df4['order_book_id'] = list_order_book_id
    df4['window'] = list_window

    pd.concat([df1,df2,df3,df4], ignore_index=True).to_csv('path-table.csv', index=False)


def get_path_set(source_dir: str):

    the_set = set()
    sftp_client = get_sftp_client()

    walkdir(sftp_client, source_dir, the_set)    

    return the_set


def walkdir(sftp, remotedir, the_set):
    """
    helper method for get_path_list. 
    used only by it
    """
    #N = 4
    #i = 0

    for entry in sftp.listdir_attr(remotedir):
        #i += 1 
        #if i > N:
        #    break 

        remotepath = remotedir + '/' + entry.filename
        mode = entry.st_mode

        if S_ISDIR(mode):
            walkdir(sftp, remotepath, the_set)
        elif S_ISREG(mode):
            #print(remotepath)
            if remotepath in the_set: 
                raise Exception(remotepath)
            
            the_set.add(remotepath)
    
    return the_set


if __name__ == '__main__':

    write_path_table()
