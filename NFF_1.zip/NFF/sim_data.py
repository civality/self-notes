from typing import Union
import numpy as np
from order_book import OrderBook
from util import get_formatted_date
from quantlib import utilities as ut
from data_types import ExponentialMovingAverage, ExponentialMovingSum, HiLow
from quantlib import database_functions as db
from message_objects import *

nanos_in_sec = 1e9
micros_in_sec = 1e6

class SimData:

    def __init__(self, date: str, order_book_id: int, order_book: OrderBook, kind: str):
        
        self.date = date
        self.order_book_id = order_book_id
        self.order_book = order_book
        self.kind = kind

        self.sensitivity = 0.03
        self.exec_delay_window = 200000
        
        self.init_data()
        
        print(f'End of SimData.__init__ {date} {order_book_id} {kind}')


    def init_data(self):

        self.state_name = 'P_GUNSONU'

        self.beginning_of_day = ut.get_beginning_nanos_epoch(self.date, '10:00:00') 
        self.end_of_day = ut.get_beginning_nanos_epoch(self.date, '18:00:00')

        self.first_second = True
        self.first_exec = True
        self.last_exec = False
        
        self.last_exec_side = None
        self.is_cont_trading = False
        
        self.beta = self.get_beta()
        yest_close = self.get_yest_close()

        self.closing_price = 0
        self.opening_price = yest_close

        self.mid = yest_close
        self.mid_adj = yest_close
        self.mid_prev = yest_close
        self.mid_adj_prev = yest_close

        self.spread = 0
        self.spread_l2 = 0
        self.spread_l3 = 0
        
        self.nanos_from_epoch = 0
        self.beginning_nanos_epoch = 0
        self.last_second_from_epoch = 0

        self.time_exec_prev = 0 # unused currently
        self.time_exec_cur = 0  # unused currently

        self.last_exec_snap = 0
        
        self.ewavg_px_10s = 0  
        self.ewavg_px_1m = 0  
        self.ewavg_px_3m = 0  
        self.ewavg_px_10m = 0
        self.ewavg_px_30m = 0
        self.ewavg_px_10s_adj = 0  
        self.ewavg_px_1m_adj = 0  
        self.ewavg_px_3m_adj  = 0  
        self.ewavg_px_10m_adj = 0
        self.ewavg_px_30m_adj = 0
        self.day_w_px = 0
        self.day_qty = 0
        self.day_qty_px  = 0
        self.day_buy_qty = 0
        self.day_sell_qty = 0
        self.day_w_px_adj = 0
        self.day_qty_px_adj = 0  
        self.day_buy_notional = 0 
        self.snap_exec_qty = 0
        self.buy_add_slope_last_update_time = 0
        self.day_sell_notional = 0 
        self.buy_l1_px_prev = 0
        self.buy_l2_px_prev = 0
        self.buy_l3_px_prev = 0
        self.buy_l4_px_prev = 0
        self.buy_l5_px_prev = 0
        self.buy_l6_px_prev = 0
        self.buy_l7_px_prev = 0
        self.buy_l8_px_prev = 0
        self.buy_l9_px_prev = 0
        self.buy_l10_px_prev = 0
        self.sell_l1_px_prev = 0
        self.sell_l2_px_prev = 0
        self.sell_l3_px_prev = 0
        self.sell_l4_px_prev = 0
        self.sell_l5_px_prev = 0
        self.sell_l6_px_prev = 0
        self.sell_l7_px_prev = 0
        self.sell_l8_px_prev = 0
        self.sell_l9_px_prev = 0
        self.sell_l10_px_prev = 0
        self.buy_l1_shr_prev = 0
        self.buy_l2_shr_prev = 0
        self.buy_l3_shr_prev = 0
        self.buy_l4_shr_prev = 0
        self.buy_l5_shr_prev = 0
        self.buy_l6_shr_prev = 0
        self.buy_l7_shr_prev = 0
        self.buy_l8_shr_prev = 0
        self.buy_l9_shr_prev = 0
        self.buy_l10_shr_prev = 0
        self.sell_l1_shr_prev = 0
        self.sell_l2_shr_prev = 0
        self.sell_l3_shr_prev = 0
        self.sell_l4_shr_prev = 0
        self.sell_l5_shr_prev = 0
        self.sell_l6_shr_prev = 0
        self.sell_l7_shr_prev = 0
        self.sell_l8_shr_prev = 0
        self.sell_l9_shr_prev = 0
        self.sell_l10_shr_prev = 0
        self.buy_l1_px_diff = 0
        self.buy_l2_px_diff = 0
        self.buy_l3_px_diff = 0
        self.buy_l4_px_diff = 0
        self.buy_l5_px_diff = 0
        self.buy_l6_px_diff = 0
        self.buy_l7_px_diff = 0
        self.buy_l8_px_diff = 0
        self.buy_l9_px_diff = 0
        self.buy_l10_px_diff = 0
        self.sell_l1_px_diff = 0
        self.sell_l2_px_diff = 0
        self.sell_l3_px_diff = 0
        self.sell_l4_px_diff = 0
        self.sell_l5_px_diff = 0
        self.sell_l6_px_diff = 0
        self.sell_l7_px_diff = 0
        self.sell_l8_px_diff = 0
        self.sell_l9_px_diff = 0
        self.sell_l10_px_diff = 0
        self.buy_l1_shr_diff = 0
        self.buy_l2_shr_diff = 0
        self.buy_l3_shr_diff = 0
        self.buy_l4_shr_diff = 0
        self.buy_l5_shr_diff = 0
        self.buy_l6_shr_diff = 0
        self.buy_l7_shr_diff = 0
        self.buy_l8_shr_diff = 0
        self.buy_l9_shr_diff = 0
        self.buy_l10_shr_diff = 0
        self.sell_l1_shr_diff = 0
        self.sell_l2_shr_diff = 0
        self.sell_l3_shr_diff = 0
        self.sell_l4_shr_diff = 0
        self.sell_l5_shr_diff = 0
        self.sell_l6_shr_diff = 0
        self.sell_l7_shr_diff = 0
        self.sell_l8_shr_diff = 0
        self.sell_l9_shr_diff = 0
        self.sell_l10_shr_diff = 0
        self.buy_add_1s_prev = 0
        self.buy_add_1s_now = 0
        self.buy_add_3s_prev = 0
        self.buy_add_3s_now = 0
        self.sell_add_1s_prev = 0
        self.sell_add_1s_now = 0
        self.sell_add_3s_prev = 0
        self.sell_add_3s_now  = 0
        self.buy_del_1s_prev = 0
        self.buy_del_1s_now = 0
        self.buy_del_3s_prev = 0
        self.buy_del_3s_now = 0
        self.sell_del_1s_prev = 0
        self.sell_del_1s_now = 0
        self.sell_del_3s_prev = 0
        self.sell_del_3s_now = 0
        self.buy_exec_1s_prev = 0
        self.buy_exec_1s_now = 0
        self.buy_exec_3s_prev = 0
        self.buy_exec_3s_now = 0
        self.sell_exec_1s_prev = 0
        self.sell_exec_1s_now = 0
        self.sell_exec_3s_prev = 0
        self.sell_exec_3s_now = 0
        self.buy_add_list_1s_prev = 0
        self.buy_add_list_1s_now = 0
        self.sell_add_list_1s_prev = 0
        self.sell_add_list_1s_now = 0
        self.buy_del_list_1s_prev = 0
        self.buy_del_list_1s_now = 0
        self.sell_del_list_1s_prev = 0
        self.sell_del_list_1s_now = 0
        self.buy_exec_list_1s_prev = 0
        self.buy_exec_list_1s_now = 0
        self.sell_exec_list_1s_prev = 0
        self.sell_exec_list_1s_now = 0
        self.beginning_nanos_epoch = 0
        self.buy_add_slope = 0                
        self.sell_add_slope = 0 
        self.buy_add_slope_last_update_time = 0
        self.sell_add_slope_last_update_time = 0
        self.buy_del_slope = 0                
        self.buy_exec_slope = 0                
        self.sell_del_slope = 0 
        self.buy_del_slope_last_update_time = 0
        self.sell_del_slope_last_update_time = 0
        self.sell_exec_slope = 0 
        self.buy_exec_slope_last_update_time = 0
        self.sell_exec_slope_last_update_time = 0
        self.buy_add_sh_l1_10s_dec = 0 
        self.buy_add_sh_l1_1m_dec = 0 
        self.buy_add_sh_l1_3m_dec = 0 
        self.buy_add_sh_l1_10m_dec = 0 
        self.buy_add_cnt_l1_10s_dec = 0 
        self.buy_add_cnt_l1_1m_dec = 0 
        self.buy_add_cnt_l1_3m_dec = 0 
        self.buy_add_cnt_l1_10m_dec = 0 
        self.sell_add_sh_l1_10s_dec = 0 
        self.sell_add_sh_l1_1m_dec = 0 
        self.sell_add_sh_l1_3m_dec = 0 
        self.sell_add_sh_l1_10m_dec = 0 
        self.sell_add_cnt_l1_10s_dec = 0 
        self.sell_add_cnt_l1_1m_dec = 0 
        self.sell_add_cnt_l1_3m_dec = 0 
        self.sell_add_cnt_l1_10m_dec = 0 
        self.buy_add_sh_l2_10s_dec = 0 
        self.buy_add_sh_l2_1m_dec = 0 
        self.buy_add_sh_l2_3m_dec = 0 
        self.buy_add_sh_l2_10m_dec = 0 
        self.buy_add_cnt_l2_10s_dec = 0 
        self.buy_add_cnt_l2_1m_dec = 0 
        self.buy_add_cnt_l2_3m_dec = 0 
        self.buy_add_cnt_l2_10m_dec = 0 
        self.sell_add_sh_l2_10s_dec = 0 
        self.sell_add_sh_l2_1m_dec = 0 
        self.sell_add_sh_l2_3m_dec = 0 
        self.sell_add_sh_l2_10m_dec = 0 
        self.sell_add_cnt_l2_10s_dec = 0 
        self.sell_add_cnt_l2_1m_dec = 0 
        self.sell_add_cnt_l2_3m_dec = 0 
        self.sell_add_cnt_l2_10m_dec = 0 
        self.buy_delete_sh_l1_10s_dec = 0 
        self.buy_delete_sh_l1_1m_dec = 0 
        self.buy_delete_sh_l1_3m_dec = 0 
        self.buy_delete_sh_l1_10m_dec = 0 
        self.buy_delete_cnt_l1_10s_dec = 0 
        self.buy_delete_cnt_l1_1m_dec = 0 
        self.buy_delete_cnt_l1_3m_dec = 0 
        self.buy_delete_cnt_l1_10m_dec = 0 
        self.sell_delete_sh_l1_10s_dec = 0 
        self.sell_delete_sh_l1_1m_dec = 0 
        self.sell_delete_sh_l1_3m_dec = 0 
        self.sell_delete_sh_l1_10m_dec = 0 
        self.sell_delete_cnt_l1_10s_dec = 0 
        self.sell_delete_cnt_l1_1m_dec = 0 
        self.sell_delete_cnt_l1_3m_dec = 0 
        self.sell_delete_cnt_l1_10m_dec = 0 
        self.buy_delete_sh_l2_10s_dec = 0 
        self.buy_delete_sh_l2_1m_dec = 0 
        self.buy_delete_sh_l2_3m_dec = 0 
        self.buy_delete_sh_l2_10m_dec = 0 
        self.buy_delete_cnt_l2_10s_dec = 0 
        self.buy_delete_cnt_l2_1m_dec = 0 
        self.buy_delete_cnt_l2_3m_dec = 0 
        self.buy_delete_cnt_l2_10m_dec = 0 
        self.sell_delete_sh_l2_10s_dec = 0 
        self.sell_delete_sh_l2_1m_dec = 0 
        self.sell_delete_sh_l2_3m_dec = 0 
        self.sell_delete_sh_l2_10m_dec = 0 
        self.sell_delete_cnt_l2_10s_dec = 0 
        self.sell_delete_cnt_l2_1m_dec = 0 
        self.sell_delete_cnt_l2_3m_dec = 0 
        self.sell_delete_cnt_l2_10m_dec = 0 
        self.counter_1m = 0
        self.buy_side_order_life = 0
        self.sell_side_order_life = 0
        self.order_life_last_exec_order = 0
        self.di_p1 = 0
        self.di_n1 = 0
        self.di1_ratio = 0
        self.di_p10 = 0
        self.di_n10 = 0
        self.di10_ratio = 0

        self.e_buy_add_px_10s = yest_close
        self.e_sell_add_px_10s = yest_close
        self.e_buy_del_px_10s = yest_close
        self.e_sell_del_px_10s = yest_close
        self.e_buy_exec_px_30s = yest_close
        self.e_sell_exec_px_30s = yest_close
        
        self.ewavg_qty_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)  
        self.ewavg_qty_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)  
        self.ewavg_qty_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.ewavg_qty_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.ewavg_qty_30m = ExponentialMovingSum(0, 0, 30 * 60 * nanos_in_sec)
        self.ewavg_px_qty_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec) 
        self.ewavg_px_qty_1m  = ExponentialMovingSum(0, 0, 60 * nanos_in_sec) 
        self.ewavg_px_qty_3m  = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec) 
        self.ewavg_px_qty_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.ewavg_px_qty_30m = ExponentialMovingSum(0, 0, 30* 60 * nanos_in_sec)
        self.ewavg_px_qty_10s_adj = ExponentialMovingSum(0, 0, 10 * nanos_in_sec) 
        self.ewavg_px_qty_1m_adj  = ExponentialMovingSum(0, 0, 60 * nanos_in_sec) 
        self.ewavg_px_qty_3m_adj  = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec) 
        self.ewavg_px_qty_10m_adj = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.ewavg_px_qty_30m_adj = ExponentialMovingSum(0, 0, 30 * 60 * nanos_in_sec)
        self.buy_add_1s = ExponentialMovingSum(0, 0, 1 * nanos_in_sec)  
        self.buy_add_3s = ExponentialMovingSum(0, 0, 3 * nanos_in_sec)  
        self.buy_add_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)  
        self.buy_add_90s = ExponentialMovingSum(0, 0, 90 * nanos_in_sec)  
        self.sell_add_1s = ExponentialMovingSum(0, 0, 1 * nanos_in_sec)  
        self.sell_add_3s = ExponentialMovingSum(0, 0, 3 * nanos_in_sec)  
        self.sell_add_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)  
        self.sell_add_90s = ExponentialMovingSum(0, 0, 90 * nanos_in_sec)  
        self.buy_del_1s = ExponentialMovingSum(0, 0, 1 * nanos_in_sec)  
        self.buy_del_3s = ExponentialMovingSum(0, 0, 3 * nanos_in_sec)  
        self.buy_del_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)  
        self.buy_del_90s = ExponentialMovingSum(0, 0, 90 * nanos_in_sec)  
        self.sell_del_1s = ExponentialMovingSum(0, 0, 1 * nanos_in_sec)  
        self.sell_del_3s = ExponentialMovingSum(0, 0, 3 * nanos_in_sec)  
        self.sell_del_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)  
        self.sell_del_90s = ExponentialMovingSum(0, 0, 90 * nanos_in_sec) 
        self.buy_exec_1s = ExponentialMovingSum(0, 0, 1 * nanos_in_sec)  
        self.buy_exec_3s = ExponentialMovingSum(0, 0, 3 * nanos_in_sec)  
        self.buy_exec_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)  
        self.buy_exec_90s = ExponentialMovingSum(0, 0, 90 * nanos_in_sec)  
        self.sell_exec_1s = ExponentialMovingSum(0, 0, 1 * nanos_in_sec)  
        self.sell_exec_3s = ExponentialMovingSum(0, 0, 3 * nanos_in_sec)  
        self.sell_exec_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)  
        self.sell_exec_90s = ExponentialMovingSum(0, 0, 90 * nanos_in_sec) 
        self.ewavg_buy_add_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_add_px_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_add_time_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_add_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_add_time_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_add_time_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_add_px_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_add_cnt_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_px_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_time_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_time_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_time_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_px_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_add_cnt_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_px_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_time_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_time_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_time_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_px_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_del_cnt_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_px_qty_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_time_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_time_px_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_time_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_px_sq_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_sell_del_cnt_10s = ExponentialMovingSum(0, 0, 10 * micros_in_sec) 
        self.ewavg_buy_exec_qty_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_buy_exec_px_qty_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_buy_exec_time_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_buy_exec_px_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_buy_exec_time_px_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_buy_exec_time_sq_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_buy_exec_px_sq_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_buy_exec_cnt_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_qty_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_px_qty_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_time_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_px_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_time_px_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_time_sq_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_px_sq_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.ewavg_sell_exec_cnt_30s = ExponentialMovingSum(0, 0, 30 * micros_in_sec) 
        self.buy_add_sh_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_add_sh_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_add_sh_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_add_sh_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_add_cnt_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_add_cnt_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_add_cnt_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_add_cnt_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_add_sh_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_add_sh_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_add_sh_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_add_sh_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_add_cnt_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_add_cnt_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_add_cnt_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_add_cnt_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_add_sh_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_add_sh_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_add_sh_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_add_sh_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_add_cnt_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_add_cnt_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_add_cnt_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_add_cnt_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_add_sh_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_add_sh_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_add_sh_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_add_sh_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_add_cnt_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_add_cnt_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_add_cnt_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_add_cnt_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_delete_sh_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_delete_sh_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_delete_sh_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_delete_sh_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_delete_cnt_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_delete_cnt_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_delete_cnt_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_delete_cnt_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_delete_sh_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_delete_sh_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_delete_sh_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_delete_sh_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_delete_cnt_l1_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_delete_cnt_l1_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_delete_cnt_l1_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_delete_cnt_l1_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_delete_sh_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_delete_sh_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_delete_sh_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_delete_sh_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_delete_cnt_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_delete_cnt_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_delete_cnt_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_delete_cnt_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_delete_sh_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_delete_sh_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_delete_sh_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_delete_sh_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_delete_cnt_l2_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_delete_cnt_l2_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_delete_cnt_l2_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_delete_cnt_l2_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_level_added_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_level_added_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_level_added_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_level_added_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_level_added_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_level_added_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_level_added_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_level_added_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_level_removed_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.buy_level_removed_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.buy_level_removed_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_level_removed_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_level_removed_10s = ExponentialMovingSum(0, 0, 10 * nanos_in_sec)
        self.sell_level_removed_1m = ExponentialMovingSum(0, 0, 60 * nanos_in_sec)
        self.sell_level_removed_3m = ExponentialMovingSum(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_level_removed_10m = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.obv1_10 = ExponentialMovingSum(0, 0, 1 * 30 * nanos_in_sec)
        self.obv1_30 = ExponentialMovingSum(0, 0, 1 * 60 * nanos_in_sec)
        self.dm_p1 = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.dm_n1 = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.high_low_sum = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.dm_p10 = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)
        self.dm_n10 = ExponentialMovingSum(0, 0, 10 * 60 * nanos_in_sec)

        self.eavg_spread = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.eavg_spread_10m = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.eavg_px_10m = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.eavg_px_10m_adj = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.eavg_px_10s = ExponentialMovingAverage(0, 0, 10 * nanos_in_sec)
        self.eavg_px_1m = ExponentialMovingAverage(0, 0, 60 * nanos_in_sec)
        self.eavg_px_3m = ExponentialMovingAverage(0, 0, 3 * 60 * nanos_in_sec)
        self.eavg_px_10m = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.eavg_px_10s_adj = ExponentialMovingAverage(0, 0, 10 * nanos_in_sec)
        self.eavg_px_1m_adj = ExponentialMovingAverage(0, 0, 60 * nanos_in_sec)
        self.eavg_px_3m_adj = ExponentialMovingAverage(0, 0, 3 * 60 * nanos_in_sec)
        self.eavg_px_10m_adj = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_exec_10s = ExponentialMovingAverage(0, 0, 10 * nanos_in_sec)
        self.buy_exec_1m = ExponentialMovingAverage(0, 0, 60 * nanos_in_sec)
        self.buy_exec_3m = ExponentialMovingAverage(0, 0, 3 * 60 * nanos_in_sec)
        self.buy_exec_10m = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.buy_exec_30m = ExponentialMovingAverage(0, 0, 30 * 60 * nanos_in_sec)
        self.sell_exec_10s = ExponentialMovingAverage(0, 0, 10 * nanos_in_sec)
        self.sell_exec_1m = ExponentialMovingAverage(0, 0, 60 * nanos_in_sec)
        self.sell_exec_3m = ExponentialMovingAverage(0, 0, 3 * 60 * nanos_in_sec)
        self.sell_exec_10m = ExponentialMovingAverage(0, 0, 10 * 60 * nanos_in_sec)
        self.sell_exec_30m = ExponentialMovingAverage(0, 0, 30 * 60 * nanos_in_sec)

        self.buy_add_list_1s = []
        self.buy_add_list_10s = []
        self.buy_add_list_90s = []
        self.sell_add_list_1s = []
        self.sell_add_list_10s = []
        self.sell_add_list_90s = []
        self.buy_del_list_1s = []
        self.buy_del_list_10s = []
        self.buy_del_list_90s = []
        self.sell_del_list_1s = []
        self.sell_del_list_10s = []
        self.sell_del_list_90s = []
        self.buy_exec_list_1s = []
        self.buy_exec_list_10s = []
        self.buy_exec_list_90s = []
        self.sell_exec_list_1s = []
        self.sell_exec_list_10s = []
        self.sell_exec_list_90s = []

        self.reset_time_bucket_based_variables(self.mid, self.mid, 60)

        print(f'End of SimData.init_data() beta {self.beta} yest_close {yest_close}')

    def reset_time_bucket_based_variables(self, high, low, bucket_frequency):
        
        self.is_bucket_first_exec = True

        self.high_1m = high
        self.high_3m = high
        self.high_10m = high
        self.high_30m = high
        self.high_day = high

        self.low_1m = low
        self.low_3m = low
        self.low_10m = low
        self.low_30m = low
        self.low_day = low

        self.cur_hi_lo = HiLow(high, low, 60)

        hi_lo = HiLow(high, low, bucket_frequency)

        self.hi_lo_1m = [hi_lo for i in range(1)]
        self.hi_lo_3m = [hi_lo for i in range(3)]
        self.hi_lo_10m = [hi_lo for i in range(10)]
        self.hi_lo_30m = [hi_lo for i in range(30)]


    def update_data(self, event, obj: Union[Add, Delete, Execute, Trade, State, Seconds]):

        self.nanos_from_epoch = obj.nanos_from_epoch

        if event == 'add':
            self.on_add(obj)

        elif event == 'delete':
            self.on_delete(obj)

        elif event == 'execute':
            self.on_execute(obj)
        
        elif event == 'trade':
            self.on_trade(obj)
        
        elif event == 'state':
            self.on_state(obj)
 
        elif event == 'seconds':
            self.on_seconds(obj)

    def update_mids_spreads(self, obj):

        if self.is_cont_trading and self.order_book.is_top_level_changed:

            self.mid_prev = self.mid
            self.mid_adj_prev = self.mid_adj
            
            if not self.order_book.buy_side and not self.order_book.sell_side:
                pass
            elif not self.order_book.buy_side:
                self.mid = self.order_book.sell_side[0].price
                self.mid_adj = self.order_book.sell_side[0].price
                self.spread = 0
            elif not self.order_book.sell_side:
                self.mid = self.order_book.buy_side[0].price
                self.mid_adj = self.order_book.buy_side[0].price
                self.spread = 0
            else:
                self.mid = (self.order_book.buy_side[0].price + self.order_book.sell_side[0].price) / 2
                self.mid_adj = (
                    ((self.order_book.buy_side[0].price * self.order_book.sell_side[0].total_shares) 
                    + (self.order_book.sell_side[0].price * self.order_book.buy_side[0].total_shares)) 
                    / (self.order_book.buy_side[0].total_shares + self.order_book.sell_side[0].total_shares))
                
                self.spread = self.order_book.sell_side[0].price - self.order_book.buy_side[0].price
        
            self.eavg_spread.update_value(self.spread, obj.nanos_from_epoch)
            self.eavg_px_10s.update_value(self.mid, obj.nanos_from_epoch)
            self.eavg_px_1m.update_value(self.mid, obj.nanos_from_epoch)
            self.eavg_px_3m.update_value(self.mid, obj.nanos_from_epoch)
            self.eavg_px_10m.update_value(self.mid, obj.nanos_from_epoch)
            self.eavg_px_10s_adj.update_value(self.mid_adj, obj.nanos_from_epoch)
            self.eavg_px_1m_adj.update_value(self.mid_adj, obj.nanos_from_epoch)
            self.eavg_px_3m_adj.update_value(self.mid_adj, obj.nanos_from_epoch)
            self.eavg_px_10m_adj.update_value(self.mid_adj, obj.nanos_from_epoch)

        self.spread_l2 = self.order_book.sell_side[1].price - self.order_book.buy_side[1].price if 1 < len(self.order_book.sell_side) and 1 < len(self.order_book.buy_side) else None # Can give a better default value later
        self.spread_l3 = self.order_book.sell_side[2].price - self.order_book.buy_side[2].price if 2 < len(self.order_book.sell_side) and 2 < len(self.order_book.buy_side) else None # Can give a better default value later

    def on_add(self, obj: Add):

        self.update_mids_spreads(obj)

        if not self.is_cont_trading: return 

        if obj.side == 'B':

            #StrategyTimeSensitiveData
            if obj.price >= self.mid * (1 - self.sensitivity):
                self.buy_add_1s.update_value(1, obj.nanos_from_epoch)
                self.buy_add_3s.update_value(1, obj.nanos_from_epoch)
                self.buy_add_10s.update_value(1, obj.nanos_from_epoch)
                self.buy_add_90s.update_value(1, obj.nanos_from_epoch)
                self.buy_add_list_1s[:] = [x for x in self.buy_add_list_1s if x > (obj.nanos_from_epoch - 1 * nanos_in_sec)]
                self.buy_add_list_1s.append(obj.nanos_from_epoch)
                self.buy_add_list_10s[:] = [x for x in self.buy_add_list_10s if x > (obj.nanos_from_epoch - 10 * nanos_in_sec)]
                self.buy_add_list_10s.append(obj.nanos_from_epoch)            
                self.buy_add_list_90s[:] = [x for x in self.buy_add_list_90s if x > (obj.nanos_from_epoch - 90 * nanos_in_sec)]
                self.buy_add_list_90s.append(obj.nanos_from_epoch)
                if obj.price == self.order_book.buy_side[0].price:
                    self.update_add_top_px(obj)

            #StrategyExecData
            if self.order_book.buy_side is not None and obj.price == self.order_book.buy_side[0].price:
                if  self.order_book.buy_side[0].number_of_orders == 1:
                    self.buy_level_added_10s.update_value(1, obj.nanos_from_epoch)
                    self.buy_level_added_1m.update_value(1, obj.nanos_from_epoch)
                    self.buy_level_added_3m.update_value(1, obj.nanos_from_epoch)
                    self.buy_level_added_10m.update_value(1, obj.nanos_from_epoch)
                self.buy_add_sh_l1_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_sh_l1_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_sh_l1_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_sh_l1_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_cnt_l1_10s.update_value(1, obj.nanos_from_epoch)
                self.buy_add_cnt_l1_1m.update_value(1, obj.nanos_from_epoch)
                self.buy_add_cnt_l1_3m.update_value(1, obj.nanos_from_epoch)
                self.buy_add_cnt_l1_10m.update_value(1, obj.nanos_from_epoch)
            if len(self.order_book.buy_side) > 1 and obj.price == self.order_book.buy_side[1].price:
                self.buy_add_sh_l2_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_sh_l2_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_sh_l2_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_sh_l2_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_add_cnt_l2_10s.update_value(1, obj.nanos_from_epoch)
                self.buy_add_cnt_l2_1m.update_value(1, obj.nanos_from_epoch)
                self.buy_add_cnt_l2_3m.update_value(1, obj.nanos_from_epoch)
                self.buy_add_cnt_l2_10m.update_value(1, obj.nanos_from_epoch)

        elif obj.side == 'S':
            #StrategyTimeSensitiveData
            if obj.price <= self.mid * (1 + self.sensitivity):
                self.sell_add_1s.update_value(1, obj.nanos_from_epoch)
                self.sell_add_3s.update_value(1, obj.nanos_from_epoch)
                self.sell_add_10s.update_value(1, obj.nanos_from_epoch)
                self.sell_add_90s.update_value(1, obj.nanos_from_epoch)
                self.sell_add_list_1s[:] = [x for x in self.sell_add_list_1s if x > (obj.nanos_from_epoch - 1 * nanos_in_sec)]
                self.sell_add_list_1s.append(obj.nanos_from_epoch)
                self.sell_add_list_10s[:] = [x for x in self.sell_add_list_10s if x > (obj.nanos_from_epoch - 10 * nanos_in_sec)]
                self.sell_add_list_10s.append(obj.nanos_from_epoch)
                self.sell_add_list_90s[:] = [x for x in self.sell_add_list_90s if x > (obj.nanos_from_epoch - 90 * nanos_in_sec)]
                self.sell_add_list_90s.append(obj.nanos_from_epoch)
                if obj.price == self.order_book.sell_side[0].price:
                    self.update_add_top_px(obj)
            
            #StrategyExecData
            if self.order_book.sell_side is not None and obj.price == self.order_book.sell_side[0].price:
                if self.order_book.sell_side[0].number_of_orders == 1:
                    self.sell_level_added_10s.update_value(1, obj.nanos_from_epoch)
                    self.sell_level_added_1m.update_value(1, obj.nanos_from_epoch)
                    self.sell_level_added_3m.update_value(1, obj.nanos_from_epoch)
                    self.sell_level_added_10m.update_value(1, obj.nanos_from_epoch)          
                self.sell_add_sh_l1_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_sh_l1_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_sh_l1_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_sh_l1_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_cnt_l1_10s.update_value(1, obj.nanos_from_epoch)
                self.sell_add_cnt_l1_1m.update_value(1, obj.nanos_from_epoch)
                self.sell_add_cnt_l1_3m.update_value(1, obj.nanos_from_epoch)
                self.sell_add_cnt_l1_10m.update_value(1, obj.nanos_from_epoch)            
            if len(self.order_book.sell_side) > 1 and obj.price == self.order_book.sell_side[1].price:
                self.sell_add_sh_l2_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_sh_l2_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_sh_l2_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_sh_l2_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_add_cnt_l2_10s.update_value(1, obj.nanos_from_epoch)
                self.sell_add_cnt_l2_1m.update_value(1, obj.nanos_from_epoch)
                self.sell_add_cnt_l2_3m.update_value(1, obj.nanos_from_epoch)
                self.sell_add_cnt_l2_10m.update_value(1, obj.nanos_from_epoch)
        else:
            pass


    def on_delete(self, obj: Delete):

        self.update_mids_spreads(obj)

        if not self.is_cont_trading: return

        if obj.side == 'B':
            #StrategyTimeSensitiveData
            if obj.price >= self.mid * (1 - self.sensitivity):
                self.buy_del_1s.update_value(1, obj.nanos_from_epoch)
                self.buy_del_3s.update_value(1, obj.nanos_from_epoch)
                self.buy_del_10s.update_value(1, obj.nanos_from_epoch)
                self.buy_del_90s.update_value(1, obj.nanos_from_epoch)
                self.buy_del_list_1s[:] = [x for x in self.buy_del_list_1s if x > (obj.nanos_from_epoch - 1 * nanos_in_sec)]
                self.buy_del_list_1s.append(obj.nanos_from_epoch)
                self.buy_del_list_10s[:] = [x for x in self.buy_del_list_10s if x > (obj.nanos_from_epoch - 10 * nanos_in_sec)]
                self.buy_del_list_10s.append(obj.nanos_from_epoch)
                self.buy_del_list_90s[:] = [x for x in self.buy_del_list_90s if x > (obj.nanos_from_epoch - 90 * nanos_in_sec)]
                self.buy_del_list_90s.append(obj.nanos_from_epoch)
                if not len(self.order_book.buy_side) < 1:
                    if obj.price >= self.order_book.buy_side[0].price:
                        self.update_del_top_px(obj)

            #StrategyExecData
            if len(self.order_book.buy_side) < 1 or obj.price >= self.order_book.buy_side[0].price:
                if len(self.order_book.buy_side) < 1 or obj.price > self.order_book.buy_side[0].price:
                    self.buy_level_removed_10s.update_value(1, obj.nanos_from_epoch)
                    self.buy_level_removed_1m.update_value(1, obj.nanos_from_epoch)
                    self.buy_level_removed_3m.update_value(1, obj.nanos_from_epoch)
                    self.buy_level_removed_10m.update_value(1, obj.nanos_from_epoch)
                self.buy_delete_sh_l1_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_sh_l1_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_sh_l1_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_sh_l1_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_cnt_l1_10s.update_value(1, obj.nanos_from_epoch)
                self.buy_delete_cnt_l1_1m.update_value(1, obj.nanos_from_epoch)
                self.buy_delete_cnt_l1_3m.update_value(1, obj.nanos_from_epoch)
                self.buy_delete_cnt_l1_10m.update_value(1, obj.nanos_from_epoch)
            if len(self.order_book.buy_side) > 1 and obj.price >= self.order_book.buy_side[1].price and obj.price < self.order_book.buy_side[0].price:
                self.buy_delete_sh_l2_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_sh_l2_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_sh_l2_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_sh_l2_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_delete_cnt_l2_10s.update_value(1, obj.nanos_from_epoch)
                self.buy_delete_cnt_l2_1m.update_value(1, obj.nanos_from_epoch)
                self.buy_delete_cnt_l2_3m.update_value(1, obj.nanos_from_epoch)
                self.buy_delete_cnt_l2_10m.update_value(1, obj.nanos_from_epoch)

        elif obj.side == 'S':
            #StrategyTimeSensitiveData
            if obj.price <= self.mid * (1 + self.sensitivity):
                self.sell_del_1s.update_value(1, obj.nanos_from_epoch)
                self.sell_del_3s.update_value(1, obj.nanos_from_epoch)
                self.sell_del_10s.update_value(1, obj.nanos_from_epoch)
                self.sell_del_90s.update_value(1, obj.nanos_from_epoch)
                self.sell_del_list_1s[:] = [x for x in self.sell_del_list_1s if x > (obj.nanos_from_epoch - 1 * nanos_in_sec)]
                self.sell_del_list_1s.append(obj.nanos_from_epoch)
                self.sell_del_list_10s[:] = [x for x in self.sell_del_list_10s if x > (obj.nanos_from_epoch - 10 * nanos_in_sec)]
                self.sell_del_list_10s.append(obj.nanos_from_epoch)
                self.sell_del_list_90s[:] = [x for x in self.sell_del_list_90s if x > (obj.nanos_from_epoch - 90 * nanos_in_sec)]
                self.sell_del_list_90s.append(obj.nanos_from_epoch)
                if not len(self.order_book.sell_side) < 1:
                    if obj.price <= self.order_book.sell_side[0].price:
                        self.update_del_top_px(obj)

            #StrategyExecData
            if len(self.order_book.sell_side) < 1 or obj.price <= self.order_book.sell_side[0].price:
                
                if len(self.order_book.sell_side) < 1 or obj.price < self.order_book.sell_side[0].price:
                    self.sell_level_removed_10s.update_value(1, obj.nanos_from_epoch)
                    self.sell_level_removed_1m.update_value(1, obj.nanos_from_epoch)
                    self.sell_level_removed_3m.update_value(1, obj.nanos_from_epoch)
                    self.sell_level_removed_10m.update_value(1, obj.nanos_from_epoch)
                
                self.sell_delete_sh_l1_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_sh_l1_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_sh_l1_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_sh_l1_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_cnt_l1_10s.update_value(1, obj.nanos_from_epoch)
                self.sell_delete_cnt_l1_1m.update_value(1, obj.nanos_from_epoch)
                self.sell_delete_cnt_l1_3m.update_value(1, obj.nanos_from_epoch)
                self.sell_delete_cnt_l1_10m.update_value(1, obj.nanos_from_epoch)

            if len(self.order_book.sell_side) > 1 and obj.price <= self.order_book.sell_side[1].price and obj.price > self.order_book.sell_side[0].price:
                self.sell_delete_sh_l2_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_sh_l2_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_sh_l2_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_sh_l2_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_delete_cnt_l2_10s.update_value(1, obj.nanos_from_epoch)
                self.sell_delete_cnt_l2_1m.update_value(1, obj.nanos_from_epoch)
                self.sell_delete_cnt_l2_3m.update_value(1, obj.nanos_from_epoch)
                self.sell_delete_cnt_l2_10m.update_value(1, obj.nanos_from_epoch)

        else:
            pass

    # end of method on_delete

    def on_execute(self, obj: Execute):

        self.update_mids_spreads(obj)

        self.time_exec_prev = self.time_exec_cur  # unused currently
        self.time_exec_cur = obj.nanos_from_epoch # unused currently

        if self.order_book.is_top_level_changed:

            if obj.side == 'B':
                self.day_buy_notional += (obj.shares * obj.price)
                self.day_buy_qty += obj.shares
                self.buy_exec_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_exec_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_exec_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_exec_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.buy_exec_30m.update_value(obj.shares, obj.nanos_from_epoch)
            else:
                self.day_sell_notional += (obj.shares * obj.price)
                self.day_sell_qty += obj.shares 
                self.sell_exec_10s.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_exec_1m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_exec_3m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_exec_10m.update_value(obj.shares, obj.nanos_from_epoch)
                self.sell_exec_30m.update_value(obj.shares, obj.nanos_from_epoch)

            # Variables exec_wgt
            self.ewavg_qty_10s.update_value(obj.shares, obj.nanos_from_epoch)  
            self.ewavg_qty_1m.update_value(obj.shares, obj.nanos_from_epoch)  
            self.ewavg_qty_3m.update_value(obj.shares, obj.nanos_from_epoch)  
            self.ewavg_qty_10m.update_value(obj.shares, obj.nanos_from_epoch)     
            self.ewavg_qty_30m.update_value(obj.shares, obj.nanos_from_epoch) 

            self.ewavg_px_qty_10s.update_value(self.mid_prev * obj.shares, obj.nanos_from_epoch)    
            self.ewavg_px_qty_1m.update_value(self.mid_prev * obj.shares, obj.nanos_from_epoch)    
            self.ewavg_px_qty_3m.update_value(self.mid_prev * obj.shares, obj.nanos_from_epoch)    
            self.ewavg_px_qty_10m.update_value(self.mid_prev * obj.shares, obj.nanos_from_epoch)   
            self.ewavg_px_qty_30m.update_value(self.mid_prev * obj.shares, obj.nanos_from_epoch)   

            self.ewavg_px_10s = self.ewavg_px_qty_10s.get_last_value() / self.ewavg_qty_10s.get_last_value() 
            self.ewavg_px_1m = self.ewavg_px_qty_1m.get_last_value() / self.ewavg_qty_1m.get_last_value() 
            self.ewavg_px_3m = self.ewavg_px_qty_3m.get_last_value() / self.ewavg_qty_3m.get_last_value() 
            self.ewavg_px_10m = self.ewavg_px_qty_10m.get_last_value() / self.ewavg_qty_10m.get_last_value()
            self.ewavg_px_30m = self.ewavg_px_qty_30m.get_last_value() / self.ewavg_qty_30m.get_last_value()

            #Variables exec_wgt_adj
            self.ewavg_px_qty_10s_adj.update_value(self.mid_adj_prev * obj.shares, obj.nanos_from_epoch)    
            self.ewavg_px_qty_1m_adj.update_value(self.mid_adj_prev * obj.shares, obj.nanos_from_epoch)    
            self.ewavg_px_qty_3m_adj.update_value(self.mid_adj_prev * obj.shares, obj.nanos_from_epoch)    
            self.ewavg_px_qty_10m_adj.update_value(self.mid_adj_prev * obj.shares, obj.nanos_from_epoch)   
            self.ewavg_px_qty_30m_adj.update_value(self.mid_adj_prev * obj.shares, obj.nanos_from_epoch)   

            self.ewavg_px_10s_adj = self.ewavg_px_qty_10s_adj.get_last_value() / self.ewavg_qty_10s.get_last_value() 
            self.ewavg_px_1m_adj = self.ewavg_px_qty_1m_adj.get_last_value() / self.ewavg_qty_1m.get_last_value() 
            self.ewavg_px_3m_adj = self.ewavg_px_qty_3m_adj.get_last_value() / self.ewavg_qty_3m.get_last_value() 
            self.ewavg_px_10m_adj = self.ewavg_px_qty_10m_adj.get_last_value() / self.ewavg_qty_10m.get_last_value()
            self.ewavg_px_30m_adj = self.ewavg_px_qty_30m_adj.get_last_value() / self.ewavg_qty_30m.get_last_value()

            self.day_qty += obj.shares 
            self.day_qty_px += (self.mid_prev * obj.shares)
            self.day_w_px = self.day_qty_px / self.day_qty  

            self.day_qty_px_adj += (self.mid_adj_prev * obj.shares)
            self.day_w_px_adj = self.day_qty_px_adj / self.day_qty  
            
        #self.order_book.print_order_book(until=3)
        
        #StrategyTimeSensitiveData
        if self.is_cont_trading:
            if obj.side == 'B':
                
                self.buy_exec_1s.update_value(1, obj.nanos_from_epoch)
                self.buy_exec_3s.update_value(1, obj.nanos_from_epoch)
                self.buy_exec_10s.update_value(1, obj.nanos_from_epoch)
                self.buy_exec_90s.update_value(1, obj.nanos_from_epoch)
                self.buy_exec_list_1s[:] = [x for x in self.buy_exec_list_1s if x > (obj.nanos_from_epoch - 1 * nanos_in_sec)]
                self.buy_exec_list_1s.append(obj.nanos_from_epoch)
                self.buy_exec_list_10s[:] = [x for x in self.buy_exec_list_10s if x > (obj.nanos_from_epoch - 10 * nanos_in_sec)]
                self.buy_exec_list_10s.append(obj.nanos_from_epoch)
                self.buy_exec_list_90s[:] = [x for x in self.buy_exec_list_90s if x > (obj.nanos_from_epoch - 90 * nanos_in_sec)]
                self.buy_exec_list_90s.append(obj.nanos_from_epoch)
            else:
                self.sell_exec_1s.update_value(1, obj.nanos_from_epoch)
                self.sell_exec_3s.update_value(1, obj.nanos_from_epoch)
                self.sell_exec_10s.update_value(1, obj.nanos_from_epoch)
                self.sell_exec_90s.update_value(1, obj.nanos_from_epoch)
                self.sell_exec_list_1s[:] = [x for x in self.sell_exec_list_1s if x > (obj.nanos_from_epoch - 1 * nanos_in_sec)]
                self.sell_exec_list_1s.append(obj.nanos_from_epoch)
                self.sell_exec_list_10s[:] = [x for x in self.sell_exec_list_10s if x > (obj.nanos_from_epoch - 10 * nanos_in_sec)]
                self.sell_exec_list_10s.append(obj.nanos_from_epoch)
                self.sell_exec_list_90s[:] = [x for x in self.sell_exec_list_90s if x > (obj.nanos_from_epoch - 90 * nanos_in_sec)]
                self.sell_exec_list_90s.append(obj.nanos_from_epoch)
            
            self.update_exec_top_px(obj)

            #update slopes
            if obj.nanos_from_epoch - self.last_exec_snap > self.exec_delay_window:

                update_time = round( (obj.nanos_from_epoch - self.beginning_nanos_epoch)/1000,0)
                self.buy_add_slope = round(self.buy_add_slope / np.log(1 + (update_time - self.buy_add_slope_last_update_time + 0.00001) ),6)  
                self.sell_add_slope = round(self.sell_add_slope / np.log(1 + (update_time - self.sell_add_slope_last_update_time + 0.00001)),6)  
                self.buy_del_slope = round(self.buy_del_slope / np.log(1 + (update_time - self.buy_del_slope_last_update_time + 0.00001)),6)  
                self.sell_del_slope = round(self.sell_del_slope / np.log(1 + (update_time - self.sell_del_slope_last_update_time + 0.00001)),6)  
                self.buy_exec_slope = round(self.buy_exec_slope / np.log(1 + (update_time - self.buy_exec_slope_last_update_time + 0.00001)),6)  
                self.sell_exec_slope = round(self.sell_exec_slope / np.log(1 + (update_time - self.sell_exec_slope_last_update_time + 0.00001)),6)  

        #StrategyExecData
        if self.is_cont_trading:

            if self.first_exec:
                self.reset_time_bucket_based_variables(obj.price, obj.price, 60)
                self.first_exec = False

            if self.is_bucket_first_exec:
                self.is_bucket_first_exec = False
                self.cur_hi_lo.high = obj.price
                self.cur_hi_lo.low = obj.price

            self.buy_side_order_life = obj.nanos_from_epoch - max(self.beginning_of_day, self.order_book.buy_side[0].orders[0].nanos_from_epoch) if len(self.order_book.buy_side) > 0 else 0
            self.sell_side_order_life = obj.nanos_from_epoch - max(self.beginning_of_day, self.order_book.sell_side[0].orders[0].nanos_from_epoch) if len(self.order_book.sell_side) > 0 else 0
            self.order_life_last_exec_order = obj.nanos_from_epoch - max(self.beginning_of_day, self.order_book.entry_time_last_exec)
            
            side = 0
            side = int(1) if obj.side == 'B' else int(-1)

            self.snap_exec_qty = obj.shares * side

            if self.ewavg_px_10m > self.mid:
                self.obv1_10.update_value(round(np.power(obj.shares, 0.2), 3), obj.nanos_from_epoch)
            else:            
                self.obv1_10.update_value(-round(np.power(obj.shares, 0.2), 3), obj.nanos_from_epoch)

            if self.ewavg_px_30m > self.mid:
                self.obv1_30.update_value(round(np.power(obj.shares, 0.2), 3), obj.nanos_from_epoch)
            else:            
                self.obv1_30.update_value(-round(np.power(obj.shares, 0.2), 3), obj.nanos_from_epoch)
            
            if obj.price > self.cur_hi_lo.high:
                self.cur_hi_lo.high = obj.price
            if obj.price < self.cur_hi_lo.low:
                self.cur_hi_lo.low = obj.price
            
            if obj.price > self.high_1m:
                self.high_1m = obj.price
            if obj.price > self.high_3m:
                self.high_3m = obj.price
            if obj.price > self.high_10m:
                self.high_10m = obj.price
            if obj.price > self.high_30m:
                self.high_30m = obj.price
            if obj.price > self.high_day:
                self.high_day = obj.price

            if obj.price < self.low_1m:
                self.low_1m = obj.price
            if obj.price < self.low_3m:
                self.low_3m = obj.price
            if obj.price < self.low_10m:
                self.low_10m = obj.price
            if obj.price < self.low_30m:
                self.low_30m = obj.price
            if obj.price < self.low_day:
                self.low_day = obj.price

            self.dm_p1.update_value(self.high_day - self.high_1m, obj.nanos_from_epoch)
            self.dm_n1.update_value(self.low_1m - self.low_day, obj.nanos_from_epoch)
            self.dm_p10.update_value(self.high_day - self.high_10m, obj.nanos_from_epoch)
            self.dm_n10.update_value(self.low_10m - self.low_day, obj.nanos_from_epoch)

            self.high_low_sum.update_value(self.high_day - self.low_day, obj.nanos_from_epoch)

            self.di_p1 = self.dm_p1.get_last_value() / self.high_low_sum.get_last_value() if self.high_low_sum.get_last_value() != 0 else 0
            self.di_n1 = self.dm_n1.get_last_value() / self.high_low_sum.get_last_value() if self.high_low_sum.get_last_value() != 0 else 0
            self.di_p10 = self.dm_p10.get_last_value() / self.high_low_sum.get_last_value() if self.high_low_sum.get_last_value() != 0 else 0
            self.di_n10 = self.dm_n10.get_last_value() / self.high_low_sum.get_last_value() if self.high_low_sum.get_last_value() != 0 else 0

            self.di1_ratio = (self.di_p1 - self.di_n1) / (self.di_p1 + self.di_n1) if (self.di_p1 + self.di_n1) != 0 else 0
            self.di10_ratio = (self.di_p10 - self.di_n10) / (self.di_p10 + self.di_n10) if (self.di_p10 + self.di_n10) != 0 else 0

            if self.ewavg_px_30m > self.ewavg_px_1m:
                self.di1_ratio *= -1
            
            if self.ewavg_px_30m > self.ewavg_px_1m:
                self.di10_ratio *= -1
        
    # end of method on_execute()

    def on_trade(self, obj: Trade):
        if self.first_exec:
            self.opening_price = obj.trade_price
        if self.last_exec:
            self.closing_price = obj.trade_price


    def update_add_top_px(self, add: Add):
        update_time = round( (add.nanos_from_epoch - self.beginning_nanos_epoch)/1000,0)
        update_time_log = np.power(update_time + 0.01, 1/3)

        if add.side == 'B':
            self.ewavg_buy_add_qty_10s.update_value(add.shares, update_time)   
            self.ewavg_buy_add_px_qty_10s.update_value(add.price * add.shares, update_time) 
            self.e_buy_add_px_10s = self.ewavg_buy_add_px_qty_10s.get_last_value() / self.ewavg_buy_add_qty_10s.get_last_value()
            self.ewavg_buy_add_time_10s.update_value(update_time_log, update_time)
            self.ewavg_buy_add_px_10s.update_value(self.e_buy_add_px_10s, update_time)
            self.ewavg_buy_add_time_px_10s.update_value(update_time_log * self.e_buy_add_px_10s, update_time)
            self.ewavg_buy_add_time_sq_10s.update_value(np.square(update_time_log), update_time)
            self.ewavg_buy_add_px_sq_10s.update_value(self.e_buy_add_px_10s * self.e_buy_add_px_10s, update_time)
            self.ewavg_buy_add_cnt_10s.update_value(1, update_time)
            self.buy_add_slope = (
                ( (self.ewavg_buy_add_cnt_10s.get_last_value() * self.ewavg_buy_add_time_px_10s.get_last_value())
                - (self.ewavg_buy_add_time_10s.get_last_value() * self.ewavg_buy_add_px_10s.get_last_value()) )
                / (self.ewavg_buy_add_cnt_10s.get_last_value() * self.ewavg_buy_add_time_sq_10s.get_last_value() 
                - (self.ewavg_buy_add_time_10s.get_last_value() ** 2) + 0.00001 ) * 10e3)

            self.buy_add_slope = self.ewavg_buy_add_qty_10s.get_last_value() / np.sqrt((update_time - self.buy_add_slope_last_update_time + 0.0001))
            self.buy_add_slope_last_update_time = update_time
        else:
            self.ewavg_sell_add_qty_10s.update_value(add.shares, update_time)   
            self.ewavg_sell_add_px_qty_10s.update_value(add.price * add.shares, update_time) 
            self.e_sell_add_px_10s = self.ewavg_sell_add_px_qty_10s.get_last_value() / self.ewavg_sell_add_qty_10s.get_last_value()
            self.ewavg_sell_add_time_10s.update_value(update_time_log, update_time)
            self.ewavg_sell_add_px_10s.update_value(self.e_sell_add_px_10s, update_time)
            self.ewavg_sell_add_time_px_10s.update_value(update_time_log * self.e_sell_add_px_10s, update_time)
            self.ewavg_sell_add_time_sq_10s.update_value(np.square(update_time_log), update_time)
            self.ewavg_sell_add_px_sq_10s.update_value(self.e_sell_add_px_10s * self.e_sell_add_px_10s, update_time)
            self.ewavg_sell_add_cnt_10s.update_value(1, update_time)

            self.sell_add_slope = (
                ( (self.ewavg_sell_add_cnt_10s.get_last_value() * self.ewavg_sell_add_time_px_10s.get_last_value())
                - (self.ewavg_sell_add_time_10s.get_last_value() * self.ewavg_sell_add_px_10s.get_last_value()) )
                / (self.ewavg_sell_add_cnt_10s.get_last_value() * self.ewavg_sell_add_time_sq_10s.get_last_value()
                - (self.ewavg_sell_add_time_10s.get_last_value() ** 2) + 0.00001)  * 10e3)

            self.sell_add_slope = self.ewavg_sell_add_qty_10s.get_last_value() / np.sqrt((update_time - self.sell_add_slope_last_update_time + 0.0001))
            self.sell_add_slope_last_update_time = update_time

    def update_del_top_px(self, delete: Delete):
        update_time = round( (delete.nanos_from_epoch - self.beginning_nanos_epoch)/1000,0)
        update_time_log = np.power(update_time + 0.01, 1/3)
        
        if delete.side == 'B':
            self.ewavg_buy_del_qty_10s.update_value(delete.shares, update_time)   
            self.ewavg_buy_del_px_qty_10s.update_value(delete.price * delete.shares, update_time) 
            self.e_buy_del_px_10s = self.ewavg_buy_del_px_qty_10s.get_last_value() / self.ewavg_buy_del_qty_10s.get_last_value()
            self.ewavg_buy_del_time_10s.update_value(update_time_log, update_time)
            self.ewavg_buy_del_px_10s.update_value(self.e_buy_del_px_10s, update_time)
            self.ewavg_buy_del_time_px_10s.update_value(update_time_log * self.e_buy_del_px_10s, update_time)
            self.ewavg_buy_del_time_sq_10s.update_value(np.square(update_time_log), update_time)
            self.ewavg_buy_del_px_sq_10s.update_value(self.e_buy_del_px_10s * self.e_buy_del_px_10s, update_time)
            self.ewavg_buy_del_cnt_10s.update_value(1, update_time)

            self.buy_del_slope = (
                ( (self.ewavg_buy_del_cnt_10s.get_last_value() * self.ewavg_buy_del_time_px_10s.get_last_value()) 
                - (self.ewavg_buy_del_time_10s.get_last_value() * self.ewavg_buy_del_px_10s.get_last_value()) )
                / (self.ewavg_buy_del_cnt_10s.get_last_value() * self.ewavg_buy_del_time_sq_10s.get_last_value() 
                - (self.ewavg_buy_del_time_10s.get_last_value() ** 2) + 0.00001 ) * 10e3)

            self.buy_del_slope = self.ewavg_buy_del_qty_10s.get_last_value() / np.sqrt(update_time - self.buy_del_slope_last_update_time + 0.0001)           
            self.buy_del_slope_last_update_time = update_time
        else:
            self.ewavg_sell_del_qty_10s.update_value(delete.shares, update_time)   
            self.ewavg_sell_del_px_qty_10s.update_value(delete.price*delete.shares, update_time) 
            self.e_sell_del_px_10s = self.ewavg_sell_del_px_qty_10s.get_last_value() / self.ewavg_sell_del_qty_10s.get_last_value()
            self.ewavg_sell_del_time_10s.update_value(update_time_log, update_time)
            self.ewavg_sell_del_px_10s.update_value(self.e_sell_del_px_10s, update_time)
            self.ewavg_sell_del_time_px_10s.update_value(update_time_log * self.e_sell_del_px_10s, update_time)
            self.ewavg_sell_del_time_sq_10s.update_value(np.square(update_time_log), update_time)
            self.ewavg_sell_del_px_sq_10s.update_value(self.e_sell_del_px_10s * self.e_sell_del_px_10s, update_time)
            self.ewavg_sell_del_cnt_10s.update_value(1, update_time)

            self.sell_del_slope = (
                ( (self.ewavg_sell_del_cnt_10s.get_last_value() * self.ewavg_sell_del_time_px_10s.get_last_value()) 
                - (self.ewavg_sell_del_time_10s.get_last_value() * self.ewavg_sell_del_px_10s.get_last_value()) )
                / (self.ewavg_sell_del_cnt_10s.get_last_value() * self.ewavg_sell_del_time_sq_10s.get_last_value() 
                - (self.ewavg_sell_del_time_10s.get_last_value() ** 2) + 0.00001 ) * 10e3)

            self.sell_del_slope = self.ewavg_sell_del_qty_10s.get_last_value() / np.sqrt(update_time - self.sell_del_slope_last_update_time + 0.0001)           
            self.sell_del_slope_last_update_time = update_time

    def update_exec_top_px(self, execute: Execute):
        
        update_time = round( (execute.nanos_from_epoch - self.beginning_nanos_epoch)/1000,0)
        update_time_log = np.power(update_time + 0.01, 1/3)
        if execute.side == 'B':
            self.ewavg_buy_exec_qty_30s.update_value(execute.shares, update_time)   
            self.ewavg_buy_exec_px_qty_30s.update_value(execute.price*execute.shares, update_time) 
            self.e_buy_exec_px_30s = self.ewavg_buy_exec_px_qty_30s.get_last_value() / self.ewavg_buy_exec_qty_30s.get_last_value()
            self.ewavg_buy_exec_time_30s.update_value(update_time_log, update_time)
            self.ewavg_buy_exec_px_30s.update_value(self.e_buy_exec_px_30s, update_time)
            self.ewavg_buy_exec_time_px_30s.update_value(update_time_log * self.e_buy_exec_px_30s, update_time)
            self.ewavg_buy_exec_time_sq_30s.update_value(np.square(update_time_log), update_time)
            self.ewavg_buy_exec_px_sq_30s.update_value(self.e_buy_exec_px_30s * self.e_buy_exec_px_30s, update_time)
            self.ewavg_buy_exec_cnt_30s.update_value(1, update_time)

            self.buy_exec_slope = ( 
                ( (self.ewavg_buy_exec_cnt_30s.get_last_value() * self.ewavg_buy_exec_time_px_30s.get_last_value()) 
                - (self.ewavg_buy_exec_time_30s.get_last_value() * self.ewavg_buy_exec_px_30s.get_last_value()) )
                / (self.ewavg_buy_exec_cnt_30s.get_last_value() * self.ewavg_buy_exec_time_sq_30s.get_last_value() 
                - (self.ewavg_buy_exec_time_30s.get_last_value() ** 2) + 0.00001) * 10e3)

            self.buy_exec_slope = self.ewavg_buy_exec_qty_30s.get_last_value() / np.sqrt((update_time - self.buy_exec_slope_last_update_time + 0.0001))                      
            self.buy_exec_slope_last_update_time = update_time
        else:
            self.ewavg_sell_exec_qty_30s.update_value(execute.shares, update_time)   
            self.ewavg_sell_exec_px_qty_30s.update_value(execute.price*execute.shares, update_time) 
            self.e_sell_exec_px_30s = self.ewavg_sell_exec_px_qty_30s.get_last_value() / self.ewavg_sell_exec_qty_30s.get_last_value()
            self.ewavg_sell_exec_time_30s.update_value(update_time_log, update_time)
            self.ewavg_sell_exec_px_30s.update_value(self.e_sell_exec_px_30s, update_time)
            self.ewavg_sell_exec_time_px_30s.update_value(update_time_log * self.e_sell_exec_px_30s, update_time)
            self.ewavg_sell_exec_time_sq_30s.update_value(np.square(update_time_log), update_time)
            self.ewavg_sell_exec_px_sq_30s.update_value(self.e_sell_exec_px_30s * self.e_sell_exec_px_30s, update_time)
            self.ewavg_sell_exec_cnt_30s.update_value(1, update_time)

            self.sell_exec_slope = (
                ( (self.ewavg_sell_exec_cnt_30s.get_last_value() * self.ewavg_sell_exec_time_px_30s.get_last_value()) 
                - (self.ewavg_sell_exec_time_30s.get_last_value() * self.ewavg_sell_exec_px_30s.get_last_value()) )
                / (self.ewavg_sell_exec_cnt_30s.get_last_value() * self.ewavg_sell_exec_time_sq_30s.get_last_value() 
                - (self.ewavg_sell_exec_time_30s.get_last_value() ** 2) + 0.00001 ) * 10e3)

            self.sell_exec_slope = self.ewavg_sell_exec_qty_30s.get_last_value() / np.sqrt((update_time - self.sell_exec_slope_last_update_time + 0.0001))                      
            self.sell_exec_slope_last_update_time = update_time

    def get_yest_close(self):
        print('@get_yest_close', self.kind, self.date)
        return db.equity_derivative.get_data_by_order_book_id_day_index( 
            order_book_id=self.order_book_id, 
            date=get_formatted_date(self.date), 
            fields=['CLOSING_PRICE'],
            data_type=self.kind,
            day_index_list=[-1]
        )['CLOSING_PRICE'][0]


    def get_beta(self):

        if self.kind == 'Bist_Equity':
            print('@get_beta', self.date, self.kind)
            beta = db.beta.get_beta_by_order_book_id(
                    first_date = get_formatted_date(self.date), 
                    second_date = get_formatted_date(self.date), 
                    order_book_id_list = [self.order_book_id])['BETA'][0]
        
        elif self.kind == 'Bist_Derivative':
            beta = None 

        return beta


    def on_state(self, state: State):

        self.state_name = state.state_name

        if self.state_name in ['P_SUREKLI_ISLEM', 'VIOP_SUREKLI_MZYD', 'VIOP_AS_SUREKLI_MZYD']:
            self.is_cont_trading = True
        else:
            self.is_cont_trading = False

        if self.state_name in ['P_KAPANIS_EMIR_TPL']:
            self.last_exec =True

        if state.state_name in ['P_SUREKLI_ISLEM'] and self.first_exec:
            self.beginning_nanos_epoch = state.nanos_from_epoch


    def on_seconds(self, seconds: Seconds):
        self.last_second_from_epoch = seconds.seconds_from_epoch

        nanos_from_epoch = seconds.nanos_from_epoch

        #StrategyExecData
        if self.is_cont_trading:

            self.counter_1m += 1

            if self.counter_1m == 60:
                
                self.is_bucket_first_exec = True
                
                self.counter_1m = 0
                self.hi_lo_1m.pop(0)
                self.hi_lo_1m.append(self.cur_hi_lo.copy())

                self.hi_lo_3m.pop(0)
                self.hi_lo_3m.append(self.cur_hi_lo.copy())

                self.hi_lo_10m.pop(0)
                self.hi_lo_10m.append(self.cur_hi_lo.copy())

                self.hi_lo_30m.pop(0)
                self.hi_lo_30m.append(self.cur_hi_lo.copy())

                # refresh high and low to drop old high lows
                self.high_1m   = max(hi_lo.high for hi_lo in self.hi_lo_1m)
                self.low_1m    = min(hi_lo.low for hi_lo in self.hi_lo_1m)
                self.high_3m   = max(hi_lo.high for hi_lo in self.hi_lo_3m)
                self.low_3m    = min(hi_lo.low for hi_lo in self.hi_lo_3m)
                self.high_10m  = max(hi_lo.high for hi_lo in self.hi_lo_10m)
                self.low_10m   = min(hi_lo.low for hi_lo in self.hi_lo_10m)
                self.high_30m  = max(hi_lo.high for hi_lo in self.hi_lo_30m)
                self.low_30m   = min(hi_lo.low for hi_lo in self.hi_lo_30m)

                self.cur_hi_lo.high = self.mid
                self.cur_hi_lo.low  = self.mid
                

        # StrategyTimeSensitiveData
        if self.is_cont_trading:
            if self.first_second:
                self.first_second=False
                print("it comes to first sec")
                self.buy_l1_px_prev = self.order_book.buy_side[0].price if 0 < len(self.order_book.buy_side) else None 
                self.buy_l2_px_prev = self.order_book.buy_side[1].price if 1 < len(self.order_book.buy_side) else None 
                self.buy_l3_px_prev = self.order_book.buy_side[2].price if 2 < len(self.order_book.buy_side) else None 
                self.buy_l4_px_prev = self.order_book.buy_side[3].price if 3 < len(self.order_book.buy_side) else None
                self.buy_l5_px_prev = self.order_book.buy_side[4].price if 4 < len(self.order_book.buy_side) else None
                self.buy_l6_px_prev = self.order_book.buy_side[5].price if 5 < len(self.order_book.buy_side) else None
                self.buy_l7_px_prev = self.order_book.buy_side[6].price if 6 < len(self.order_book.buy_side) else None
                self.buy_l8_px_prev = self.order_book.buy_side[7].price if 7 < len(self.order_book.buy_side) else None
                self.buy_l9_px_prev = self.order_book.buy_side[8].price if 8 < len(self.order_book.buy_side) else None
                self.buy_l10_px_prev = self.order_book.buy_side[9].price if 9 < len(self.order_book.buy_side) else None
                self.sell_l1_px_prev = self.order_book.sell_side[0].price if 0 < len(self.order_book.sell_side) else None
                self.sell_l2_px_prev = self.order_book.sell_side[1].price if 1 < len(self.order_book.sell_side) else None 
                self.sell_l3_px_prev = self.order_book.sell_side[2].price if 2 < len(self.order_book.sell_side) else None
                self.sell_l4_px_prev = self.order_book.sell_side[3].price if 3 < len(self.order_book.sell_side) else None
                self.sell_l5_px_prev = self.order_book.sell_side[4].price if 4 < len(self.order_book.sell_side) else None
                self.sell_l6_px_prev = self.order_book.sell_side[5].price if 5 < len(self.order_book.sell_side) else None
                self.sell_l7_px_prev = self.order_book.sell_side[6].price if 6 < len(self.order_book.sell_side) else None
                self.sell_l8_px_prev = self.order_book.sell_side[7].price if 7 < len(self.order_book.sell_side) else None
                self.sell_l9_px_prev = self.order_book.sell_side[8].price if 8 < len(self.order_book.sell_side) else None
                self.sell_l10_px_prev = self.order_book.sell_side[9].price if 9 < len(self.order_book.sell_side) else None
                self.buy_l1_shr_prev = self.order_book.buy_side[0].total_shares if 0 < len(self.order_book.buy_side) else None
                self.buy_l2_shr_prev = self.order_book.buy_side[1].total_shares if 1 < len(self.order_book.buy_side) else None
                self.buy_l3_shr_prev = self.order_book.buy_side[2].total_shares if 2 < len(self.order_book.buy_side) else None
                self.buy_l4_shr_prev = self.order_book.buy_side[3].total_shares if 3 < len(self.order_book.buy_side) else None
                self.buy_l5_shr_prev = self.order_book.buy_side[4].total_shares if 4 < len(self.order_book.buy_side) else None
                self.buy_l6_shr_prev = self.order_book.buy_side[5].total_shares if 5 < len(self.order_book.buy_side) else None
                self.buy_l7_shr_prev = self.order_book.buy_side[6].total_shares if 6 < len(self.order_book.buy_side) else None
                self.buy_l8_shr_prev = self.order_book.buy_side[7].total_shares if 7 < len(self.order_book.buy_side) else None
                self.buy_l9_shr_prev = self.order_book.buy_side[8].total_shares if 8 < len(self.order_book.buy_side) else None
                self.buy_l10_shr_prev = self.order_book.buy_side[9].total_shares if 9 < len(self.order_book.buy_side) else None
                self.sell_l1_shr_prev = self.order_book.sell_side[0].total_shares if 0 < len(self.order_book.sell_side) else None
                self.sell_l2_shr_prev = self.order_book.sell_side[1].total_shares if 1 < len(self.order_book.sell_side) else None
                self.sell_l3_shr_prev = self.order_book.sell_side[2].total_shares if 2 < len(self.order_book.sell_side) else None
                self.sell_l4_shr_prev = self.order_book.sell_side[3].total_shares if 3 < len(self.order_book.sell_side) else None
                self.sell_l5_shr_prev = self.order_book.sell_side[4].total_shares if 4 < len(self.order_book.sell_side) else None
                self.sell_l6_shr_prev = self.order_book.sell_side[5].total_shares if 5 < len(self.order_book.sell_side) else None
                self.sell_l7_shr_prev = self.order_book.sell_side[6].total_shares if 6 < len(self.order_book.sell_side) else None
                self.sell_l8_shr_prev = self.order_book.sell_side[7].total_shares if 7 < len(self.order_book.sell_side) else None
                self.sell_l9_shr_prev = self.order_book.sell_side[8].total_shares if 8 < len(self.order_book.sell_side) else None
                self.sell_l10_shr_prev = self.order_book.sell_side[9].total_shares if 9 < len(self.order_book.sell_side) else None
            
            self.buy_l1_px_diff = self.order_book.buy_side[0].price - self.buy_l1_px_prev if 0 < len(self.order_book.buy_side) and self.buy_l1_px_prev is not None else None 
            self.buy_l2_px_diff = self.order_book.buy_side[1].price - self.buy_l2_px_prev if 1 < len(self.order_book.buy_side) and self.buy_l2_px_prev is not None else None
            self.buy_l3_px_diff = self.order_book.buy_side[2].price - self.buy_l3_px_prev if 2 < len(self.order_book.buy_side) and self.buy_l3_px_prev is not None else None
            self.buy_l4_px_diff = self.order_book.buy_side[3].price - self.buy_l4_px_prev if 3 < len(self.order_book.buy_side) and self.buy_l4_px_prev is not None else None
            self.buy_l5_px_diff = self.order_book.buy_side[4].price - self.buy_l5_px_prev if 4 < len(self.order_book.buy_side) and self.buy_l5_px_prev is not None else None
            self.buy_l6_px_diff = self.order_book.buy_side[5].price - self.buy_l6_px_prev if 5 < len(self.order_book.buy_side) and self.buy_l6_px_prev is not None else None
            self.buy_l7_px_diff = self.order_book.buy_side[6].price - self.buy_l7_px_prev if 6 < len(self.order_book.buy_side) and self.buy_l7_px_prev is not None else None
            self.buy_l8_px_diff = self.order_book.buy_side[7].price - self.buy_l8_px_prev if 7 < len(self.order_book.buy_side) and self.buy_l8_px_prev is not None else None
            self.buy_l9_px_diff = self.order_book.buy_side[8].price - self.buy_l9_px_prev if 8 < len(self.order_book.buy_side) and self.buy_l9_px_prev is not None else None
            self.buy_l10_px_diff = self.order_book.buy_side[9].price - self.buy_l10_px_prev if 9 < len(self.order_book.buy_side) and self.buy_l10_px_prev is not None else None
            self.sell_l1_px_diff = self.order_book.sell_side[0].price - self.sell_l1_px_prev if 0 < len(self.order_book.sell_side) and self.sell_l1_px_prev is not None else None
            self.sell_l2_px_diff = self.order_book.sell_side[1].price - self.sell_l2_px_prev if 1 < len(self.order_book.sell_side) and self.sell_l2_px_prev is not None else None
            self.sell_l3_px_diff = self.order_book.sell_side[2].price - self.sell_l3_px_prev if 2 < len(self.order_book.sell_side) and self.sell_l3_px_prev is not None else None
            self.sell_l4_px_diff = self.order_book.sell_side[3].price - self.sell_l4_px_prev if 3 < len(self.order_book.sell_side) and self.sell_l4_px_prev is not None else None
            self.sell_l5_px_diff = self.order_book.sell_side[4].price - self.sell_l5_px_prev if 4 < len(self.order_book.sell_side) and self.sell_l5_px_prev is not None else None
            self.sell_l6_px_diff = self.order_book.sell_side[5].price - self.sell_l6_px_prev if 5 < len(self.order_book.sell_side) and self.sell_l6_px_prev is not None else None
            self.sell_l7_px_diff = self.order_book.sell_side[6].price - self.sell_l7_px_prev if 6 < len(self.order_book.sell_side) and self.sell_l7_px_prev is not None else None
            self.sell_l8_px_diff = self.order_book.sell_side[7].price - self.sell_l8_px_prev if 7 < len(self.order_book.sell_side) and self.sell_l8_px_prev is not None else None
            self.sell_l9_px_diff = self.order_book.sell_side[8].price - self.sell_l9_px_prev if 8 < len(self.order_book.sell_side) and self.sell_l9_px_prev is not None else None
            self.sell_l10_px_diff = self.order_book.sell_side[9].price - self.sell_l10_px_prev if 9 < len(self.order_book.sell_side) and self.sell_l10_px_prev is not None else None

            self.buy_l1_px_prev = self.order_book.buy_side[0].price if 0 < len(self.order_book.buy_side) else None
            self.buy_l2_px_prev = self.order_book.buy_side[1].price if 1 < len(self.order_book.buy_side) else None
            self.buy_l3_px_prev = self.order_book.buy_side[2].price if 2 < len(self.order_book.buy_side) else None
            self.buy_l4_px_prev = self.order_book.buy_side[3].price if 3 < len(self.order_book.buy_side) else None
            self.buy_l5_px_prev = self.order_book.buy_side[4].price if 4 < len(self.order_book.buy_side) else None
            self.buy_l6_px_prev = self.order_book.buy_side[5].price if 5 < len(self.order_book.buy_side) else None
            self.buy_l7_px_prev = self.order_book.buy_side[6].price if 6 < len(self.order_book.buy_side) else None
            self.buy_l8_px_prev = self.order_book.buy_side[7].price if 7 < len(self.order_book.buy_side) else None
            self.buy_l9_px_prev = self.order_book.buy_side[8].price if 8 < len(self.order_book.buy_side) else None
            self.buy_l10_px_prev = self.order_book.buy_side[9].price if 9 < len(self.order_book.buy_side) else None
            self.sell_l1_px_prev = self.order_book.sell_side[0].price if 0 < len(self.order_book.sell_side) else None
            self.sell_l2_px_prev = self.order_book.sell_side[1].price if 1 < len(self.order_book.sell_side) else None
            self.sell_l3_px_prev = self.order_book.sell_side[2].price if 2 < len(self.order_book.sell_side) else None
            self.sell_l4_px_prev = self.order_book.sell_side[3].price if 3 < len(self.order_book.sell_side) else None
            self.sell_l5_px_prev = self.order_book.sell_side[4].price if 4 < len(self.order_book.sell_side) else None
            self.sell_l6_px_prev = self.order_book.sell_side[5].price if 5 < len(self.order_book.sell_side) else None
            self.sell_l7_px_prev = self.order_book.sell_side[6].price if 6 < len(self.order_book.sell_side) else None
            self.sell_l8_px_prev = self.order_book.sell_side[7].price if 7 < len(self.order_book.sell_side) else None
            self.sell_l9_px_prev = self.order_book.sell_side[8].price if 8 < len(self.order_book.sell_side) else None
            self.sell_l10_px_prev = self.order_book.sell_side[9].price if 9 < len(self.order_book.sell_side) else None

            self.buy_l1_shr_diff = self.order_book.buy_side[0].total_shares - self.buy_l1_shr_prev if 0 < len(self.order_book.buy_side) and self.buy_l1_shr_prev is not None else None
            self.buy_l2_shr_diff = self.order_book.buy_side[1].total_shares - self.buy_l2_shr_prev if 1 < len(self.order_book.buy_side) and self.buy_l2_shr_prev is not None else None
            self.buy_l3_shr_diff = self.order_book.buy_side[2].total_shares - self.buy_l3_shr_prev if 2 < len(self.order_book.buy_side) and self.buy_l3_shr_prev is not None else None
            self.buy_l4_shr_diff = self.order_book.buy_side[3].total_shares - self.buy_l4_shr_prev if 3 < len(self.order_book.buy_side) and self.buy_l4_shr_prev is not None else None
            self.buy_l5_shr_diff = self.order_book.buy_side[4].total_shares - self.buy_l5_shr_prev if 4 < len(self.order_book.buy_side) and self.buy_l5_shr_prev is not None else None
            self.buy_l6_shr_diff = self.order_book.buy_side[5].total_shares - self.buy_l6_shr_prev if 5 < len(self.order_book.buy_side) and self.buy_l6_shr_prev is not None else None
            self.buy_l7_shr_diff = self.order_book.buy_side[6].total_shares - self.buy_l7_shr_prev if 6 < len(self.order_book.buy_side) and self.buy_l7_shr_prev is not None else None
            self.buy_l8_shr_diff = self.order_book.buy_side[7].total_shares - self.buy_l8_shr_prev if 7 < len(self.order_book.buy_side) and self.buy_l8_shr_prev is not None else None
            self.buy_l9_shr_diff = self.order_book.buy_side[8].total_shares - self.buy_l9_shr_prev if 8 < len(self.order_book.buy_side) and self.buy_l9_shr_prev is not None else None
            self.buy_l10_shr_diff = self.order_book.buy_side[9].total_shares - self.buy_l10_shr_prev if 9 < len(self.order_book.buy_side) and self.buy_l10_shr_prev is not None else None
            self.sell_l1_shr_diff = self.order_book.sell_side[0].total_shares - self.sell_l1_shr_prev if 0 < len(self.order_book.sell_side) and self.sell_l1_shr_prev is not None else None
            self.sell_l2_shr_diff = self.order_book.sell_side[1].total_shares - self.sell_l2_shr_prev if 1 < len(self.order_book.sell_side) and self.sell_l2_shr_prev is not None else None
            self.sell_l3_shr_diff = self.order_book.sell_side[2].total_shares - self.sell_l3_shr_prev if 2 < len(self.order_book.sell_side) and self.sell_l3_shr_prev is not None else None
            self.sell_l4_shr_diff = self.order_book.sell_side[3].total_shares - self.sell_l4_shr_prev if 3 < len(self.order_book.sell_side) and self.sell_l4_shr_prev is not None else None
            self.sell_l5_shr_diff = self.order_book.sell_side[4].total_shares - self.sell_l5_shr_prev if 4 < len(self.order_book.sell_side) and self.sell_l5_shr_prev is not None else None
            self.sell_l6_shr_diff = self.order_book.sell_side[5].total_shares - self.sell_l6_shr_prev if 5 < len(self.order_book.sell_side) and self.sell_l6_shr_prev is not None else None
            self.sell_l7_shr_diff = self.order_book.sell_side[6].total_shares - self.sell_l7_shr_prev if 6 < len(self.order_book.sell_side) and self.sell_l7_shr_prev is not None else None
            self.sell_l8_shr_diff = self.order_book.sell_side[7].total_shares - self.sell_l8_shr_prev if 7 < len(self.order_book.sell_side) and self.sell_l8_shr_prev is not None else None
            self.sell_l9_shr_diff = self.order_book.sell_side[8].total_shares - self.sell_l9_shr_prev if 8 < len(self.order_book.sell_side) and self.sell_l9_shr_prev is not None else None
            self.sell_l10_shr_diff = self.order_book.sell_side[9].total_shares - self.sell_l10_shr_prev if 9 < len(self.order_book.sell_side) and self.sell_l10_shr_prev is not None else None

            self.buy_l1_shr_prev = self.order_book.buy_side[0].total_shares if 0 < len(self.order_book.buy_side) else None
            self.buy_l2_shr_prev = self.order_book.buy_side[1].total_shares if 1 < len(self.order_book.buy_side) else None
            self.buy_l3_shr_prev = self.order_book.buy_side[2].total_shares if 2 < len(self.order_book.buy_side) else None
            self.buy_l4_shr_prev = self.order_book.buy_side[3].total_shares if 3 < len(self.order_book.buy_side) else None
            self.buy_l5_shr_prev = self.order_book.buy_side[4].total_shares if 4 < len(self.order_book.buy_side) else None
            self.buy_l6_shr_prev = self.order_book.buy_side[5].total_shares if 5 < len(self.order_book.buy_side) else None
            self.buy_l7_shr_prev = self.order_book.buy_side[6].total_shares if 6 < len(self.order_book.buy_side) else None
            self.buy_l8_shr_prev = self.order_book.buy_side[7].total_shares if 7 < len(self.order_book.buy_side) else None
            self.buy_l9_shr_prev = self.order_book.buy_side[8].total_shares if 8 < len(self.order_book.buy_side) else None
            self.buy_l10_shr_prev = self.order_book.buy_side[9].total_shares if 9 < len(self.order_book.buy_side) else None
            self.sell_l1_shr_prev = self.order_book.sell_side[0].total_shares if 0 < len(self.order_book.sell_side) else None
            self.sell_l2_shr_prev = self.order_book.sell_side[1].total_shares if 1 < len(self.order_book.sell_side) else None
            self.sell_l3_shr_prev = self.order_book.sell_side[2].total_shares if 2 < len(self.order_book.sell_side) else None
            self.sell_l4_shr_prev = self.order_book.sell_side[3].total_shares if 3 < len(self.order_book.sell_side) else None
            self.sell_l5_shr_prev = self.order_book.sell_side[4].total_shares if 4 < len(self.order_book.sell_side) else None
            self.sell_l6_shr_prev = self.order_book.sell_side[5].total_shares if 5 < len(self.order_book.sell_side) else None
            self.sell_l7_shr_prev = self.order_book.sell_side[6].total_shares if 6 < len(self.order_book.sell_side) else None
            self.sell_l8_shr_prev = self.order_book.sell_side[7].total_shares if 7 < len(self.order_book.sell_side) else None
            self.sell_l9_shr_prev = self.order_book.sell_side[8].total_shares if 8 < len(self.order_book.sell_side) else None
            self.sell_l10_shr_prev = self.order_book.sell_side[9].total_shares if 9 < len(self.order_book.sell_side) else None

            self.buy_add_1s_prev = self.buy_add_1s_now
            self.buy_add_3s_prev = self.buy_add_3s_now
            self.sell_add_1s_prev = self.sell_add_1s_now
            self.sell_add_3s_prev = self.sell_add_3s_now

            self.buy_del_1s_prev = self.buy_del_1s_now
            self.buy_del_3s_prev = self.buy_del_3s_now
            self.sell_del_1s_prev = self.sell_del_1s_now
            self.sell_del_3s_prev = self.sell_del_3s_now

            self.buy_exec_1s_prev = self.buy_exec_1s_now
            self.buy_exec_3s_prev = self.buy_exec_3s_now
            self.sell_exec_1s_prev = self.sell_exec_1s_now
            self.sell_exec_3s_prev = self.sell_exec_3s_now

            self.buy_add_1s_now = self.buy_add_1s.get_last_value_decayed(nanos_from_epoch)
            self.buy_add_3s_now = self.buy_add_3s.get_last_value_decayed(nanos_from_epoch)  
            self.sell_add_1s_now = self.sell_add_1s.get_last_value_decayed(nanos_from_epoch)
            self.sell_add_3s_now = self.sell_add_3s.get_last_value_decayed(nanos_from_epoch)   

            self.buy_del_1s_now = self.buy_del_1s.get_last_value_decayed(nanos_from_epoch)
            self.buy_del_3s_now = self.buy_del_3s.get_last_value_decayed(nanos_from_epoch)   
            self.sell_del_1s_now = self.sell_del_1s.get_last_value_decayed(nanos_from_epoch)
            self.sell_del_3s_now = self.sell_del_3s.get_last_value_decayed(nanos_from_epoch) 

            self.buy_exec_1s_now = self.buy_exec_1s.get_last_value_decayed(nanos_from_epoch)
            self.buy_exec_3s_now = self.buy_exec_3s.get_last_value_decayed(nanos_from_epoch)   
            self.sell_exec_1s_now = self.sell_exec_1s.get_last_value_decayed(nanos_from_epoch)
            self.sell_exec_3s_now = self.sell_exec_3s.get_last_value_decayed(nanos_from_epoch) 

            self.buy_add_list_1s_prev = self.buy_add_list_1s_now
            self.buy_add_list_1s_now = len(self.buy_add_list_1s)
            self.sell_add_list_1s_prev = self.sell_add_list_1s_now
            self.sell_add_list_1s_now = len(self.sell_add_list_1s)

            self.buy_del_list_1s_prev = self.buy_del_list_1s_now
            self.buy_del_list_1s_now = len(self.buy_del_list_1s)
            self.sell_del_list_1s_prev = self.sell_del_list_1s_now
            self.sell_del_list_1s_now = len(self.sell_del_list_1s)

            self.buy_exec_list_1s_prev = self.buy_exec_list_1s_now
            self.buy_exec_list_1s_now = len(self.buy_exec_list_1s)
            self.sell_exec_list_1s_prev = self.sell_exec_list_1s_now
            self.sell_exec_list_1s_now = len(self.sell_exec_list_1s)

    def get_snapshot(self, nanos_from_epoch):

        update_time = round( (nanos_from_epoch - self.beginning_nanos_epoch) / 1000, 0)

        variables = {  
            'time_exec_prev': self.time_exec_prev,
            'time_exec_cur': self.time_exec_cur,
            'entry_time_last_exec': self.order_book.entry_time_last_exec,
            'closing_price': self.closing_price,
            'is_cont_trading': self.is_cont_trading,
            'nanos_from_epoch': self.nanos_from_epoch,
            'last_second_from_epoch': self.last_second_from_epoch,
            'beta': self.beta,
            'w_eavg_px_10s': self.ewavg_px_10s,
            'w_eavg_px_1m': self.ewavg_px_1m,
            'w_eavg_px_3m': self.ewavg_px_3m,
            'w_eavg_px_10m': self.ewavg_px_10m,
            'w_eavg_px_30m': self.ewavg_px_30m,
            'w_eavg_px_10s_adj': self.ewavg_px_10s_adj,
            'w_eavg_px_1m_adj': self.ewavg_px_1m_adj,
            'w_eavg_px_3m_adj': self.ewavg_px_3m_adj,
            'w_eavg_px_10m_adj': self.ewavg_px_10m_adj,
            'w_eavg_px_30m_adj': self.ewavg_px_30m_adj,
            'day_w_px': self.day_w_px,
            'day_w_px_adj': self.day_w_px_adj,
            'day_buy_notional': self.day_buy_notional,
            'day_sell_notional': self.day_sell_notional,
            'day_qty': self.day_qty,
            'day_buy_qty': self.day_buy_qty,
            'day_sell_qty': self.day_sell_qty,
            'snap_exec_qty': self.snap_exec_qty,
            'order_life_last_exec_order': self.order_life_last_exec_order,
            'high_day': self.high_day,
            'low_day': self.low_day,
            'high_1m': self.high_1m,
            'low_1m': self.low_1m,
            'high_3m': self.high_3m,
            'low_3m': self.low_3m,
            'high_10m': self.high_10m,
            'low_10m': self.low_10m,
            'high_30m': self.high_30m,
            'low_30m': self.low_30m,
            'buy_side_order_life': self.buy_side_order_life,
            'sell_side_order_life': self.sell_side_order_life,
            'di1_ratio': self.di1_ratio, 
            'di10_ratio': self.di10_ratio, 
            'di_p1': self.di_p1,
            'di_n1': self.di_n1, 
            'di_p10': self.di_p10,
            'di_n10': self.di_n10,
            'buy_add_1s_prev': self.buy_add_1s_prev,
            'buy_add_1s_now': self.buy_add_1s_now,
            'buy_add_3s_prev': self.buy_add_3s_prev,
            'buy_add_3s_now': self.buy_add_3s_now, 
            'sell_add_1s_prev': self.sell_add_1s_prev,
            'sell_add_1s_now': self.sell_add_1s_now,
            'sell_add_3s_prev': self.sell_add_3s_prev,
            'sell_add_3s_now': self.sell_add_3s_now,
            'buy_del_1s_prev': self.buy_del_1s_prev,
            'buy_del_1s_now': self.buy_del_1s_now,
            'buy_del_3s_prev': self.buy_del_3s_prev,
            'buy_del_3s_now': self.buy_del_3s_now, 
            'sell_del_1s_prev': self.sell_del_1s_prev,
            'sell_del_1s_now': self.sell_del_1s_now,
            'sell_del_3s_prev': self.sell_del_3s_prev,
            'sell_del_3s_now': self.sell_del_3s_now,
            'buy_exec_1s_prev': self.buy_exec_1s_prev,
            'buy_exec_1s_now': self.buy_exec_1s_now,
            'buy_exec_3s_prev': self.buy_exec_3s_prev,
            'buy_exec_3s_now': self.buy_exec_3s_now,
            'sell_exec_1s_prev': self.sell_exec_1s_prev,
            'sell_exec_1s_now': self.sell_exec_1s_now,
            'sell_exec_3s_prev': self.sell_exec_3s_prev,
            'sell_exec_3s_now': self.sell_exec_3s_now,
            'buy_add_list_1s_prev': self.buy_add_list_1s_prev,
            'buy_add_list_1s_now': self.buy_add_list_1s_now,
            'sell_add_list_1s_prev': self.sell_add_list_1s_prev,
            'sell_add_list_1s_now': self.sell_add_list_1s_now,
            'buy_del_list_1s_prev': self.buy_del_list_1s_prev,
            'buy_del_list_1s_now': self.buy_del_list_1s_now,
            'sell_del_list_1s_prev': self.sell_del_list_1s_prev,
            'sell_del_list_1s_now': self.sell_del_list_1s_now,
            'buy_exec_list_1s_prev': self.buy_exec_list_1s_prev,
            'buy_exec_list_1s_now': self.buy_exec_list_1s_now,
            'sell_exec_list_1s_prev': self.sell_exec_list_1s_prev,
            'sell_exec_list_1s_now': self.sell_exec_list_1s_now,
            'e_buy_add_px_10s': self.e_buy_add_px_10s,
            'buy_add_slope': self.buy_add_slope,
            'e_sell_add_px_10s':  self.e_sell_add_px_10s,
            'sell_add_slope': self.sell_add_slope,
            'buy_l1_px_diff': self.buy_l1_px_diff,
            'buy_l2_px_diff': self.buy_l2_px_diff,
            'buy_l3_px_diff': self.buy_l3_px_diff,
            'buy_l4_px_diff': self.buy_l4_px_diff,
            'buy_l5_px_diff': self.buy_l5_px_diff,
            'buy_l6_px_diff': self.buy_l6_px_diff,
            'buy_l7_px_diff': self.buy_l7_px_diff,
            'buy_l8_px_diff': self.buy_l8_px_diff,
            'buy_l9_px_diff': self.buy_l9_px_diff,
            'buy_l10_px_diff': self.buy_l10_px_diff,
            'sell_l1_px_diff': self.sell_l1_px_diff,
            'sell_l2_px_diff': self.sell_l2_px_diff,
            'sell_l3_px_diff': self.sell_l3_px_diff,
            'sell_l4_px_diff': self.sell_l4_px_diff,
            'sell_l5_px_diff': self.sell_l5_px_diff,
            'sell_l6_px_diff': self.sell_l6_px_diff,
            'sell_l7_px_diff': self.sell_l7_px_diff,
            'sell_l8_px_diff': self.sell_l8_px_diff,
            'sell_l9_px_diff': self.sell_l9_px_diff,
            'sell_l10_px_diff': self.sell_l10_px_diff,
            'buy_l1_shr_diff': self.buy_l1_shr_diff,
            'buy_l2_shr_diff': self.buy_l2_shr_diff,
            'buy_l3_shr_diff': self.buy_l3_shr_diff,
            'buy_l4_shr_diff': self.buy_l4_shr_diff,
            'buy_l5_shr_diff': self.buy_l5_shr_diff,
            'buy_l6_shr_diff': self.buy_l6_shr_diff,
            'buy_l7_shr_diff': self.buy_l7_shr_diff,
            'buy_l8_shr_diff': self.buy_l8_shr_diff,
            'buy_l9_shr_diff': self.buy_l9_shr_diff,
            'buy_l10_shr_diff': self.buy_l10_shr_diff,
            'sell_l1_shr_diff': self.sell_l1_shr_diff,
            'sell_l2_shr_diff': self.sell_l2_shr_diff,
            'sell_l3_shr_diff': self.sell_l3_shr_diff,
            'sell_l4_shr_diff': self.sell_l4_shr_diff,
            'sell_l5_shr_diff': self.sell_l5_shr_diff,
            'sell_l6_shr_diff': self.sell_l6_shr_diff,
            'sell_l7_shr_diff': self.sell_l7_shr_diff,
            'sell_l8_shr_diff': self.sell_l8_shr_diff,
            'sell_l9_shr_diff': self.sell_l9_shr_diff,
            'sell_l10_shr_diff': self.sell_l10_shr_diff,
            'e_buy_del_px_10s': self.e_buy_del_px_10s,
            'buy_del_slope': self.buy_del_slope,
            'e_sell_del_px_10s': self.e_sell_del_px_10s,
            'sell_del_slope': self.sell_del_slope,
            'e_buy_exec_px_30s': self.e_buy_exec_px_30s,
            'buy_exec_slope': self.buy_exec_slope,
            'e_sell_exec_px_30s': self.e_sell_exec_px_30s,
            'sell_exec_slope': self.sell_exec_slope, 
            'obv1_10': self.obv1_10.get_last_value(),
            'obv1_30': self.obv1_30.get_last_value(),
            'dm_p1': self.dm_p1.get_last_value(),
            'dm_n1': self.dm_n1.get_last_value(),
            'high_low_sum': self.high_low_sum.get_last_value(),
            'dm_p10': self.dm_p10.get_last_value(),
            'dm_n10':self.dm_n10.get_last_value(),
            'eavg_val_spread': self.eavg_spread.get_last_value(),
            'eavg_val_px_10s': self.eavg_px_10s.get_last_value(),
            'eavg_val_px_1m': self.eavg_px_1m.get_last_value(),
            'eavg_val_px_3m': self.eavg_px_3m.get_last_value(),
            'eavg_val_px_10m': self.eavg_px_10m.get_last_value(),
            'eavg_val_px_10s_adj': self.eavg_px_10s_adj.get_last_value(),
            'eavg_val_px_1m_adj': self.eavg_px_1m_adj.get_last_value(),
            'eavg_val_px_3m_adj': self.eavg_px_3m_adj.get_last_value(),
            'eavg_val_px_10m_adj': self.eavg_px_10m_adj.get_last_value(),
            'w_eavg_qty_10s': self.ewavg_qty_10s.get_last_value(),
            'w_eavg_qty_1m': self.ewavg_qty_1m.get_last_value(),
            'w_eavg_qty_3m': self.ewavg_qty_3m.get_last_value(),
            'w_eavg_qty_10m': self.ewavg_qty_10m.get_last_value(),
            'w_eavg_qty_30m': self.ewavg_qty_30m.get_last_value(),
            'buy_exec_10s': self.buy_exec_10s.get_last_value(),
            'buy_exec_1m': self.buy_exec_1m.get_last_value(),
            'buy_exec_3m': self.buy_exec_3m.get_last_value(),
            'buy_exec_10m': self.buy_exec_10m.get_last_value(),
            'buy_exec_30m': self.buy_exec_30m.get_last_value(),
            'sell_exec_10s': self.sell_exec_10s.get_last_value(),
            'sell_exec_1m': self.sell_exec_1m.get_last_value(),
            'sell_exec_3m': self.sell_exec_3m.get_last_value(),
            'sell_exec_10m': self.sell_exec_10m.get_last_value(),
            'sell_exec_30m': self.sell_exec_30m.get_last_value(),
            'buy_add_sh_l1_10s': self.buy_add_sh_l1_10s.get_last_value(),
            'buy_add_sh_l1_1m': self.buy_add_sh_l1_1m.get_last_value(),
            'buy_add_sh_l1_3m': self.buy_add_sh_l1_3m.get_last_value(),
            'buy_add_sh_l1_10m': self.buy_add_sh_l1_10m.get_last_value(),
            'buy_add_cnt_l1_10s': self.buy_add_cnt_l1_10s.get_last_value(),
            'buy_add_cnt_l1_1m': self.buy_add_cnt_l1_1m.get_last_value(),
            'buy_add_cnt_l1_3m': self.buy_add_cnt_l1_3m.get_last_value(),
            'buy_add_cnt_l1_10m': self.buy_add_cnt_l1_10m.get_last_value(),
            'sell_add_sh_l1_10s': self.sell_add_sh_l1_10s.get_last_value(),
            'sell_add_sh_l1_1m': self.sell_add_sh_l1_1m.get_last_value(),
            'sell_add_sh_l1_3m': self.sell_add_sh_l1_3m.get_last_value(),
            'sell_add_sh_l1_10m': self.sell_add_sh_l1_10m.get_last_value(),
            'sell_add_cnt_l1_10s': self.sell_add_cnt_l1_10s.get_last_value(),
            'sell_add_cnt_l1_1m': self.sell_add_cnt_l1_1m.get_last_value(),
            'sell_add_cnt_l1_3m': self.sell_add_cnt_l1_3m.get_last_value(),
            'sell_add_cnt_l1_10m': self.sell_add_cnt_l1_10m.get_last_value(),
            'buy_add_sh_l2_10s': self.buy_add_sh_l2_10s.get_last_value(),
            'buy_add_sh_l2_1m': self.buy_add_sh_l2_1m.get_last_value(),
            'buy_add_sh_l2_3m': self.buy_add_sh_l2_3m.get_last_value(),
            'buy_add_sh_l2_10m': self.buy_add_sh_l2_10m.get_last_value(),
            'buy_add_cnt_l2_10s': self.buy_add_cnt_l2_10s.get_last_value(),
            'buy_add_cnt_l2_1m': self.buy_add_cnt_l2_1m.get_last_value(),
            'buy_add_cnt_l2_3m': self.buy_add_cnt_l2_3m.get_last_value(),
            'buy_add_cnt_l2_10m': self.buy_add_cnt_l2_10m.get_last_value(),
            'sell_add_sh_l2_10s': self.sell_add_sh_l2_10s.get_last_value(),
            'sell_add_sh_l2_1m': self.sell_add_sh_l2_1m.get_last_value(),
            'sell_add_sh_l2_3m': self.sell_add_sh_l2_3m.get_last_value(),
            'sell_add_sh_l2_10m': self.sell_add_sh_l2_10m.get_last_value(),
            'sell_add_cnt_l2_10s': self.sell_add_cnt_l2_10s.get_last_value(),
            'sell_add_cnt_l2_1m': self.sell_add_cnt_l2_1m.get_last_value(),
            'sell_add_cnt_l2_3m': self.sell_add_cnt_l2_3m.get_last_value(),
            'sell_add_cnt_l2_10m': self.sell_add_cnt_l2_10m.get_last_value(),
            'buy_delete_sh_l1_10s': self.buy_delete_sh_l1_10s.get_last_value(),
            'buy_delete_sh_l1_1m': self.buy_delete_sh_l1_1m.get_last_value(),
            'buy_delete_sh_l1_3m': self.buy_delete_sh_l1_3m.get_last_value(),
            'buy_delete_sh_l1_10m': self.buy_delete_sh_l1_10m.get_last_value(),
            'buy_delete_cnt_l1_10s': self.buy_delete_cnt_l1_10s.get_last_value(),
            'buy_delete_cnt_l1_1m': self.buy_delete_cnt_l1_1m.get_last_value(),
            'buy_delete_cnt_l1_3m': self.buy_delete_cnt_l1_3m.get_last_value(),
            'buy_delete_cnt_l1_10m': self.buy_delete_cnt_l1_10m.get_last_value(),
            'sell_delete_sh_l1_10s': self.sell_delete_sh_l1_10s.get_last_value(),
            'sell_delete_sh_l1_1m': self.sell_delete_sh_l1_1m.get_last_value(),
            'sell_delete_sh_l1_3m': self.sell_delete_sh_l1_3m.get_last_value(),
            'sell_delete_sh_l1_10m': self.sell_delete_sh_l1_10m.get_last_value(),
            'sell_delete_cnt_l1_10s': self.sell_delete_cnt_l1_10s.get_last_value(),
            'sell_delete_cnt_l1_1m': self.sell_delete_cnt_l1_1m.get_last_value(),
            'sell_delete_cnt_l1_3m': self.sell_delete_cnt_l1_3m.get_last_value(),
            'sell_delete_cnt_l1_10m': self.sell_delete_cnt_l1_10m.get_last_value(),
            'buy_delete_sh_l2_10s': self.buy_delete_sh_l2_10s.get_last_value(),
            'buy_delete_sh_l2_1m': self.buy_delete_sh_l2_1m.get_last_value(),
            'buy_delete_sh_l2_3m': self.buy_delete_sh_l2_3m.get_last_value(),
            'buy_delete_sh_l2_10m': self.buy_delete_sh_l2_10m.get_last_value(),
            'buy_delete_cnt_l2_10s': self.buy_delete_cnt_l2_10s.get_last_value(),
            'buy_delete_cnt_l2_1m': self.buy_delete_cnt_l2_1m.get_last_value(),
            'buy_delete_cnt_l2_3m': self.buy_delete_cnt_l2_3m.get_last_value(),
            'buy_delete_cnt_l2_10m': self.buy_delete_cnt_l2_10m.get_last_value(),
            'sell_delete_sh_l2_10s': self.sell_delete_sh_l2_10s.get_last_value(),
            'sell_delete_sh_l2_1m': self.sell_delete_sh_l2_1m.get_last_value(),
            'sell_delete_sh_l2_3m': self.sell_delete_sh_l2_3m.get_last_value(),
            'sell_delete_sh_l2_10m': self.sell_delete_sh_l2_10m.get_last_value(),
            'sell_delete_cnt_l2_10s': self.sell_delete_cnt_l2_10s.get_last_value(),
            'sell_delete_cnt_l2_1m': self.sell_delete_cnt_l2_1m.get_last_value(),
            'sell_delete_cnt_l2_3m': self.sell_delete_cnt_l2_3m.get_last_value(),
            'sell_delete_cnt_l2_10m': self.sell_delete_cnt_l2_10m.get_last_value(),
            'buy_add_1s': self.buy_add_1s.get_last_value_decayed(nanos_from_epoch), 
            'buy_add_3s': self.buy_add_3s.get_last_value_decayed(nanos_from_epoch), 
            'buy_add_10s': self.buy_add_10s.get_last_value_decayed(nanos_from_epoch), 
            'buy_add_90s': self.buy_add_90s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_1s': self.sell_add_1s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_3s': self.sell_add_3s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_10s': self.sell_add_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_90s': self.sell_add_90s.get_last_value_decayed(nanos_from_epoch),
            'buy_del_1s': self.buy_del_1s.get_last_value_decayed(nanos_from_epoch), 
            'buy_del_3s': self.buy_del_3s.get_last_value_decayed(nanos_from_epoch), 
            'buy_del_10s': self.buy_del_10s.get_last_value_decayed(nanos_from_epoch), 
            'buy_del_90s': self.buy_del_90s.get_last_value_decayed(nanos_from_epoch),
            'sell_del_1s': self.sell_del_1s.get_last_value_decayed(nanos_from_epoch),
            'sell_del_3s': self.sell_del_3s.get_last_value_decayed(nanos_from_epoch),
            'sell_del_10s': self.sell_del_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_del_90s': self.sell_del_90s.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_1s': self.buy_exec_1s.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_3s': self.buy_exec_3s.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_10s': self.buy_exec_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_90s': self.buy_exec_90s.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_1s': self.sell_exec_1s.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_3s': self.sell_exec_3s.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_10s': self.sell_exec_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_90s': self.sell_exec_90s.get_last_value_decayed(nanos_from_epoch),
            'ewavg_buy_add_qty_10s': self.ewavg_buy_add_qty_10s.get_last_value_decayed(update_time),
            'ewavg_buy_add_cnt_10s': self.ewavg_buy_add_cnt_10s.get_last_value_decayed(update_time),
            'ewavg_sell_add_qty_10s': self.ewavg_sell_add_qty_10s.get_last_value_decayed(update_time),
            'ewavg_sell_add_cnt_10s': self.ewavg_sell_add_cnt_10s.get_last_value_decayed(update_time),
            'ewavg_buy_del_qty_10s': self.ewavg_buy_del_qty_10s.get_last_value_decayed(update_time),
            'ewavg_buy_del_cnt_10s': self.ewavg_buy_del_cnt_10s.get_last_value_decayed(update_time),
            'ewavg_sell_del_qty_10s': self.ewavg_sell_del_qty_10s.get_last_value_decayed(update_time),
            'ewavg_sell_del_cnt_10s': self.ewavg_sell_del_cnt_10s.get_last_value_decayed(update_time),
            'ewavg_buy_exec_qty_30s': self.ewavg_buy_exec_qty_30s.get_last_value_decayed(update_time),
            'ewavg_buy_exec_cnt_30s': self.ewavg_buy_exec_cnt_30s.get_last_value_decayed(update_time),
            'ewavg_sell_exec_qty_30s': self.ewavg_sell_exec_qty_30s.get_last_value_decayed(update_time),
            'ewavg_sell_exec_cnt_30s': self.ewavg_sell_exec_cnt_30s.get_last_value_decayed(update_time),
            'buy_exec_10s_dec': self.buy_exec_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_1m_dec': self.buy_exec_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_3m_dec': self.buy_exec_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_10m_dec': self.buy_exec_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_exec_30m_dec': self.buy_exec_30m.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_10s_dec': self.sell_exec_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_1m_dec': self.sell_exec_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_3m_dec': self.sell_exec_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_10m_dec': self.sell_exec_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_exec_30m_dec': self.sell_exec_30m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l1_10s_dec': self.buy_add_sh_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l1_1m_dec': self.buy_add_sh_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l1_3m_dec': self.buy_add_sh_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l1_10m_dec': self.buy_add_sh_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l1_10s_dec': self.buy_add_cnt_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l1_1m_dec': self.buy_add_cnt_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l1_3m_dec': self.buy_add_cnt_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l1_10m_dec': self.buy_add_cnt_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l1_10s_dec': self.sell_add_sh_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l1_1m_dec': self.sell_add_sh_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l1_3m_dec': self.sell_add_sh_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l1_10m_dec': self.sell_add_sh_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l1_10s_dec': self.sell_add_cnt_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l1_1m_dec': self.sell_add_cnt_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l1_3m_dec': self.sell_add_cnt_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l1_10m_dec': self.sell_add_cnt_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l2_10s_dec': self.buy_add_sh_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l2_1m_dec': self.buy_add_sh_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l2_3m': self.buy_add_sh_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_sh_l2_10m': self.buy_add_sh_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l2_10s': self.buy_add_cnt_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l2_1m': self.buy_add_cnt_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l2_3m': self.buy_add_cnt_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_add_cnt_l2_10m': self.buy_add_cnt_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l2_10s': self.sell_add_sh_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l2_1m': self.sell_add_sh_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l2_3m': self.sell_add_sh_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_sh_l2_10m': self.sell_add_sh_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l2_10s': self.sell_add_cnt_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l2_1m': self.sell_add_cnt_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l2_3m': self.sell_add_cnt_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_add_cnt_l2_10m': self.sell_add_cnt_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l1_10s': self.buy_delete_sh_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l1_1m': self.buy_delete_sh_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l1_3m': self.buy_delete_sh_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l1_10m': self.buy_delete_sh_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l1_10s': self.buy_delete_cnt_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l1_1m': self.buy_delete_cnt_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l1_3m': self.buy_delete_cnt_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l1_10m': self.buy_delete_cnt_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l1_10s': self.sell_delete_sh_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l1_1m': self.sell_delete_sh_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l1_3m': self.sell_delete_sh_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l1_10m': self.sell_delete_sh_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l1_10s': self.sell_delete_cnt_l1_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l1_1m': self.sell_delete_cnt_l1_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l1_3m': self.sell_delete_cnt_l1_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l1_10m': self.sell_delete_cnt_l1_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l2_10s_dec': self.buy_delete_sh_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l2_1m_dec': self.buy_delete_sh_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l2_3m_dec': self.buy_delete_sh_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_sh_l2_10m_dec': self.buy_delete_sh_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l2_10s_dec': self.buy_delete_cnt_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l2_1m_dec': self.buy_delete_cnt_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l2_3m_dec': self.buy_delete_cnt_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_delete_cnt_l2_10m_dec': self.buy_delete_cnt_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l2_10s_dec': self.sell_delete_sh_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l2_1m_dec': self.sell_delete_sh_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l2_3m_dec': self.sell_delete_sh_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_sh_l2_10m_dec': self.sell_delete_sh_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l2_10s_dec': self.sell_delete_cnt_l2_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l2_1m_dec': self.sell_delete_cnt_l2_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l2_3m_dec': self.sell_delete_cnt_l2_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_delete_cnt_l2_10m_dec': self.sell_delete_cnt_l2_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_level_added_10s': self.buy_level_added_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_level_added_1m': self.buy_level_added_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_level_added_3m': self.buy_level_added_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_level_added_10m': self.buy_level_added_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_level_added_10s': self.sell_level_added_10s.get_last_value_decayed(nanos_from_epoch),
            'sell_level_added_1m': self.sell_level_added_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_level_added_3m': self.sell_level_added_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_level_added_10m': self.sell_level_added_10m.get_last_value_decayed(nanos_from_epoch), 
            'buy_level_removed_10s': self.buy_level_removed_10s.get_last_value_decayed(nanos_from_epoch),
            'buy_level_removed_1m': self.buy_level_removed_1m.get_last_value_decayed(nanos_from_epoch),
            'buy_level_removed_3m': self.buy_level_removed_3m.get_last_value_decayed(nanos_from_epoch),
            'buy_level_removed_10m': self.buy_level_removed_10m.get_last_value_decayed(nanos_from_epoch),
            'sell_level_removed_10s': self.sell_level_removed_10s.get_last_value_decayed(nanos_from_epoch), 
            'sell_level_removed_1m': self.sell_level_removed_1m.get_last_value_decayed(nanos_from_epoch),
            'sell_level_removed_3m': self.sell_level_removed_3m.get_last_value_decayed(nanos_from_epoch),
            'sell_level_removed_10m': self.sell_level_removed_10m.get_last_value_decayed(nanos_from_epoch),
            'buy_level1_price': self.order_book.buy_side[0].price if 0 < len(self.order_book.buy_side) else None,
            'buy_level1_quantity': self.order_book.buy_side[0].total_shares if 0 < len(self.order_book.buy_side) else None,
            'buy_level1_count': self.order_book.buy_side[0].number_of_orders if 0 < len(self.order_book.buy_side) else None,
            'buy_level2_price': self.order_book.buy_side[1].price if 1 < len(self.order_book.buy_side) else None,
            'buy_level2_quantity': self.order_book.buy_side[1].total_shares if 1 < len(self.order_book.buy_side) else None,
            'buy_level2_count': self.order_book.buy_side[1].number_of_orders if 1 < len(self.order_book.buy_side) else None,
            'buy_level3_price': self.order_book.buy_side[2].price if 2 < len(self.order_book.buy_side) else None,
            'buy_level3_quantity': self.order_book.buy_side[2].total_shares if 2 < len(self.order_book.buy_side) else None,
            'buy_level3_count': self.order_book.buy_side[2].number_of_orders if 2 < len(self.order_book.buy_side) else None,
            'buy_level4_price': self.order_book.buy_side[3].price if 3 < len(self.order_book.buy_side) else None,
            'buy_level4_quantity': self.order_book.buy_side[3].total_shares if 3 < len(self.order_book.buy_side) else None,
            'buy_level4_count': self.order_book.buy_side[3].number_of_orders if 3 < len(self.order_book.buy_side) else None,
            'buy_level5_price': self.order_book.buy_side[4].price if 4 < len(self.order_book.buy_side) else None,
            'buy_level5_quantity': self.order_book.buy_side[4].total_shares if 4 < len(self.order_book.buy_side) else None,
            'buy_level5_count': self.order_book.buy_side[4].number_of_orders if 4 < len(self.order_book.buy_side) else None,
            'buy_level6_price': self.order_book.buy_side[5].price if 5 < len(self.order_book.buy_side) else None,
            'buy_level6_quantity': self.order_book.buy_side[5].total_shares if 5 < len(self.order_book.buy_side) else None,
            'buy_level6_count': self.order_book.buy_side[5].number_of_orders if 5 < len(self.order_book.buy_side) else None,
            'buy_level7_price': self.order_book.buy_side[6].price if 6 < len(self.order_book.buy_side) else None,
            'buy_level7_quantity': self.order_book.buy_side[6].total_shares if 6 < len(self.order_book.buy_side) else None,
            'buy_level7_count': self.order_book.buy_side[6].number_of_orders if 6 < len(self.order_book.buy_side) else None,
            'buy_level8_price': self.order_book.buy_side[7].price if 7 < len(self.order_book.buy_side) else None,
            'buy_level8_quantity': self.order_book.buy_side[7].total_shares if 7 < len(self.order_book.buy_side) else None,
            'buy_level8_count': self.order_book.buy_side[7].number_of_orders if 7 < len(self.order_book.buy_side) else None,
            'buy_level9_price': self.order_book.buy_side[8].price if 8 < len(self.order_book.buy_side) else None,
            'buy_level9_quantity': self.order_book.buy_side[8].total_shares if 8 < len(self.order_book.buy_side) else None,
            'buy_level9_count': self.order_book.buy_side[8].number_of_orders if 8 < len(self.order_book.buy_side) else None,
            'buy_level10_price': self.order_book.buy_side[9].price if 9 < len(self.order_book.buy_side) else None,
            'buy_level10_quantity': self.order_book.buy_side[9].total_shares if 9 < len(self.order_book.buy_side) else None,
            'buy_level10_count': self.order_book.buy_side[9].number_of_orders if 9 < len(self.order_book.buy_side) else None,
            'sell_level1_price': self.order_book.sell_side[0].price if 0 < len(self.order_book.sell_side) else None,
            'sell_level1_quantity': self.order_book.sell_side[0].total_shares if 0 < len(self.order_book.sell_side) else None,
            'sell_level1_count': self.order_book.sell_side[0].number_of_orders if 0 < len(self.order_book.sell_side) else None,
            'sell_level2_price': self.order_book.sell_side[1].price if 1 < len(self.order_book.sell_side) else None,
            'sell_level2_quantity': self.order_book.sell_side[1].total_shares if 1 < len(self.order_book.sell_side) else None,
            'sell_level2_count': self.order_book.sell_side[1].number_of_orders if 1 < len(self.order_book.sell_side) else None,
            'sell_level3_price': self.order_book.sell_side[2].price if 2 < len(self.order_book.sell_side) else None,
            'sell_level3_quantity': self.order_book.sell_side[2].total_shares if 2 < len(self.order_book.sell_side) else None,
            'sell_level3_count': self.order_book.sell_side[2].number_of_orders if 2 < len(self.order_book.sell_side) else None,
            'sell_level4_price': self.order_book.sell_side[3].price if 3 < len(self.order_book.sell_side) else None,
            'sell_level4_quantity': self.order_book.sell_side[3].total_shares if 3 < len(self.order_book.sell_side) else None,
            'sell_level4_count': self.order_book.sell_side[3].number_of_orders if 3 < len(self.order_book.sell_side) else None,
            'sell_level5_price': self.order_book.sell_side[4].price if 4 < len(self.order_book.sell_side) else None,
            'sell_level5_quantity': self.order_book.sell_side[4].total_shares if 4 < len(self.order_book.sell_side) else None,
            'sell_level5_count': self.order_book.sell_side[4].number_of_orders if 4 < len(self.order_book.sell_side) else None,
            'sell_level6_price': self.order_book.sell_side[5].price if 5 < len(self.order_book.sell_side) else None,
            'sell_level6_quantity': self.order_book.sell_side[5].total_shares if 5 < len(self.order_book.sell_side) else None,
            'sell_level6_count': self.order_book.sell_side[5].number_of_orders if 5 < len(self.order_book.sell_side) else None,
            'sell_level7_price': self.order_book.sell_side[6].price if 6 < len(self.order_book.sell_side) else None,
            'sell_level7_quantity': self.order_book.sell_side[6].total_shares if 6 < len(self.order_book.sell_side) else None,
            'sell_level7_count': self.order_book.sell_side[6].number_of_orders if 6 < len(self.order_book.sell_side) else None,
            'sell_level8_price': self.order_book.sell_side[7].price if 7 < len(self.order_book.sell_side) else None,
            'sell_level8_quantity': self.order_book.sell_side[7].total_shares if 7 < len(self.order_book.sell_side) else None,
            'sell_level8_count': self.order_book.sell_side[7].number_of_orders if 7 < len(self.order_book.sell_side) else None,
            'sell_level9_price': self.order_book.sell_side[8].price if 8 < len(self.order_book.sell_side) else None,
            'sell_level9_quantity': self.order_book.sell_side[8].total_shares if 8 < len(self.order_book.sell_side) else None,
            'sell_level9_count': self.order_book.sell_side[8].number_of_orders if 8 < len(self.order_book.sell_side) else None,
            'sell_level10_price': self.order_book.sell_side[9].price if 9 < len(self.order_book.sell_side) else None,
            'sell_level10_quantity': self.order_book.sell_side[9].total_shares if 9 < len(self.order_book.sell_side) else None,
            'sell_level10_count': self.order_book.sell_side[9].number_of_orders if 9 < len(self.order_book.sell_side) else None,
            'mid': self.mid,
            'mid_adj': round(self.mid_adj, 6),
            'spread': round(self.spread, 6) if self.spread is not None else None,
            'spread_l2': round(self.spread_l2, 6) if self.spread_l2 is not None else None,
            'spread_l3': round(self.spread_l3, 6) if self.spread_l3 is not None else None,
        }

        return variables


if __name__ == '__main__':
    date = '20201112'
    order_book_id = 74196

    sim_data = SimData(date, order_book_id)

    print(sim_data.beginning_of_day)
    print(sim_data.end_of_day)


