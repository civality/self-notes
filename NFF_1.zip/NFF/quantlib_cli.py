from util import get_tick_data_path, get_formatted_date
from ssh_connector import get_remote_file
from quantlib.database_functions import constants
from quantlib import database_functions as db

def get_yest_close(date, order_book_id):

    return db.equity_derivative.get_data_by_order_book_id_day_index( 
        order_book_id=order_book_id, 
        date=get_formatted_date(date), 
        fields=['CLOSING_PRICE'], 
        data_type='Bist_Equity', 
        day_index_list=[-1]
    )['CLOSING_PRICE'][0]

if __name__ == '__main__':

    date = '20211130'
    order_book_id = 70796

    yest_close = db.equity_derivative.get_data_by_order_book_id_day_index( 
            order_book_id=order_book_id, 
            date=get_formatted_date(date), 
            fields=['CLOSING_PRICE'],
            data_type='Bist_Equity',
            day_index_list=[-1]
        )['CLOSING_PRICE'][0]

    yesterday_close = db.analiz_expert.get_analiz_expert_data_by_order_book_id_day_index(
        indicator=constants.database.analiz_expert.NOT_ADJUSTED_CLOSING_PRICE,
        order_book_id_list=[order_book_id],
        date=get_formatted_date(date),
        day_index=-1
    ).iloc[0,1]

    index_order_book_id = db.most_liquid.get_most_liquid_derivatives_de_bist30_fut(get_formatted_date(date), first_N=1)['ORDER_BOOK_ID'].iloc[0]
