import json
import numpy as np
import datetime
from typing import Any, List, Tuple, Union

def get_prev_date(cur_date: str, days_ago: int) -> str:
    """
    cur_date: 'yyyymmdd'
    days_ago: int
    
    returns prev_date: 'yyyymmdd'  
    """
    prev_date = datetime.datetime.strptime(cur_date, '%Y%m%d') - datetime.timedelta(days_ago) 
    return prev_date.strftime('%Y%m%d')


def get_tick_data_path(date: str, order_book_id: Union[int, str], kind: str = 'tick-equity') -> str:
    """
    Returns the path of tick data, ie. txt file with message lines 
    for given order_book_id and date;
    date: 'yyyymmdd'
    kind: 'tick-equity' or 'tick-derivative'
    """
    year, month, day = get_year_month_day(date)

    if kind == 'tick-equity':
        source_dir = f'/mnt/data/text_parsed/Bist_Equity/{year}/{month}/{day}/{order_book_id}'
        path_source = f'{source_dir}/perSymbol.Bist_Equity.{date}.{order_book_id}.parsed.txt'
    
    elif kind == 'tick-derivative':
        source_dir = f'/mnt/data/text_parsed/Bist_Derivative/{year}/{month}/{day}/{order_book_id}'
        path_source = f'{source_dir}/perSymbol.Bist_Derivative.{date}.{order_book_id}.parsed.txt'

    else:
        raise ValueError(f'Invalid kind {kind}')

    return path_source

def get_formatted_date(date: Union[int, str]) -> str:
    """
    date: 'yyyymmdd'
    returns: 'yyyy-mm-dd'
    """
    date = str(date)
    
    year, month, day = get_year_month_day(date, as_str=True)
    return f'{year}-{month}-{day}'


def get_year_month_day(date: Union[int, str], as_str: bool = True) -> Union[Tuple[str, str, str], Tuple[int, int, int]]:
    """
    date: 'yyyymmdd'
    returns: (yyyy, mm, dd)
    """
    date = str(date)

    year = date[:4]
    month = date[4:6]
    day = date[6:]

    if as_str:
        return year, month, day
    else:
        return int(year), int(month), int(day)


def dump_list(path: str, my_list: List) -> None:
    """
    Created a txt file each list item are 
    separated by newlines
    """
    with open(path, 'w', encoding='utf-8') as file:
        file.write('\n'.join([str(x) for x in my_list]))


def load_list(path: str) -> List:
    """
    Creates a python list from a txt file.
    Every line becomes a list item
    If infer is False, all elements of returned list are in str format
    If infer is True, all elements of returned list are inferred using eval() method
    """

    with open(path, 'r', encoding='utf-8') as file:
        my_list = file.read().splitlines()
    
    return my_list


def dump_jsonl(data, output_path, append=True):

    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        json_record = json.dumps(data, cls=NpEncoder, ensure_ascii=False)
        f.write(json_record + '\n')


class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NpEncoder, self).default(obj)


def validate_target(df):
    """
    we expect that target is one step ahed mid
    this must hold for a (symbol, day)
    however it is not necessarily true for chained days data for a symbol
    """
    
    df = df[['mid', 'target']].copy()
    df['midup'] = df['mid'].shift(-1)
    df = df.dropna()
    bools = df['target'] == df['midup']
    assert bools.all()

def get_tick_size(px):
    """
    These rules are provided by the exchange
    """
    if px > 99.99:
        return 0.1
    if px > 49.99:
        return 0.05
    if px > 19.99:
        return 0.02
    else: 
        return 0.01
