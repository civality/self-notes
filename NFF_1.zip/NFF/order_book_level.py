class OrderBookLevel:

    def __init__(self, order):
        self.orders = [order]
        self.number_of_orders = 1
        self.total_shares = order.shares
        self.price = order.price
        
    def append(self, order):
        self.orders.append(order)
        self.number_of_orders += 1
        self.total_shares += order.shares

    def adjust_size(self, shares, order_count):
        self.number_of_orders -= order_count
        self.total_shares -= shares
