import util
import pathlib
import pandas as pd
from typing import Union, Optional
from sim_data import SimData
from order_book import OrderBook
from model_config import ModelConfig
from market_player_2 import MarketPlayer2
from message_objects import Add, Delete, Execute, Trade, State, Seconds, get_message_object, create_object_add
from quantlib import database_functions as db

from ssh_connector import get_remote_file
from report import StateReport

nanos_in_sec = 1e9
micros_in_sec = 1e6

class MarketPlayer:
    
    def __init__(self, date: str, order_book_id: int, is_transformer_enabled: bool):

        self.date = date
        self.order_book_id = order_book_id
        self.commission = 7e-5
        self.action_cooldown = int(100e3)
        
        self.action_max_shares = int(10e3)
        self.position_limit_shares = int(150e3)
        self.position_shares = 0
        
        self.action_price_max = int(30e3)
        self.position_price_max = int(1000e3)
        self.position_price_cur = 0
        
        self.action_time_last_exec = 0 
        self.action_delay_nanoseconds = int(90e3)
        self.file_sink = f'{self.date}-{self.order_book_id}.jsonl'
        
        self.order_book = OrderBook()
        self.sim_data = SimData(self.date, self.order_book_id, self.order_book, 'Bist_Equity')
        self.player2 = MarketPlayer2(self.date, self.get_index_order_book_id()) 
        self.model_config = ModelConfig(self.date, self.order_book_id, is_train_enabled=True, is_transformer_enabled=is_transformer_enabled)
        self.report = StateReport()

        self.quant_actions = []
        self.quant_action_results = []
        self.directions = []

    
        self.init_paths()
        #print('@End of MarketPlayer.__init__', date, order_book_id, self.get_index_order_book_id())
    
    def get_index_order_book_id(self):
        return db.most_liquid.get_most_liquid_derivatives_de_bist30_fut(util.get_formatted_date(self.date), first_N=1)['ORDER_BOOK_ID'][0]

        
    def play(self):
        with get_remote_file(util.get_tick_data_path(self.date, self.order_book_id, 'tick-equity')) as f:

            for line in f:
                """
                self.report.on_line(line)
                """
                obj = get_message_object(line)
                if obj:
                    #print(line)
                    #print(obj.to_dict())
                    self.consume_queue(obj.nanos_from_epoch)
                    self.on_message(obj)
                    
                    """
                    if obj.nanos_from_epoch >= 1611903617766100000 and obj.nanos_from_epoch <= 1611903617766480301:
                        print('\n', obj.to_dict())
                        self.order_book.print_order_book(2)
                    """

    def consume_queue(self, until: int):

        while self.quant_actions and self.quant_actions[0][0] <= until:
            
            action_tuple = self.quant_actions.pop(0)

            D = self.sim_data.get_snapshot(action_tuple[0])

            if D['buy_level1_quantity'] and D['sell_level1_quantity']:

                if action_tuple[1] == 'S':
                    
                    if self.position_price_cur < self.position_price_max:
                        
                        cur_shares = min(self.action_price_max // D['sell_level1_price'] , D['sell_level1_quantity'])
                        self.position_price_cur += cur_shares * D['mid']

                        action_result_dict = { 
                            'timestamp': action_tuple[0],
                            'side': action_tuple[1],
                            'price': D['sell_level1_price'],
                            'shares': cur_shares
                        }

                        self.quant_action_results.append(action_result_dict)

                elif action_tuple[1] == 'B':

                    if self.position_price_cur > -self.position_price_max:
                        
                        cur_shares = min(self.action_price_max // D['buy_level1_price'] , D['buy_level1_quantity'])
                        self.position_price_cur -= cur_shares * D['mid']
                        
                        action_result_dict = { 
                            'timestamp': action_tuple[0],
                            'side': action_tuple[1],
                            'price': D['buy_level1_price'],
                            'shares': cur_shares
                        }
                
                        self.quant_action_results.append(action_result_dict)

    def on_message(self, obj: Union[Add, Delete, Execute, Trade, State, Seconds, None]) -> None:
        if obj is None: return
        msg_type = obj.msg_type

        if msg_type == 'A':
            self.on_add(obj)
        elif msg_type == 'D':
            self.on_delete(obj)
        elif msg_type == 'E':
            self.on_execute(obj)
        elif msg_type == 'T':
            self.on_seconds(obj)
        elif msg_type == 'P':
            self.on_trade(obj)
        elif msg_type == 'O':
            self.on_state(obj)
        else:
            pass
        

    def on_add(self, add):
        
        self.order_book.on_add(add)
        self.sim_data.update_data('add', add)

    def on_delete(self, delete):

        self.order_book.on_delete(delete)
        self.sim_data.update_data('delete', delete)

    def on_execute(self, execute: Execute):
        
        """
        print(self.sim_data.time_exec_prev == self.order_book.entry_time_last_exec,
              self.sim_data.time_exec_prev, 
              self.sim_data.time_exec_cur,
              self.order_book.entry_time_last_exec
              )
        """
        
        self.order_book.on_execute(execute)
        self.sim_data.update_data('execute', execute)

        self.player2.play_until(execute.nanos_from_epoch)
        
        D1 = self.sim_data.get_snapshot(execute.nanos_from_epoch)
        D2 = self.player2.get_snapshot(execute.nanos_from_epoch)

        self.may_take_action(D1, D2, execute)
 
        
    def on_trade(self, trade: Trade):
        self.sim_data.update_data('trade', trade)


    def on_state(self, state: State):
        self.sim_data.update_data('state', state)


    def on_seconds(self, seconds):
        self.sim_data.update_data('seconds', seconds)


    def may_take_action(self, D1: dict, D2: dict, execute: Execute):  
        
        if not D1['is_cont_trading']: return
        if execute.nanos_from_epoch - self.action_time_last_exec < self.action_cooldown: return
        if D1['buy_level1_quantity'] is None or D1['sell_level1_quantity'] is None: return 

        bid = D1['buy_level1_price']
        ask = D1['sell_level1_price']
        
        half_spread_percent = (ask - bid) / (ask + bid)
        value = half_spread_percent + self.commission

        excess_ret_5m_pred = self.model_config.predict(D1, D2) #a.k.a expected return

        self.directions.append((execute.side, excess_ret_5m_pred, value))
        
        if (execute.side == 'S' and excess_ret_5m_pred > value) or (execute.side == 'B' and excess_ret_5m_pred < -value):

            self.action_time_last_exec = execute.nanos_from_epoch
            self.quant_actions.append( ( execute.nanos_from_epoch + self.action_delay_nanoseconds, execute.side ) )


    def init_paths(self):

        self.sink_dir = f'data/transformer={self.model_config.is_transformer_enabled}'
        self.path_directions = f'{self.sink_dir}/directions-{self.date}-{self.order_book_id}.csv'
        self.path_quant_action_results = f'{self.sink_dir}/quant-action-results-{self.date}-{self.order_book_id}.csv'


    def dump_data(self):
        
        pathlib.Path(self.sink_dir).mkdir(parents=True, exist_ok=True)

        pd.DataFrame(self.directions, columns=['side', 'excess_ret_5m_pred', 'value']).to_csv(self.path_directions, index=False)
        pd.DataFrame(self.quant_action_results).to_csv(self.path_quant_action_results, index=False)
        

    def get_profit(self):

        closing_price = self.sim_data.get_snapshot( int(2e18) )['closing_price'] # use after play method has finished

        df = pd.read_csv(self.path_quant_action_results)

        profit = (
            (df[df['side'] == 'B']['shares'] * (df[df['side'] == 'B']['price'] - closing_price)).sum()
          + (df[df['side'] == 'S']['shares'] * (closing_price - df[df['side'] == 'S']['price'] )).sum()
        )
            
        return round(profit, 2) 
            
if __name__ == '__main__':

    # '20210217' red day
    # '20210130' is saturday, so get beta gives error 

    #list_date = ['20210129', '20210201', '20210202', '20210203', '20210204', '20210205', '20210208', '20210209', '20210210', '20210211']
    #list_order_book_id = [70796, 71376, 71536, 72076, 73616, 73776, 74156, 74196, 74736, 75236, 75656]
    
    start_date = '20210129'
    end_date =   '20210302'

    df_path_table = pd.read_csv('_path-table.csv')
    df_path_table['date'] = df_path_table['date'].astype(str)
    df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']
    df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < end_date)]
    
    list_problematic_player = []

    for date in df_path_table['date'].unique():
        for order_book_id in df_path_table['order_book_id'].unique():
            for is_transformer_enabled in [True, False]:
                
                try:

                    date = str(date)
                    order_book_id = int(order_book_id)
                    
                    print(util.get_tick_data_path(date, order_book_id, kind='tick-equity'))

                    player = MarketPlayer(date, order_book_id, is_transformer_enabled)
                    player.play()
                    player.dump_data()
                    profit = player.get_profit()

                    util.dump_jsonl({'date': date, 'order_book_id': order_book_id, 'profit': profit, 'is_transformer_enabled': is_transformer_enabled }, 'sim_results.jsonl')

                except:
                    print(f'passing problematic player: {date}-{order_book_id}') #Maybe columns are not as we wanted, or something else
                    list_problematic_player.append(f'{date}-{order_book_id}')

            if len(list_problematic_player) > 0:
                util.dump_list(f'list_problematic_player-{date}-{order_book_id}.txt', list_problematic_player)


    df = pd.read_json('sim_results.jsonl', lines=True)
    df_non_transform = df[df['is_transformer_enabled'].notna()]
    df_transform = df[df['is_transformer_enabled'].isna()]

    df_non_transform_grouped = df_non_transform.groupby('order_book_id')['profit'].agg(['sum', 'mean', 'std']).astype(int)
    df_transform_grouped = df_transform.groupby('order_book_id')['profit'].agg(['sum', 'mean', 'std']).astype(int)

    df_non_transform_grouped['std'] = df_non_transform_grouped['std'] / 1e9
    df_transform_grouped['std'] = df_transform_grouped['std'] / 1e9

    df_non_transform_grouped.columns = ['sum', 'mean', 'std (billions)']
    df_transform_grouped.columns = ['sum', 'mean', 'std (billions)']

    print(df_non_transform_grouped)
    print('total return', df_non_transform_grouped['sum'].sum()) 

    df_transform_grouped

    
    df_transform_grouped['sum'].sum()


