import os
import paramiko
from paramiko.sftp_client import SFTPClient
from paramiko.sftp_file import SFTPFile

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('172.30.3.219', 
    username=os.environ['PARAMIKO_USER'], 
    password=os.environ['PARAMIKO_PASS'])


def get_remote_file(path_source: str) -> SFTPFile:
    """
    returns paramiko file object for given path
    """
    remote_file = get_sftp_client().open(path_source)
    return remote_file


def get_sftp_client() -> SFTPClient:
    """
    returns paramiko sftp_client 
    """
    sftp_client = ssh.open_sftp()
    return sftp_client
