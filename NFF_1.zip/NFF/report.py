from message_objects import get_message_object

class StateReport:
    """
    Note: 
    All messages in [P_ESLESTIRME P_MARJ_YAYIN) have same timestamp 
    """

    def __init__(self) -> None:
        self.reset_dict()
        self.state_prev = 'None'
        self.state = 'None'
        self.timestamp = 0
        self.date_str_prev = None
        self.date_str = None

        self.before_first_exec = True

        self.before_first_trade = True

    def get_date_str(self, date_str):
        if date_str:
            return date_str[11:22]
        else:
            return None
    
    def print_interval(self):
        

        state_prev_spaced = self.state_prev.ljust(21)
        state_spaced = self.state.ljust(21) 

        print(f' {self.get_date_str(self.date_str_prev)}  {state_prev_spaced} {state_spaced}')

    def reset_dict(self):
        self.D = {
            'A': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'D': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'E': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'T': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'P': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'O': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'Z': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'S': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'L': {'count': 0, 'first_timestamp': None, 'last_timestamp': None},
            'R': {'count': 0, 'first_timestamp': None, 'last_timestamp': None}
        }

    def update_dict(self, obj):

        if obj.msg_type != 'T': #Todo: handle t timestamp properly
            print(self.D)
            print(obj.msg_type)
            self.D[obj.msg_type]['count'] += 1
            self.D[obj.msg_type]['last_timestamp'] = obj.date_str
        
        
            if self.D[obj.msg_type]['first_timestamp'] is None:
                self.D[obj.msg_type]['first_timestamp'] = obj.date_str
            
    def on_line(self, line):
        
        obj = get_message_object(line)
        self.update_dict(obj)
        
        if obj.msg_type == 'O':
            

            print(self.D)
            self.D = {} # purpose is count messages in each state interval

            self.state_prev = self.state
            self.date_str_prev = self.date_str
            self.state = obj.state_name
            self.date_str = obj.date_str
            self.timestamp = obj.nanos_from_epoch
            
            self.reset_dict()

