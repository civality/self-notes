import numpy as np
import pandas as pd
import util
from sklearn.linear_model import Ridge
from sklearn.preprocessing import QuantileTransformer
from typing import List

class ModelConfig:

    def __init__(self, date, order_book_id, is_train_enabled=True, is_transformer_enabled=True):
        
        self.date = date
        self.order_book_id = order_book_id
        self.days_ago = 60
        self.is_transformer_enabled = is_transformer_enabled

        self.init_features()
        self.init_data()

        if is_train_enabled:
            self.train_model()

        print('@ End of ModelConfig.__init__', date, order_book_id)

    def init_data(self) -> None:

        start_date = util.get_prev_date(self.date, self.days_ago)

        df_path_table = pd.read_csv('_path-table.csv')
        df_path_table['date'] = df_path_table['date'].astype(str)
        df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']
        df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < self.date)]
        df_path_table = df_path_table[df_path_table['order_book_id'] == self.order_book_id]

        # Preparing model input
        list_df = []

        list_problematic_path = []
        for path in df_path_table['path']:
            try:
                df_part = pd.read_csv(path, usecols=self.get_columns(with_target=True))
                list_df.append(df_part)
            except:
                print(f'passing problematic path: {path}') #Maybe columns are not as we wanted, or something else
                list_problematic_path.append(path)

        if len(list_problematic_path) > 0:
            util.dump_list(f'list_problematic_path-{self.date}-{self.order_book_id}.txt', list_problematic_path)

        self.data = pd.concat(list_df, axis=0, ignore_index=True)

        self.data = self.data[self.get_columns(with_target=True)]  # This ensures desired column order 

        self.data = self.data.fillna(0) # bp can be null sometimes
        self.data = self.data.replace(np.inf, 0)
        self.data = self.data.replace(-np.inf, 0)


    def train_model(self) -> None:

        y = self.data[self.target]
        X = self.data.drop([self.target], axis=1)

        self.scaler = QuantileTransformer()
        self.model = Ridge(alpha=0.1)

        if self.is_transformer_enabled:
            arr_X = self.scaler.fit_transform(X.values)
        else:
            arr_X = X.values

        X = pd.DataFrame(
            data = arr_X,
            columns = X.columns,
            index = X.index
        )

        self.model.fit(X.values, y.values)

        print('@ End of ModelConfig.train_model()')


    def predict(self, D1: dict, D2: dict) -> float:
        
        if self.is_transformer_enabled:
            y_pred = self.model.predict(self.scaler.transform(np.array(list(self.extract_features(D1, D2).values())).reshape(1, -1)))[0]
        else:
            y_pred = self.model.predict(np.array(list(self.extract_features(D1, D2).values())).reshape(1, -1))[0]
        
        return y_pred

    def get_columns(self, with_target: bool = False) -> List:

        cols = list(self.features.keys())
        if with_target:
            cols.append(self.target)
        return cols


    def check_sign(self, x):

        return 1 if x > 0 else -1


    def init_features(self):
        """
        These features represent exact order of the features in the trained model
        """        
        self.target = 'excess_ret_5m'

        self.features  = {
            'bp': 0,
            'buy_exec_10s_dec': 0,
            'w_eavg_qty_10s': 0,
            'buy_add_3s': 0,
            'buy_exec_ts_1s': 0,
            'buy_exec_ts_90s': 0,
            'buy_del_10s': 0,
            'buy_del_90s': 0,
            'sell_exec_10s': 0,
            'sell_exec_ts_1s': 0,
            'buy_add_sh_l1_10s_dec': 0,
            'buy_delete_sh_l2_3m_dec': 0,
            'buy_add_sh_l2_1m': 0,
            'buy_level_added_1m': 0,
            'buy_level_removed_3m': 0,
            'sell_add_cnt_l1_10s': 0,
            'sell_add_cnt_l1_1m': 0,
            'sell_add_sh_l1_1m': 0,
            'sell_add_sh_l2_1m': 0,
            'sell_delete_sh_l2_3m': 0,
            'sell_level_removed_1m': 0,
            'snap_exec_qty': 0,
            'obv1_10': 0,
            'dm_p1': 0,
            'ind.ret.w.eavg.10s': 0,
            'ind.ret.w.eavg.3m': 0,
            'ind.ret.w.eavg.10m': 0,
            'mfm_1min': 0,
            'mfm_3min': 0,
            'mfm_day': 0,
            'ret.eavg.10m.a': 0,
            'ret.w.eavg.30m': 0,
            'dir_log_exec_qty': 0,
            'excess.ret.w.eavg.10s': 0,
            'side_time': 0,
            'ret.eavg.10s.a': 0,
            'dir_hi_lo_3m_bps': 0
        }


    def extract_features(self, D1, D2):
        
        beta = D1['beta']
        spread = D1['spread']
        mid = D1['mid']
        mid_adj = D1['mid_adj']
        low_1m = D1['low_1m']
        low_3m = D1['low_3m']
        low_day = D1['low_day']
        high_1m = D1['high_1m']
        high_3m = D1['high_3m']
        high_day = D1['high_day']
        w_eavg_qty_1m = D1['w_eavg_qty_1m']
        w_eavg_qty_3m = D1['w_eavg_qty_3m']
        day_qty = D1['day_qty']
        eavg_val_px_10m_adj = D1['eavg_val_px_10m_adj']
        w_eavg_px_30m = D1['w_eavg_px_30m']
        snap_exec_qty = D1['snap_exec_qty']
        w_eavg_px_10s = D1['w_eavg_px_10s']
        order_life_last_exec_order = D1['order_life_last_exec_order']
        eavg_val_px_10s_adj = D1['eavg_val_px_10s_adj']
        buy_level1_quantity = D1['buy_level1_quantity']
        sell_level1_quantity = D1['sell_level1_quantity']

        ind_mid = D2['mid']
        ind_w_eavg_px_10s = D2['w_eavg_px_10s']
        ind_w_eavg_px_1m = D2['w_eavg_px_1m']
        ind_w_eavg_px_3m = D2['w_eavg_px_3m']
        ind_w_eavg_px_10m = D2['w_eavg_px_10m']
        ind_w_eavg_px_30m = D2['w_eavg_px_30m']
        ind_eavg_val_px_10s = D2['eavg_val_px_10s']
        ind_eavg_val_px_1m = D2['eavg_val_px_1m']
        ind_eavg_val_px_3m = D2['eavg_val_px_3m']
        ind_eavg_val_px_10m = D2['eavg_val_px_10m']

        spread_bps = spread / mid
        side = self.check_sign(snap_exec_qty)

        bp = (buy_level1_quantity - sell_level1_quantity) / (buy_level1_quantity + sell_level1_quantity)
        ind_ret_w_eavg_10s = (ind_mid - ind_w_eavg_px_10s) / ind_w_eavg_px_10s
        ind_ret_w_eavg_3m = (ind_mid - ind_w_eavg_px_3m) / ind_w_eavg_px_3m
        ind_ret_w_eavg_10m = (ind_mid - ind_w_eavg_px_10m) / ind_w_eavg_px_10m
        mfm_1min = ((mid - low_1m) - (high_1m - mid)) / (high_1m - low_1m + 1e-6) * np.log(w_eavg_qty_1m + 1) * spread_bps 
        mfm_3min = ((mid - low_3m) - (high_3m - mid)) / (high_3m - low_3m + 1e-6) * np.log(w_eavg_qty_3m + 1) * spread_bps 
        mfm_day = ((mid - low_day) - (high_day - mid)) / (high_day - low_day + 1e-6) * np.log(day_qty + 1) * spread_bps
        ret_eavg_10m_a = (mid - eavg_val_px_10m_adj) / eavg_val_px_10m_adj
        ret_w_eavg_30m = (mid - w_eavg_px_30m) / w_eavg_px_30m
        dir_log_exec_qty = np.log(abs(snap_exec_qty) + 1) * spread_bps * side

        ind_ret_w_eavg_10s = (ind_mid - ind_w_eavg_px_10s)  / ind_w_eavg_px_10s
        ret_w_eavg_10s = (mid - w_eavg_px_10s) / w_eavg_px_10s

        excess_ret_w_eavg_10s = ret_w_eavg_10s - ind_ret_w_eavg_10s * beta
        side_time = side * (1 / np.log(1 + order_life_last_exec_order))  
        ret_eavg_10s_a = (mid_adj - eavg_val_px_10s_adj) / eavg_val_px_10s_adj
        hi_lo_3m_bps = (high_3m - low_3m) / mid 
        dir_hi_lo_3m_bps = hi_lo_3m_bps * side

        # comfortably ignore the order of keys in this dict. we will take care the order at the end of the method
        features  = {
            'bp': bp,
            'buy_exec_10s_dec': D1['buy_exec_10s_dec'],
            'w_eavg_qty_10s': D1['w_eavg_qty_10s'],
            'buy_add_3s': D1['buy_add_3s'],
            'buy_exec_ts_1s': D1['buy_exec_1s'], #@StrtegyTimeSensitiveData
            'buy_exec_ts_90s': D1['buy_exec_90s'], #@StrtegyTimeSensitiveData
            'buy_del_10s': D1['buy_del_10s'],
            'buy_del_90s': D1['buy_del_90s'],
            'sell_exec_10s': D1['sell_exec_10s'],
            'sell_exec_ts_1s': D1['sell_exec_1s'],
            'buy_add_sh_l1_10s_dec': D1['buy_add_sh_l1_10s_dec'],
            'buy_delete_sh_l2_3m_dec': D1['buy_delete_sh_l2_3m_dec'],
            'buy_add_sh_l2_1m': D1['buy_add_sh_l2_1m'],
            'buy_level_added_1m': D1['buy_level_added_1m'],
            'buy_level_removed_3m': D1['buy_level_removed_3m'],
            'sell_add_cnt_l1_10s': D1['sell_add_cnt_l1_10s'],
            'sell_add_cnt_l1_1m': D1['sell_add_cnt_l1_1m'],
            'sell_add_sh_l1_1m': D1['sell_add_sh_l1_1m'],
            'sell_add_sh_l2_1m': D1['sell_add_sh_l2_1m'],
            'sell_delete_sh_l2_3m': D1['sell_delete_sh_l2_3m'],
            'sell_level_removed_1m': D1['sell_level_removed_1m'],
            'snap_exec_qty': D1['snap_exec_qty'],
            'obv1_10': D1['obv1_10'],
            'dm_p1': D1['dm_p1'],
            'ind.ret.w.eavg.10s': ind_ret_w_eavg_10s,
            'ind.ret.w.eavg.3m': ind_ret_w_eavg_3m,
            'ind.ret.w.eavg.10m': ind_ret_w_eavg_10m,
            'mfm_1min': mfm_1min,
            'mfm_3min': mfm_3min,
            'mfm_day': mfm_day,
            'ret.eavg.10m.a': ret_eavg_10m_a,
            'ret.w.eavg.30m': ret_w_eavg_30m,
            'dir_log_exec_qty': dir_log_exec_qty,
            'excess.ret.w.eavg.10s': excess_ret_w_eavg_10s,
            'side_time': side_time,
            'ret.eavg.10s.a': ret_eavg_10s_a,
            'dir_hi_lo_3m_bps': dir_hi_lo_3m_bps
        }

        features_ordered = {k: features[k] for k in self.get_columns()}

        
        
        #util.dump_jsonl(features_ordered, 'features.jsonl')

        return features_ordered


if __name__ == '__main__':

    model_config = ModelConfig('20210130', 74196)
    # '20201112'
