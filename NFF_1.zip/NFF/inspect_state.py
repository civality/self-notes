from pathify import get_path_table
from util import get_tick_data_path
from ssh_connector import get_remote_file
import pandas as pd


def get_state_list_as_str(date, order_book_id, kind) -> str:
    """
    Depending on date, order_book_id, kind; for that tick data
    retruns state messages in a day 
    all states are concatenated as a single string. 
    all states are ordered and comma separated.
    """

    the_list = []

    with get_remote_file(get_tick_data_path(date, order_book_id, kind)) as f:
        for msg in f:
            M = msg.split(',')
            msg_type = M[0]
   
            if msg_type == 'O':
                the_list.append(M[3].rstrip()) #append state name

    return ','.join(the_list)


def make_state_table():
    kind = 'tick-equity'
    path_table = get_path_table(kind)

    the_list = []

    for i, row in path_table.iterrows():
        state_list_as_str = get_state_list_as_str(row['date'], row['order_book_id'], kind)
        
        print(row['path'], row['date'], row['order_book_id'])
        print(state_list_as_str)

        the_list.append((row['date'], row['order_book_id'], state_list_as_str))


    pd.DataFrame(
        the_list, 
        columns=['date', 'order_book_id', 'state_list_as_str']
        ).to_csv('state-table-equity.csv')

if __name__ == '__main__':

    make_state_table()
