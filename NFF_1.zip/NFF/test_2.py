import util
import pandas as pd 
import numpy as np
import os
import sys
import intraday_price.get_intraday_price as ip
from decimal import Decimal
from quantlib import database_functions as db
from quantlib.database_functions.constants import columns as cols
from util import * 
from quantlib import utilities as ut
from ssh_connector import get_remote_file
from data_types import HiLow
import model_config
import market_player

start_date = '20210129'
end_date =   '20210302'

df_path_table = pd.read_csv('_path-table.csv')
df_path_table['date'] = df_path_table['date'].astype(str)
df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']

for p in df_path_table[df_path_table['date'].isin(['20210222', '20210223', '20210224', '20210225', '20210226', '20210301']) & (df_path_table['order_book_id'] == 77796)]['path']:
    df = pd.read_csv(p)
    print(df.shape)

df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < end_date)]

list_problematic_player = []

for date in df_path_table['date'].unique():
    for order_book_id in df_path_table['order_book_id'].unique():
        for is_transformer_enabled in [True, False]:
            
            for path in df_path_table['path']:
                print(date, order_book_id, is_transformer_enabled,)

df1 = pd.read_csv('/mnt/data/exec_snap/Bist_Equity/2020/12/25/exec_snap-200000delay/Bist_Equity.20201225.74736.exec_snap.200000delay.csv.gz')
df1['excess_ret_5m']

we = pd.DataFrame({'A':[1,2,np.inf], 'B':[2,1,3], 'C':[np.inf,3,3]})
np.where(we == np.inf, 999, we)

we.replace(np.inf, 999)

we
date = '20210201'
order_book_id = 74736
days_ago = 60


config = model_config.ModelConfig(date, order_book_id, is_train_enabled=False, is_transformer_enabled=True)





start_date = util.get_prev_date(date, days_ago)

df_path_table = pd.read_csv('_path-table.csv')
df_path_table['date'] = df_path_table['date'].astype(str)
df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']
df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < date)]
df_path_table = df_path_table[df_path_table['order_book_id'] == order_book_id]

config

df_path_table

# Preparing model input
list_df = []

for path in df_path_table['path']:
    try:
        df_part = pd.read_csv(path, usecols=config.get_columns(with_target=True))

        if any(df_part == np.inf):
            print(path)
            print(df_part['ret.eavg.10m.a'].describe())

        list_df.append(df_part)
    except:
        print(f'passing problematic path: {path}') #Maybe columns are not as we wanted, or something else




for df1 in list_df:
    if any(df1 == np.inf):
        print(df1['ret.eavg.10m.a'].describe())










date = '20210201'
order_book_id = 74736


df1 = pd.read_csv('/mnt/data/exec_snap/Bist_Equity/2020/12/24/exec_snap-200000delay/Bist_Equity.20201224.74736.exec_snap.200000delay.csv.gz')
df2 = pd.read_csv('/mnt/data/exec_snap/Bist_Equity/2020/12/25/exec_snap-200000delay/Bist_Equity.20201225.74736.exec_snap.200000delay.csv.gz')

df1.columns
df2.columns

df[['mfm_3min', 'ind.ret.w.eavg.10s', 'dir_log_exec_qty', 'bp', 'excess_ret_5m', 'ind.ret.w.eavg.3m', 'ind.ret.w.eavg.10m', 'mfm_day', 'excess.ret.w.eavg.10s', 'ret.eavg.10m.a', 'dir_hi_lo_3m_bps', 'ret.eavg.10s.a', 'ret.w.eavg.30m', 'mfm_1min', 'side_time']]
df['ind.ret.w.eavg.10s']

util.dump_list('abc', df.columns.to_list())

/mnt/data/exec_snap/Bist_Equity/2020/12/25/exec_snap-200000delay/Bist_Equity.20201225.74736.exec_snap.200000delay.csv.gz



len([None, 1])


date = '20210201'
order_book_id = 74156
player = market_player.MarketPlayer(date, order_book_id, is_transformer_enabled=True)
player.play()

util.get_tick_data_path(date=date, order_book_id=order_book_id, kind='tick-equity')



start_date = '20210129'
end_date =   '20210302'

df_path_table = pd.read_csv('_path-table.csv')
df_path_table['date'] = df_path_table['date'].astype(str)
df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']
df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < end_date)]

df_path_table

start_date = '20210129'
end_date =   '20210302'


start_date = '20210129'
end_date =   '20210302'

df_path_table = pd.read_csv('_path-table.csv')
df_path_table['date'] = df_path_table['date'].astype(str)
df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']
df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < end_date)]

df_path_table = df_path_table.iloc[4:, :] #temporary line for checkpoint





df_path_table = pd.read_csv('_path-table.csv')
df_path_table['date'] = df_path_table['date'].astype(str)
df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']
df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < end_date)]

for date in df_path_table['date'].unique():
    for order_book_id in df_path_table['order_book_id'].unique():
        for is_transformer_enabled in [True, False]:
            print(date, order_book_id, is_transformer_enabled)

type(order_book_id)

int(order_book_id)

start_date = get_prev_date(self.date, self.days_ago)


# Preparing model input
list_df = []

for path in df_path_table['path']:
    df_part = pd.read_csv(path, usecols=self.get_columns(with_target=True))
    list_df.append(df_part)

df = pd.concat(list_df, axis=0, ignore_index=True)


20210217', 74196

import pandas as pd
df = pd.read_csv('directions.csv')

(df['excess_ret_5m_pred']<0).value_counts()

df = pd.read_csv('quant_action_results.csv')
df
df[df['side'] == 'B']['price'].sum() #para girdi

df['side'].value_counts()


(
(df[df['side'] == 'B']['shares'] * (df[df['side'] == 'B']['price'] - 9.55)).sum()

+

(df[df['side'] == 'S']['shares'] * (9.55 - df[df['side'] == 'S']['price'] )).sum()
)


(
(df[df['side'] == 'B']['shares'] * (df[df['side'] == 'B']['price'] - 9.55)).sum()

+

(df[df['side'] == 'S']['shares'] * (9.55 - df[df['side'] == 'S']['price'] )).sum()
)

df['timestamp'].diff().fillna(99999999).astype(int).min()



len(df) * 7e-5

(df[df['side'] == 'S']['shares'] * (9.32 - df[df['side'] == 'S']['price'] )).sum()




df[df['side'] == 'B']['shares'].sum() #hisse çıktı

df[df['side'] == 'S']['price'].sum() #para çıktı

df[df['side'] == 'S']['shares'].sum() #hisse girdi



343 + 49 + 49 + 7 + 49 + 7 + 7 + 1

8 ** 3
7e-5 == 0.00007

#toplamına oranı küçülüyor o yüzden sonuç da küçülüyor

Fark 2 #denge hi ya kayıyor

hi = 9
lo = 7

(hi - lo) / ((hi + lo) / 2)


hi = 10
lo = 8

(hi - lo) / ((hi + lo) / 2)

hi = 11
lo = 9

(hi - lo) / ((hi + lo) / 2)

hi = 12
lo = 10

(hi - lo) / ((hi + lo) / 2)






>>> (hi - lo) / ((hi + lo) / 2)
0.0019999999999999575
>>> ((hi + lo) / 2) / (hi - lo)
500.0000000000107







round(10.01 - 9.98, 3)

round(((10.01 + 9.98) / 2), 3)


( 3481
+ 1000
+ 320
+ 3596
+ 100
+ 1383
+ 3528
+ 10
+ 457
+ 1800
+ 3831
+ 494)


11503 - 1383
get_tick_data_path('20210129', 74196, kind='tick-equity')

E,2021-01-29T07:01:22.379691669(1611903682379691669),7384466331490155040,74196,B,1383,738446582038677630,0,,
E,2021-01-29T07:01:22.751387314(1611903682751387314),7384466331490155040,74196,B,3528,738446582038677686,0,,


E,2021-01-29T07:01:23.228165738(1611903683228165738),7384466331490082147,74196,S,500,738446582038677808,0,,

 S level 0 (158.6)
        (785370996, 158.6, 1) (785780072, 158.6, 3) (785782244, 158.6, 2) (785783158, 158.6, 1) 

D,2021-01-29T07:01:23.381697608(1611903683381697608),7384466331489925432,74196,B
E,2021-01-29T07:01:23.879735747(1611903683879735747),7384466331490082147,74196,S,10000,738446582038677932,0,,

quant_messages = []

for obj in [1, 3, 5, 6, 7, 9, 11, 13, 15]:
    
    while quant_messages and quant_messages[0] <= obj:

        quant_obj = quant_messages.pop(0)
        print('quant_obj', quant_obj)

    print(obj)

    if obj in [1, 5, 11]:
        quant_messages.append(obj + 5)

quant_messages
                

7384466331488939983

7384466331488939983 % int(1e10) 

len('7384466331488939983')



class Add:

    # constructor
    def __init__(self, list_msg):
    
        assert 'A' == list_msg[0]
        self.msg_type = list_msg[0]
        self.date_str = list_msg[1]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.order_id = int(list_msg[2])
        self.symbol_id = list_msg[3]
        self.side = list_msg[4]
        self.order_book_position = int(list_msg[5])
        self.shares = int(list_msg[6])
        self.price = float(list_msg[7])/1000
        
    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'date_str': self.date_str,
            'nanos_from_epoch': self.nanos_from_epoch,
            'order_id': self.order_id,
            'symbol_id': self.symbol_id,
            'side': self.side,
            'order_book_position': self.order_book_position,
            'shares': self.shares,
            'price': self.price
        }
    
M = 'A,2018-10-08T08:46:49.709496311(1538988409709496311),7050379173636005720,74836,S,1,90,9010,0,2'
M = M.split(',')


nanos_from_epoch = 1538988409709496311
pdts = pd.Timestamp(nanos_from_epoch)

msg_type = 'A'
date_str = f'{str(pdts)}({nanos_from_epoch})'
order_id = '7050379173636005720'
order_book_id = '74836'
side = 'S'
order_book_position = '1'
shares='90'
price='9010'

def create_object_add(nanos_from_epoch:str):

    pdts = pd.Timestamp(int(nanos_from_epoch))

    msg_type = 'A'
    date_str = f'{str(pdts)}({nanos_from_epoch})'
    order_id = '7050379173636005720'
    order_book_id = '74836'
    side = 'S'
    order_book_position = '1'
    shares='90'
    price='9010'


    M = f'{msg_type},{date_str},{order_id},{order_book_id},{side},{order_book_position},{shares},{price}'
    M = M.split(',')

    return Add(M)

'2' + '3'

nanos_from_epoch = 1538988409709496311
create_object_add(nanos_from_epoch)


create_object_add().to_dict()

add = Add(M)
add.price

add.shares

hi_lo = HiLow(5, 5, 60)

hi_lo.high
hi_lo.low
hi_lo.bucket_frequency

hi_lo_1m = [hi_lo for i in range(1)]
hi_lo_3m = [hi_lo for i in range(3)]

cur_hi_lo = HiLow(5, 5, 60)

hi_lo_1m

hi_lo_3m

A = [1,2,3]
A.pop(0)
A

A.append(5)
A

def foo(x):
    if x == 5: return
    print(f'HELLO X={x}')

foo(5)


round(0.123456789, 6)    # 0.123457
round(0.123, 6)          # 0.123


round(None, 6)

variables

# talking about top levels
buy_price = 9
sell_shares = 7

sell_price = 10
buy_shares = 8

(buy_price * sell_shares + sell_price * buy_shares) / (buy_shares + sell_shares)

9 * 99999999 + 10 * 7  
142 / (99999999 + 7)


def get_tick_size(px):
    if px > 99.99:
        return 0.1
    if px > 49.99:
        return 0.05
    if px > 19.99:
        return 0.02
    else:
        return 0.01

def check_sign(x):
    return 1 if x > 0 else -1

date = '20201112'
order_book_id = 74196
get_formatted_date(date)

index_order_book_id = db.most_liquid.get_most_liquid_derivatives_de_bist30_fut(get_formatted_date(date), first_N=1)['ORDER_BOOK_ID'][0]
index_order_book_id


with get_remote_file(get_tick_data_path(date, index_order_book_id, 'tick-derivative')) as f:
    lines = f.readlines()

def get_nanos_from_epoch_from_line(line):

    if line.startswith('T'):
        time = line[2:] + '000000000'
    else:
        time = line[32:51]
    
    return int(time)


lines = [line.strip() for line in lines]

idx = 0

line = lines[idx]
cur_nanos_from_epoch = 1605164403421557829
cur_nanos_from_epoch = 1605164403 * int(1e9)

def play_until():

    while get_nanos_from_epoch_from_line(line) <= cur_nanos_from_epoch:
        print(line)
        idx += 1
        line = lines[idx]


get_nanos_from_epoch_from_line(line)


D2 = {"a": 1, "b": 2, "c": 3, "d": 4}

keys_to_extract = ["a", "c"]
a_subset = {f'ind_{key}': D2[key] for key in keys_to_extract}
a_subset

'20210129', 74196
index_order_book_id = db.most_liquid.get_most_liquid_derivatives_de_bist30_fut(get_formatted_date('20210129'), first_N=1)['ORDER_BOOK_ID'][0]
index_order_book_id

list_nanos_from_epoch = [1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421557829, 1605164403421913051, 1605164403426501671, 1605164403429809002, 1605164403432564966, 1605164403447876557, 1605164403455196401, 1605164403460721877]
len(list_nanos_from_epoch) - len(set(list_nanos_from_epoch))

ip.get_intraday_price(date, index_order_book_id, list_nanos_from_epoch, lag=300, data_type = "Bist_Derivative")['price']

order_book_id = 9778629
lag=300
data_type = 'Bist_Derivative'

start_of_date = ut.get_beginning_nanos_epoch(date, "00:00:00", "UTC")
end_of_date = ut.get_beginning_nanos_epoch(date, "23:59:59", "UTC")
assert all(
    start_of_date < time_stamp < end_of_date + 1e9 
    for time_stamp 
    in list_nanos_from_epoch
    ), "Some time stamps are out of date range."

is_half_day = False
half_day_list = ["20191028", "20200730", "20201028", "20210512", "20210719"]
if date in half_day_list:
    is_half_day =  True
is_half_day

beginning_of_day = ut.get_beginning_nanos_epoch(
    ymd=date,
    hms="07:00:00",
    from_tz="UTC"
)
beginning_of_day



TEXT_PARSED_FOLDER = "/mnt/data/text_parsed"
data_folder = os.path.join(TEXT_PARSED_FOLDER, data_type)
file_dir = os.path.join(
        data_folder,
        date[:4],
        date[4:6],
        date[6:],
        str(order_book_id)
        )



lag_nanos_list = [nano + lag * int(1e9) for nano in list_nanos_from_epoch]

lag_nanos_list = list(set(lag_nanos_list))
lag_nanos_list.sort()
lag_nanos_list

beginning_of_day = ut.get_beginning_nanos_epoch(
    ymd=date,
    hms="07:00:00",
    from_tz="UTC"
)
beginning_of_day


1605164703421557829 - 1605164403421557829
1605164703421557829 - 1605164403421557829
1605164403421557829 - 1605164703421557829

create_quant_message(1605192526373427020, [None])



file_dir

assert os.path.exists(file_dir)

file_dir

file_path = os.path.join( # perSymbol txt file
    file_dir,
    os.listdir(file_dir)[0] 
    )

'/mnt/data/text_parsed/Bist_Derivative/2020/11/12/9778629/perSymbol.Bist_Derivative.20201112.9778629.parsed.txt'






get_tick_data_path(date, order_book_id, 'tick-equity')

df = pd.read_json('/home/csahin/repos/strategy_sim_repo/trunk/20201112-74196.jsonl', lines=True, nrows=1010).round(6)
list_nanos_from_epoch= df['nanos_from_epoch'].tail(20).to_list()
list_nanos_from_epoch

ip.get_intraday_price(date, index_order_book_id, list_nanos_from_epoch, lag=300, data_type = "Bist_Derivative")['price']


df['ind.mid.5m'] = ip.get_intraday_price(date, index_order_book_id, list_of_nanos_epoch_time_stamps=list_nanos_from_epoch, lag=300, data_type = "Bist_Derivative")['price']

df['ind.mid.10m'] = ip.get_intraday_price(date, index_order_book_id, list_of_nanos_epoch_time_stamps=list_nanos_from_epoch, lag=600, data_type = "Bist_Derivative")['price']

strategy_variables =\
"""
self.buy_level1_price, self.buy_level1_quantity, self.buy_level1_count,
self.buy_level2_price, self.buy_level2_quantity, self.buy_level2_count,
self.buy_level3_price, self.buy_level3_quantity, self.buy_level3_count,
self.buy_level4_price, self.buy_level4_quantity, self.buy_level4_count,
self.buy_level5_price, self.buy_level5_quantity, self.buy_level5_count,
self.buy_level6_price, self.buy_level6_quantity, self.buy_level6_count,
self.buy_level7_price, self.buy_level7_quantity, self.buy_level7_count,
self.buy_level8_price, self.buy_level8_quantity, self.buy_level8_count,
self.buy_level9_price, self.buy_level9_quantity, self.buy_level9_count,
self.buy_level10_price, self.buy_level10_quantity, self.buy_level10_count,
self.sell_level1_price, self.sell_level1_quantity, self.sell_level1_count,
self.sell_level2_price, self.sell_level2_quantity, self.sell_level2_count,
self.sell_level3_price, self.sell_level3_quantity, self.sell_level3_count,
self.sell_level4_price, self.sell_level4_quantity, self.sell_level4_count,
self.sell_level5_price, self.sell_level5_quantity, self.sell_level5_count,
self.sell_level6_price, self.sell_level6_quantity, self.sell_level6_count,
self.sell_level7_price, self.sell_level7_quantity, self.sell_level7_count,
self.sell_level8_price, self.sell_level8_quantity, self.sell_level8_count,
self.sell_level9_price, self.sell_level9_quantity, self.sell_level9_count,
self.sell_level10_price, self.sell_level10_quantity, self.sell_level10_count,
self.mid, self.mid_adj, self.spread, self.spread_l2,self.spread_l3,self.eavg_val_spread, self.eavg_val_px_10s,
self.eavg_val_px_1m,
self.eavg_val_px_3m, self.eavg_val_px_10m, self.eavg_val_px_10s_adj, self.eavg_val_px_1m_adj,
self.eavg_val_px_3m_adj, self.eavg_val_px_10m_adj, self.w_eavg_px_10s, self.w_eavg_px_1m, self.w_eavg_px_3m, self.w_eavg_px_10m, self.w_eavg_px_30m, 
self.w_eavg_px_10s_adj, self.w_eavg_px_1m_adj, self.w_eavg_px_3m_adj, self.w_eavg_px_10m_adj, self.w_eavg_px_30m_adj,
self.w_eavg_qty_10s, self.w_eavg_qty_1m, self.w_eavg_qty_3m, self.w_eavg_qty_10m, self.w_eavg_qty_30m, self.day_w_px, self.day_w_px_adj, self.day_buy_notional, self.day_sell_notional,
self.day_qty,self.day_buy_qty,self.day_sell_qty,self.buy_exec_10s,self.buy_exec_1m,self.buy_exec_3m,self.buy_exec_10m,self.buy_exec_30m,self.sell_exec_10s,self.sell_exec_1m,self.sell_exec_3m,self.sell_exec_10m,self.sell_exec_30m,
self.buy_exec_10s_dec,self.buy_exec_1m_dec,self.buy_exec_3m_dec,self.buy_exec_10m_dec,self.buy_exec_30m_dec,self.sell_exec_10s_dec,self.sell_exec_1m_dec,self.sell_exec_3m_dec,self.sell_exec_10m_dec,self.sell_exec_30m_dec
"""

strategy_variables = strategy_variables.split(',')



header = "b.book.l1.px,b.book.l1.sh,b.book.l1.ct,b.book.l2.px,b.book.l2.sh,b.book.l2.ct," \
                "b.book.l3.px,b.book.l3.sh,b.book.l3.ct,b.book.l4.px,b.book.l4.sh,b.book.l4.ct," \
                "b.book.l5.px,b.book.l5.sh,b.book.l5.ct,b.book.l6.px,b.book.l6.sh,b.book.l6.ct," \
                "b.book.l7.px,b.book.l7.sh,b.book.l7.ct,b.book.l8.px,b.book.l8.sh,b.book.l8.ct," \
                "b.book.l9.px,b.book.l9.sh,b.book.l9.ct,b.book.l10.px,b.book.l10.sh,b.book.l10.ct," \
                "s.book.l1.px,s.book.l1.sh,s.book.l1.ct,s.book.l2.px,s.book.l2.sh,s.book.l2.ct," \
                "s.book.l3.px,s.book.l3.sh,s.book.l3.ct,s.book.l4.px,s.book.l4.sh,s.book.l4.ct," \
                "s.book.l5.px,s.book.l5.sh,s.book.l5.ct,s.book.l6.px,s.book.l6.sh,s.book.l6.ct," \
                "s.book.l7.px,s.book.l7.sh,s.book.l7.ct,s.book.l8.px,s.book.l8.sh,s.book.l8.ct," \
                "s.book.l9.px,s.book.l9.sh,s.book.l9.ct,s.book.l10.px,s.book.l10.sh,s.book.l10.ct," \
                "mid,mid.adj,spr,spr2,spr3,eavg.spr,eavg.px.10s,eavg.px.1m,eavg.px.3m,eavg.px.10m," \
                "eavg.px.10s.a,eavg.px.1m.a,eavg.px.3m.a,eavg.px.10m.a,w.eavg.px.10s,w.eavg.px.1m,w.eavg.px.3m,w.eavg.px.10m,w.eavg.px.30m,w.eavg.px.10s_adj,w.eavg.px.1m_adj,w.eavg.px.3m_adj,w.eavg.px.10m_adj,w.eavg.px.30m_adj,w_eavg_qty_10s,w_eavg_qty_1m,w_eavg_qty_3m,w_eavg_qty_10m,w_eavg_qty_30m,day_w_px,day_w_px_adj,day_buy_notional,day_sell_notional,"\
                "day_qty,day_buy_qty,day_sell_qty,buy_exec_10s,buy_exec_1m,buy_exec_3m,buy_exec_10m,buy_exec_30m,sell_exec_10s,sell_exec_1m,sell_exec_3m,sell_exec_10m,sell_exec_30m,"\
                "buy_exec_10s_dec,buy_exec_1m_dec,buy_exec_3m_dec,buy_exec_10m_dec,buy_exec_30m_dec,sell_exec_10s_dec,sell_exec_1m_dec,sell_exec_3m_dec,sell_exec_10m_dec,sell_exec_30m_dec"    

header = header.split(',')

DD = {k:v for k, v in zip(header, strategy_variables)}

DD['eavg.px.10m.a']

DD['w.eavg.px.30m']

DD['eavg.px.10s.a']


        df['bp'] = (df['b.book.l1.sh'] - df['s.book.l1.sh']) /  (df['b.book.l1.sh'] + df['s.book.l1.sh'])

bp = (buy_level1_quantity - sell_level1_quantity) / (buy_level1_quantity + sell_level1_quantity)

DD['s.book.l1.sh']  

0.000001 == 1e-6

mydict = {'excess_ret_5m': 0, 'bp': -0.060303427199301464, 'buy_exec_10s_dec': 2625.536551, 'w_eavg_qty_10s': 1171335.923766, 'buy_add_3s': 48.113677, 'buy_exec_ts_1s': 0, 'buy_exec_ts_90s': 0, 'buy_del_10s': 83.61941, 'buy_del_90s': 270.320759, 'sell_exec_10s': 1085.028689, 'sell_exec_ts_1s': 0, 'buy_add_sh_l1_10s_dec': 0, 'buy_delete_sh_l2_3m_dec': 0, 'buy_add_sh_l2_1m': 408172.859027, 'buy_level_added_1m': 37.401443, 'buy_level_removed_3m': 2.426401, 'sell_add_cnt_l1_10s': 66.527424, 'sell_add_cnt_l1_1m': 243.554425, 'sell_add_sh_l1_1m': 2887381.204669, 'sell_add_sh_l2_1m': 649207.267857, 'sell_delete_sh_l2_3m': 275479.275821, 'sell_level_removed_1m': 2.954459, 'snap_exec_qty': 5000, 'obv1_10': 1461.632199, 'dm_p1': 0.0, 'ind_ret_w_eavg_10s': 0.0002300907438933415, 'ind_ret_w_eavg_3m': -0.0005814763388831912, 'ind_ret_w_eavg_10m': -0.001020547610220658, 'mfm_1min': -0.008191755877089655, 'mfm_3min': -0.0083960871576069, 'nfm_day': -0.008507848497790451, 'ret_eavg_10m_a': 9.935048438010129e-06, 'ret_w_eavg_30m': -0.004498684506325418, 'dir_log_exec_qty': 0.0100737944073553, 'excess_ret_w_eavg_10s': -0.0010009339328195333, 'side_time': 0.044897255050279916, 'ret_eavg_10s_a': -2.5665544833891953e-05, 'dir_hi_lo_3m_bps': 0.01064458900059135}

len(mydict)

1/6



values =\
"""
self.buy_l1_px_diff,self.buy_l2_px_diff,self.buy_l3_px_diff,self.buy_l4_px_diff,self.buy_l5_px_diff,self.buy_l6_px_diff,self.buy_l7_px_diff,self.buy_l8_px_diff,self.buy_l9_px_diff,self.buy_l10_px_diff,\
self.sell_l1_px_diff,self.sell_l2_px_diff,self.sell_l3_px_diff,self.sell_l4_px_diff,self.sell_l5_px_diff,self.sell_l6_px_diff,self.sell_l7_px_diff,self.sell_l8_px_diff,self.sell_l9_px_diff,self.sell_l10_px_diff,\
self.buy_l1_shr_diff,self.buy_l2_shr_diff,self.buy_l3_shr_diff,self.buy_l4_shr_diff,self.buy_l5_shr_diff,self.buy_l6_shr_diff,self.buy_l7_shr_diff,self.buy_l8_shr_diff,self.buy_l9_shr_diff,self.buy_l10_shr_diff,\
self.sell_l1_shr_diff,self.sell_l2_shr_diff,self.sell_l3_shr_diff,self.sell_l4_shr_diff,self.sell_l5_shr_diff,self.sell_l6_shr_diff,self.sell_l7_shr_diff,self.sell_l8_shr_diff,self.sell_l9_shr_diff,self.sell_l10_shr_diff,\
self.buy_add_1s.get_last_value_decayed(nanos_from_epoch), self.buy_add_3s.get_last_value_decayed(nanos_from_epoch), self.buy_add_10s.get_last_value_decayed(nanos_from_epoch), self.buy_add_90s.get_last_value_decayed(nanos_from_epoch),self.sell_add_1s.get_last_value_decayed(nanos_from_epoch),self.sell_add_3s.get_last_value_decayed(nanos_from_epoch),self.sell_add_10s.get_last_value_decayed(nanos_from_epoch),self.sell_add_90s.get_last_value_decayed(nanos_from_epoch),\
self.buy_del_1s.get_last_value_decayed(nanos_from_epoch), self.buy_del_3s.get_last_value_decayed(nanos_from_epoch), self.buy_del_10s.get_last_value_decayed(nanos_from_epoch), self.buy_del_90s.get_last_value_decayed(nanos_from_epoch),self.sell_del_1s.get_last_value_decayed(nanos_from_epoch),self.sell_del_3s.get_last_value_decayed(nanos_from_epoch),self.sell_del_10s.get_last_value_decayed(nanos_from_epoch),self.sell_del_90s.get_last_value_decayed(nanos_from_epoch),\
self.buy_exec_1s.get_last_value_decayed(nanos_from_epoch), self.buy_exec_3s.get_last_value_decayed(nanos_from_epoch), self.buy_exec_10s.get_last_value_decayed(nanos_from_epoch), self.buy_exec_90s.get_last_value_decayed(nanos_from_epoch),self.sell_exec_1s.get_last_value_decayed(nanos_from_epoch),self.sell_exec_3s.get_last_value_decayed(nanos_from_epoch),self.sell_exec_10s.get_last_value_decayed(nanos_from_epoch),self.sell_exec_90s.get_last_value_decayed(nanos_from_epoch),\
self.buy_add_1s_prev,self.buy_add_1s_now,self.buy_add_3s_prev,self.buy_add_3s_now, self.sell_add_1s_prev,self.sell_add_1s_now,self.sell_add_3s_prev,self.sell_add_3s_now,\
self.buy_del_1s_prev,self.buy_del_1s_now,self.buy_del_3s_prev,self.buy_del_3s_now, self.sell_del_1s_prev,self.sell_del_1s_now,self.sell_del_3s_prev,self.sell_del_3s_now,\
self.buy_exec_1s_prev,self.buy_exec_1s_now,self.buy_exec_3s_prev,self.buy_exec_3s_now, self.sell_exec_1s_prev,self.sell_exec_1s_now,self.sell_exec_3s_prev,self.sell_exec_3s_now,\
self.buy_add_list_1s_prev,self.buy_add_list_1s_now,self.sell_add_list_1s_prev,self.sell_add_list_1s_now,self.buy_del_list_1s_prev,self.buy_del_list_1s_now,self.sell_del_list_1s_prev,self.sell_del_list_1s_now,self.buy_exec_list_1s_prev,self.buy_exec_list_1s_now,self.sell_exec_list_1s_prev,self.sell_exec_list_1s_now,\
self.e_buy_add_px_10s,self.buy_add_slope,self.e_sell_add_px_10s,self.sell_add_slope,self.ewavg_buy_add_qty_10s.get_last_value_decayed(update_time),self.ewavg_buy_add_cnt_10s.get_last_value_decayed(update_time),self.ewavg_sell_add_qty_10s.get_last_value_decayed(update_time),self.ewavg_sell_add_cnt_10s.get_last_value_decayed(update_time), \
self.e_buy_del_px_10s,self.buy_del_slope,self.e_sell_del_px_10s,self.sell_del_slope,self.ewavg_buy_del_qty_10s.get_last_value_decayed(update_time),self.ewavg_buy_del_cnt_10s.get_last_value_decayed(update_time),self.ewavg_sell_del_qty_10s.get_last_value_decayed(update_time),self.ewavg_sell_del_cnt_10s.get_last_value_decayed(update_time),\
self.e_buy_exec_px_30s,self.buy_exec_slope,self.e_sell_exec_px_30s,self.sell_exec_slope, self.ewavg_buy_exec_qty_30s.get_last_value_decayed(update_time),self.ewavg_buy_exec_cnt_30s.get_last_value_decayed(update_time),self.ewavg_sell_exec_qty_30s.get_last_value_decayed(update_time),self.ewavg_sell_exec_cnt_30s.get_last_value_decayed(update_time)]
"""


header = "buy_l1_px_diff,buy_l2_px_diff,buy_l3_px_diff,buy_l4_px_diff,buy_l5_px_diff,buy_l6_px_diff,buy_l7_px_diff,buy_l8_px_diff,buy_l9_px_diff,buy_l10_px_diff,"\
"sell_l1_px_diff,sell_l2_px_diff,sell_l3_px_diff,sell_l4_px_diff,sell_l5_px_diff,sell_l6_px_diff,sell_l7_px_diff,sell_l8_px_diff,sell_l9_px_diff,sell_l10_px_diff,"\
"buy_l1_shr_diff,buy_l2_shr_diff,buy_l3_shr_diff,buy_l4_shr_diff,buy_l5_shr_diff,buy_l6_shr_diff,buy_l7_shr_diff,buy_l8_shr_diff,buy_l9_shr_diff,buy_l10_shr_diff,"\
"sell_l1_shr_diff,sell_l2_shr_diff,sell_l3_shr_diff,sell_l4_shr_diff,sell_l5_shr_diff,sell_l6_shr_diff,sell_l7_shr_diff,sell_l8_shr_diff,sell_l9_shr_diff,sell_l10_shr_diff,"\
"buy_add_1s,buy_add_3s,buy_add_10s,buy_add_90s,sell_add_1s,sell_add_3s,sell_add_10s,sell_add_90s,"\
"buy_del_1s,buy_del_3s,buy_del_10s,buy_del_90s,sell_del_1s,sell_del_3s,sell_del_10s,sell_del_90s,"\
"buy_exec_ts_1s,buy_exec_ts_3s,buy_exec_ts_10s,buy_exec_ts_90s,sell_exec_ts_1s,sell_exec_ts_3s,sell_exec_ts_10s,sell_exec_ts_90s,"\
"buy_add_1s_prev,buy_add_1s_now,buy_add_3s_prev,buy_add_3s_now,sell_add_1s_prev,sell_add_1s_now,sell_add_3s_prev,sell_add_3s_now,"\
"buy_del_1s_prev,buy_del_1s_now,buy_del_3s_prev,buy_del_3s_now,sell_del_1s_prev,sell_del_1s_now,sell_del_3s_prev,sell_del_3s_now,"\
"buy_exec_1s_prev,buy_exec_1s_now,buy_exec_3s_prev,buy_exec_3s_now,sell_exec_1s_prev,sell_exec_1s_now,sell_exec_3s_prev,sell_exec_3s_now,"\
"buy_add_list_1s_prev,buy_add_list_1s_now,sell_add_list_1s_prev,sell_add_list_1s_now,buy_del_list_1s_prev,buy_del_list_1s_now,sell_del_list_1s_prev,sell_del_list_1s_now,buy_exec_list_1s_prev,buy_exec_list_1s_now,sell_exec_list_1s_prev,sell_exec_list_1s_now,"\
"e_buy_add_px_10s,buy_add_slope,e_sell_add_px_10s,sell_add_slope,ewavg_buy_add_qty_10s,ewavg_buy_add_cnt_10s,ewavg_sell_add_qty_10s,ewavg_sell_add_cnt_10s,"\
"e_buy_del_px_10s,buy_del_slope,e_sell_del_px_10s,sell_del_slope,ewavg_buy_del_qty_10s,ewavg_buy_del_cnt_10s,ewavg_sell_del_qty_10s,ewavg_sell_del_cnt_10s,"\
"e_buy_exec_px_30s,buy_exec_slope,e_sell_exec_px_30s,sell_exec_slope,ewavg_buy_exec_qty_30s,ewavg_buy_exec_cnt_30s,ewavg_sell_exec_qty_30s,ewavg_sell_exec_cnt_30s"


values = values.split(',')

header = header.split(',')

DD = {k:v for k, v in zip(header, values)}

DD['sell_exec_ts_1s']   sell_exec_1s
DD['sell_exec_ts_3s']   sell_exec_3s 
DD['sell_exec_ts_10s']  sell_exec_10s 
DD['sell_exec_ts_90s']  sell_exec_90s 

action_delay_nanoseconds = 75 



delay_nanoseconds = 1e3

int(75e3)

delay_nanoseconds

sell_exec_1s

sell_exec_1s_ts

        self.header = "buy_l1_px_diff,buy_l2_px_diff,buy_l3_px_diff,buy_l4_px_diff,buy_l5_px_diff,buy_l6_px_diff,buy_l7_px_diff,buy_l8_px_diff,buy_l9_px_diff,buy_l10_px_diff,"\
        "sell_l1_px_diff,sell_l2_px_diff,sell_l3_px_diff,sell_l4_px_diff,sell_l5_px_diff,sell_l6_px_diff,sell_l7_px_diff,sell_l8_px_diff,sell_l9_px_diff,sell_l10_px_diff,"\
        "buy_l1_shr_diff,buy_l2_shr_diff,buy_l3_shr_diff,buy_l4_shr_diff,buy_l5_shr_diff,buy_l6_shr_diff,buy_l7_shr_diff,buy_l8_shr_diff,buy_l9_shr_diff,buy_l10_shr_diff,"\
        "sell_l1_shr_diff,sell_l2_shr_diff,sell_l3_shr_diff,sell_l4_shr_diff,sell_l5_shr_diff,sell_l6_shr_diff,sell_l7_shr_diff,sell_l8_shr_diff,sell_l9_shr_diff,sell_l10_shr_diff,"\
        "buy_add_1s,buy_add_3s,buy_add_10s,buy_add_90s,sell_add_1s,sell_add_3s,sell_add_10s,sell_add_90s,"\
        "buy_del_1s,buy_del_3s,buy_del_10s,buy_del_90s,sell_del_1s,sell_del_3s,sell_del_10s,sell_del_90s,"\
        "buy_exec_ts_1s,buy_exec_ts_3s,buy_exec_ts_10s,buy_exec_ts_90s,sell_exec_ts_1s,sell_exec_ts_3s,sell_exec_ts_10s,sell_exec_ts_90s,"\
        "buy_add_1s_prev,buy_add_1s_now,buy_add_3s_prev,buy_add_3s_now,sell_add_1s_prev,sell_add_1s_now,sell_add_3s_prev,sell_add_3s_now,"\
        "buy_del_1s_prev,buy_del_1s_now,buy_del_3s_prev,buy_del_3s_now,sell_del_1s_prev,sell_del_1s_now,sell_del_3s_prev,sell_del_3s_now,"\
        "buy_exec_1s_prev,buy_exec_1s_now,buy_exec_3s_prev,buy_exec_3s_now,sell_exec_1s_prev,sell_exec_1s_now,sell_exec_3s_prev,sell_exec_3s_now,"\
        "buy_add_list_1s_prev,buy_add_list_1s_now,sell_add_list_1s_prev,sell_add_list_1s_now,buy_del_list_1s_prev,buy_del_list_1s_now,sell_del_list_1s_prev,sell_del_list_1s_now,buy_exec_list_1s_prev,buy_exec_list_1s_now,sell_exec_list_1s_prev,sell_exec_list_1s_now,"\
        "e_buy_add_px_10s,buy_add_slope,e_sell_add_px_10s,sell_add_slope,ewavg_buy_add_qty_10s,ewavg_buy_add_cnt_10s,ewavg_sell_add_qty_10s,ewavg_sell_add_cnt_10s,"\
        "e_buy_del_px_10s,buy_del_slope,e_sell_del_px_10s,sell_del_slope,ewavg_buy_del_qty_10s,ewavg_buy_del_cnt_10s,ewavg_sell_del_qty_10s,ewavg_sell_del_cnt_10s,"\
        "e_buy_exec_px_30s,buy_exec_slope,e_sell_exec_px_30s,sell_exec_slope,ewavg_buy_exec_qty_30s,ewavg_buy_exec_cnt_30s,ewavg_sell_exec_qty_30s,ewavg_sell_exec_cnt_30s"


