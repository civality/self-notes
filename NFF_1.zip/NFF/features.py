my_col = ["excess_ret_5m",'bp',

'buy_exec_10s_dec', #StrategyOrderBookdata
'w_eavg_qty_10s', #StrategyOrderBookData

'buy_add_3s', #@StrategyTimeSensitiveData
'buy_exec_ts_1s',# UNSET @StrategyTimeSensitiveData
'buy_exec_ts_90s', # UNSET @StrtegyTimeSensitiveData
'buy_del_10s', # buy_del_10s @StrtegyTimeSensitiveData
'buy_del_90s', #buy_del_90s @StrategyTimeSensitiveData
'sell_exec_10s', #StrategyTimeSensitiveData
'sell_exec_ts_1s', #StrategyTimeSensitiveData lost in header


'buy_add_sh_l1_10s_dec', # always zero @StrategyExecData
'buy_delete_sh_l2_3m_dec', # always zero @StrategyExecData
'buy_add_sh_l2_1m', # buy_add_sh_l2_1m @StrategyExecData
'buy_level_added_1m', # @StrategyExecData
'buy_level_removed_3m', # @StrategyExecData
'sell_add_cnt_l1_10s', # StrategyExecData 
'sell_add_cnt_l1_1m', # StrategyExecData 
'sell_add_sh_l1_1m', # StrategyExecData 
'sell_add_sh_l2_1m', # StrategyExecData 
'sell_delete_sh_l2_3m', # StrategyExecData 
'sell_level_removed_1m', #StrategyExecData
'snap_exec_qty', #StrategyExecData
'obv1_10', # @StrategyExecData  self.obv1_10
'dm_p1', # @StrategyExecData


'ind.ret.w.eavg.10m', # Complex df['ind.ret.w.eavg.10m']=(df['ind.mid'] - df['ind.w.eavg.px.10m']) / df['ind.w.eavg.px.10m'] @FeatureExtraction
'ind.ret.w.eavg.10s', # Complex df['ind.ret.w.eavg.10s']=(df['ind.mid']  - df['ind.w.eavg.px.10s'])  / df['ind.w.eavg.px.10s'] @FeatureExtraction
'ind.ret.w.eavg.3m', # Complex df['ind.ret.w.eavg.3m']=(df['ind.mid'] - df['ind.w.eavg.px.3m']) / df['ind.w.eavg.px.3m'] @FeatureExtraction
'mfm_1min',  # Complex  df['mfm_1min'] = ((df['mid'] - df['low_1m']) - (df['high_1m'] - df['mid'])) / (df['high_1m'] - df['low_1m'] + 0.000001)  * np.log(df['w_eavg_qty_1m']+1) * df['spr.bps']   @FeatureExtraction
'mfm_3min', # Complex df['mfm_3min'] = ((df['mid'] - df['low_3m']) - (df['high_3m'] - df['mid'])) / (df['high_3m'] - df['low_3m'] + 0.000001)  * np.log(df['w_eavg_qty_3m']+1) * df['spr.bps'] @FeatureExtraction
'mfm_day', #Complex mfm_day df['mfm_day'] = ((df['mid'] - df['low_day']) - (df['high_day'] - df['mid'])) / (df['high_day'] - df['low_day'] + 0.000001)  * np.log(df['day_qty']+1) * df['spr.bps']  @FeatureExtraction
'ret.eavg.10m.a', # @ FeatureExtraction df['ret.eavg.10m.a']=(df['mid'] - df['eavg.px.10m.a']) / df['eavg.px.10m.a']
'ret.w.eavg.30m', # @ Complex df['ret.w.eavg.30m']=(df['mid'] - df['w.eavg.px.30m']) / df['w.eavg.px.30m']  @FeatureExtraction
'dir_log_exec_qty',  #Complex df['dir_log_exec_qty'] = np.log(abs(df['snap_exec_qty']) + 1) * df['spr.bps'] * df['side'] @FeatureExtraction
'excess.ret.w.eavg.10s', # Complex df['excess.ret.w.eavg.10s'] = df['ret.w.eavg.10s'] - df['ind.ret.w.eavg.10s'] * df['beta'] @FeatureExtraction
'side_time', # df['side_time'] = df['side'] * (1/np.log(1+df['ord_life_last_exec']))  
'ret.eavg.10s.a', # df['ret.eavg.10s.a'] = (df['mid.adj']  - df['eavg.px.10s.a'])  / df['eavg.px.10s.a'] @FeatureExtraction
'dir_hi_lo_3m_bps' # df['dir_hi_lo_3m_bps']  = df['hi_lo_3m_bps'] * df['side'] @FeatureExtraction

]