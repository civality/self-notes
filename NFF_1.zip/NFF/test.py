import util
import pandas as pd 
import numpy as np
import os
import sys
import intraday_price.get_intraday_price as ip
from decimal import Decimal
from quantlib import database_functions as db
from quantlib.database_functions.constants import columns as cols
from util import * 
from quantlib import utilities as ut
from ssh_connector import get_remote_file
from data_types import HiLow
import market_player
import model_config
import random 

min(10 // 3, 2)

pd.read_csv('/mnt/data/exec_snap/Bist_Equity/2021/02/19/exec_snap-200000delay/Bist_Equity.20210219.77796.exec_snap.200000delay.csv.gz').shape

start_date = '20210129'
end_date =   '20210302'

df_path_table = pd.read_csv('_path-table.csv')
df_path_table['date'] = df_path_table['date'].astype(str)
df_path_table = df_path_table[df_path_table['kind'] == 'exec-snap']
df_path_table = df_path_table[(df_path_table['date'] > start_date) & (df_path_table['date'] < end_date)]

list_problematic_player = []

the_list = []
for date in df_path_table['date'].unique():
    for order_book_id in df_path_table['order_book_id'].unique():
        for is_transformer_enabled in [True, False]:

            sink_dir = f'data/transformer={is_transformer_enabled}'
            path_directions = f'{sink_dir}/directions-{date}-{order_book_id}.csv'
            path_quant_action_results = f'{sink_dir}/quant-action-results-{date}-{order_book_id}.csv'

            print(path_directions)
            print(path_quant_action_results)

            df = pd.read_csv(path_directions)
            
            the_list.append(
                {
                    'date': date,
                    'order_book_id': order_book_id,
                    'B': df['side'].value_counts()['B'],
                    'S': df['side'].value_counts()['S']
                }
            )
            
xdf = pd.DataFrame(the_list)

(xdf['B'] / xdf['S']).describe()

xdf
df['side'].value_counts()['B']

timestamp,side,price,shares
1612335615600479348,B,10.94,794
1612335620275907819,B,10.94,696
1612335641104808663,B,10.95,1028





















a_list = [0, 1]
distribution = [.5, .5]
random_number = random.choice([0,1])
random_number

total = 0 
N = 1000
for i in range(N):
    total += random.choice([0,1])

print(total, N)



























pd.read_csv('/home/csahin/repos/strategy_sim_repo/trunk/data/transformer=False/quant-action-results-20210201-70796.csv')

result = pd.read_csv('/mnt/data/exec_snap/Bist_Equity/2021/02/19/exec_snap-200000delay/Bist_Equity.20210219.77796.exec_snap.200000delay.csv.gz')
result

result['side'].value_counts()

result = pd.read_csv('data/transformer=False/quant-action-results-20210201-75936.csv')

result.groupby('side')['shares'].count()


result.groupby('side')['shares'].mean()


result


date = '20210201'
# order_book_id = 74156 70796

order_book_id = 74736

#config = model_config.ModelConfig(date, order_book_id, is_train_enabled=True, is_transformer_enabled=True)
 
player = market_player.MarketPlayer(date, order_book_id, is_transformer_enabled=True)
 
df3 = pd.read_csv('/mnt/data/exec_snap/Bist_Equity/2021/01/27/exec_snap-200000delay/Bist_Equity.20210127.78436.exec_snap.200000delay.csv.gz')
df3

import pandas as pd
df = pd.read_json('sim_results.jsonl', lines=True)
df.to_csv('sim_results.csv', index=False)


print('With transformer')
df1 = df.loc[df['is_transformer_enabled']]
df1['profit'].sum()
df1.groupby('order_book_id')['profit'].describe()
df1.groupby('date')['profit'].describe()

print('Without transformer')
df2 = df.loc[~df['is_transformer_enabled']]
df2['profit'].sum()
df2.groupby('order_book_id')['profit'].describe()
df2.groupby('date')['profit'].describe()

df['date'].nunique()
df['order_book_id'].nunique()


df.loc[df['is_transformer_enabled'], 'profit'].min()
df.loc[~df['is_transformer_enabled'], 'profit'].min()

df.loc[df['is_transformer_enabled'], 'profit'].std()
df.loc[~df['is_transformer_enabled'], 'profit'].std()

df['date'].nunique()
df['order_book_id'].nunique()

df.to_csv('sim_results.csv', index=False)


x = 13.1
y = 13.5

(y-x) / ((y+x) / 2)

