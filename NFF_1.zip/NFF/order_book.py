from order_book_level import OrderBookLevel

nanos_in_sec = 1e9

class OrderBook:

    def __init__(self):
        
        self.buy_side = []
        self.sell_side = []
        self.is_top_level_changed = False

        self.entry_time_last_exec = 0 #tbd

    def on_add(self, add):
         
        insert_level = 0
        self.is_top_level_changed = False # This can be more granular in future, like is_top_level_price_changed, is_top_level_shares_changed

        if add.side == 'B':
            
            if not self.buy_side:
                self.buy_side = [OrderBookLevel(add)]
                return

            for level in self.buy_side:
                if add.price == level.price:
                    level.append(add)
                    self.may_reinsert_order_for_replace(insert_level, add)

                    if insert_level == 0:
                        self.is_top_level_changed = True

                    return
                elif add.price > level.price:
                    self.buy_side.insert(insert_level, OrderBookLevel(add))

                    if insert_level == 0:
                        self.is_top_level_changed = True

                    return
                else:
                    insert_level += 1

            self.buy_side.insert(insert_level, OrderBookLevel(add))

        if add.side == 'S':

            if not self.sell_side:
                self.sell_side = [OrderBookLevel(add)]
                return

            for level in self.sell_side:
                if add.price == level.price:
                    level.append(add)
                    self.may_reinsert_order_for_replace(insert_level, add)

                    if insert_level == 0:
                        self.is_top_level_changed = True

                    return
                elif add.price < level.price:
                    self.sell_side.insert(insert_level, OrderBookLevel(add))

                    if insert_level == 0:
                        self.is_top_level_changed = True

                    return
                else:
                    insert_level += 1

            self.sell_side.insert(insert_level, OrderBookLevel(add))

    def may_reinsert_order_for_replace(self, insert_level, order):

        position = 0
        level_index = insert_level + 1
        levels = self.buy_side if order.side == 'B' else self.sell_side
        for level in levels[0:level_index]:
            position += len(level.orders)
        if order.order_book_position != position:
            self.reinsert_order_for_replace(order, position, insert_level, levels)

    def reinsert_order_for_replace(self, order, position, insert_level, levels):
        
        order_count_ahead_of_level = position - len(levels[insert_level].orders)
        new_insert_position_at_level = order.order_book_position - order_count_ahead_of_level - 1 
        levels[insert_level].orders.pop()
        levels[insert_level].orders.insert(new_insert_position_at_level, order)


    def on_delete(self, delete):
        remove_level = 0
        self.is_top_level_changed = False # This can be more granular in future, like is_top_level_price_changed, is_top_level_shares_changed

        levels = self.buy_side if delete.side == 'B' else self.sell_side

        for level in levels:
            for order in level.orders:
                if order.order_id == delete.order_id:
                    delete.shares = order.shares
                    delete.price = order.price
                    level.orders.remove(order)
                    if not level.orders:
                        levels.pop(remove_level)
                    else:
                        level.adjust_size(delete.shares, 1)

                    if remove_level == 0: # popping the top level case might be extricated in future
                        self.is_top_level_changed = True
                    
                    return
            remove_level += 1

        raise Exception(f'Deleted order cannot be located in the order book, deleted order id  {delete.order_id} and order_book_id id is {delete.order_book_id}')

    def on_execute(self, execute):

        self.is_top_level_changed = False # This can be more granular in future, like is_top_level_price_changed, is_top_level_shares_changed

        levels = self.buy_side if execute.side == 'B' else self.sell_side 
        top_level = levels[0]
        execute.price = top_level.price

        if execute.order_id != top_level.orders[0].order_id or execute.shares > top_level.orders[0].shares: #and not self.last_exec?
            raise Exception()
        
        self.entry_time_last_exec = top_level.orders[0].nanos_from_epoch # you can remove this if you can correctly handle it in sim_data
    
        if execute.shares == top_level.orders[0].shares:
            top_level.orders.pop(0)
            
            if not top_level.orders:
                levels.pop(0)
            else:
                top_level.adjust_size(execute.shares, 1)

        else:
            top_level.orders[0].shares -= execute.shares
            top_level.adjust_size(execute.shares, 0)

        self.is_top_level_changed = True

    def print_order_book(self, until):

        self.print_side('B', self.buy_side, until) 
        self.print_side('S', self.sell_side, until) 

    def print_side(self, side, levels, until):
        
        for i, level in enumerate(levels):
            if i>until:
                break
            print(f'\n {side} level {i} ({level.price}) ({level.number_of_orders})')
            print('\t', end='')
            for order in level.orders:
                order_id = order.to_dict()['order_id'] % int(1e9)
                order_book_position = order.to_dict()['order_book_position'] 
                price = order.to_dict()['price']
                shares = order.to_dict()['shares']
                
                print(f"({order_id}, {order_book_position}, {price}, {shares})", end=' ')
