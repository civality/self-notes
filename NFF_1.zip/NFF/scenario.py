yest_close = 1

reset
    high_1m = 1
    cur_hi_lo = (1,1)

    hi_lo_1m = [(1,1)]
    hi_lo_3m = [(1,1), (1,1), (1,1)]

(------
E.price = 5
    cur_hi_lo = (5,5)
    high_1m = 5
    high_3m = 5

E.price = 6
    cur_hi_lo = (6,5)
    high_1m = 6
    high_1m = 6
------)

(------
E.price = 5
    cur_hi_lo = (5,5)
    high_1m = 5
    high_3m = 5

T
    hi_lo_1m = [(1,1)]
    hi_lo_3m = [(1,1), (1,1), (1,1)]

------)