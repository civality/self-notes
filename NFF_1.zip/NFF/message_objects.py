from typing import Union, Optional
from pandas import Timestamp

class Add:

    # constructor
    def __init__(self, list_msg):
    
        assert 'A' == list_msg[0]
        self.msg_type = list_msg[0]
        self.date_str = list_msg[1]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.order_id = int(list_msg[2])
        self.symbol_id = list_msg[3]
        self.side = list_msg[4]
        self.order_book_position = int(list_msg[5])
        self.shares = int(list_msg[6])
        self.price = float(list_msg[7])/1000
        
    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'date_str': self.date_str,
            'nanos_from_epoch': self.nanos_from_epoch,
            'order_id': self.order_id,
            'symbol_id': self.symbol_id,
            'side': self.side,
            'order_book_position': self.order_book_position,
            'shares': self.shares,
            'price': self.price
        }
    
class Delete:

    # constructor
    def __init__(self, list_msg):
        
        assert 'D' == list_msg[0]
        self.msg_type = list_msg[0]
        self.date_str = list_msg[1]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.order_id = int(list_msg[2])
        self.symbol_id = list_msg[3]
        self.side = list_msg[4].strip('\n')
        self.shares = 0 # lazy init hack
        self.price = 0 # lazy init hack

    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'date_str': self.date_str,
            'nanos_from_epoch': self.nanos_from_epoch,
            'order_id': self.order_id,
            'symbol_id': self.symbol_id,
            'side': self.side,
            'shares': self.shares,
            'price': self.price
        }
    
class Execute:
    """
    Order Executed Message
    This message is sent whenever an order on the book is executed in whole or in part.
    If the incoming order causing the match cannot be fully filled, the remainder will be placed in the book after 
    the match has occurred.
    It is possible to receive several Order Executed Messages for the same order if that order is executed in 
    several parts. Multiple Order Executed Messages on the same order are cumulative
    """
    # constructor
    def __init__(self, list_msg):
    
        assert 'E' == list_msg[0]
        self.msg_type = list_msg[0]
        self.date_str = list_msg[1]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.order_id = int(list_msg[2])
        self.symbol_id = list_msg[3]
        self.side = list_msg[4]
        self.shares = int(list_msg[5])
        self.match_id = list_msg[6]
        self.price = 0 # populated in update_order_book_execution_message


    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'date_str': self.date_str,
            'nanos_from_epoch': self.nanos_from_epoch,
            'order_id': self.order_id,
            'symbol_id': self.symbol_id,
            'side': self.side,
            'shares': self.shares,
            'match_id': self.match_id,
            'price': self.price,
        }


class Seconds:

    # constructor
    def __init__(self, list_msg):
    
        assert 'T' == list_msg[0]
        self.msg_type = list_msg[0]
        self.seconds_from_epoch = int(list_msg[1])
        self.nanos_from_epoch = self.seconds_from_epoch * int(1e9)

    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'seconds_from_epoch': self.seconds_from_epoch,
            'nanos_from_epoch': self.nanos_from_epoch,
        }

class Trade:

    # constructor
    def __init__(self, list_msg):
    
        assert 'P' == list_msg[0]
        self.msg_type = list_msg[0]
        self.date_str = list_msg[1]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.match_id = int(list_msg[2])
        self.combo_group_id = list_msg[3]
        self.side = list_msg[4]
        self.shares = int(list_msg[5])
        self.order_book_id = int(list_msg[6])
        self.trade_price = float(list_msg[7])/1000
        self.printable = list_msg[10]
        self.occurred_at_cross = list_msg[11]
        
    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'date_str': self.date_str,
            'nanos_from_epoch': self.nanos_from_epoch,
            'match_id': self.match_id,
            'combo_group_id': self.combo_group_id,
            'side': self.side,
            'shares': self.shares,
            'order_book_id': self.order_book_id,
            'trade_price': self.trade_price,
            'printable': self.printable,
            'occurred_at_cross': self.occurred_at_cross
        }


class State:

    # constructor
    def __init__(self, list_msg):
    
        assert 'O' == list_msg[0]
        self.msg_type = list_msg[0]
        self.date_str = list_msg[1]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.symbol_id = list_msg[2]
        self.state_name = list_msg[3].strip('\n')
        
    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'date_str': self.date_str,
            'nanos_from_epoch': self.nanos_from_epoch,
            'symbol_id': self.symbol_id,
            'state_name': self.state_name
        }
    
class Equilibrium:

    # constructor
    def __init__(self, list_msg):
        
        assert 'Z' == list_msg[0]
        self.msg_type = list_msg[0]
        self.date_str = list_msg[1]
        self.nanos_from_epoch = list_msg[1][30:49]
        self.order_book__id = int(list_msg[2])
        self.avail_bid_qty_at_equil_price = list_msg[3]
        self.avail_ask_qty_at_equil_price = list_msg[4]
        self.equil_price = float(list_msg[5])/1000
        self.best_bid_price = float(list_msg[6])/1000
        self.best_ask_price = float(list_msg[7])/1000
        self.best_bid_qty = list_msg[8]
        self.best_ask_qty = list_msg[9]

    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'date_str': self.date_str,
            'nanos_from_epoch': self.nanos_from_epoch,
            'order_book__id': self.order_book__id,
            'avail_bid_qty_at_equil_price': self.avail_bid_qty_at_equil_price,
            'avail_ask_qty_at_equil_price': self.avail_ask_qty_at_equil_price,
            'equil_price': self.equil_price,
            'best_bid_price': self.best_bid_price,
            'best_ask_price': self.best_ask_price,
            'best_bid_qty': self.best_bid_qty,
            'best_ask_qty': self.best_ask_qty,
        }
    
class System:
    
    # constructor
    def __init__(self, list_msg):
    
        assert 'S' == list_msg[0]
        self.msg_type = list_msg[0]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.date_str = list_msg[1]
        self.event_code = list_msg[2]
        
    def to_dict(self):
        return {
            'msg_type': self.msg_type,
            'nanos_from_epoch': self.nanos_from_epoch,
            'date_str': self.date_str,
            'event_code': self.event_code,
        }

class TickSize:
    
    # constructor
    def __init__(self, list_msg):
    
        assert 'L' == list_msg[0]
        self.msg_type = list_msg[0]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.date_str = list_msg[1]
        self.order_book_id = list_msg[2]
        self.tick_size = int(list_msg[3])
        self.price_from = int(list_msg[4])
        self.price_to = int(list_msg[5])
            
    def to_dict(self):
        
        return {
            'msg_type': self.msg_type,
            'nanos_from_epoch': self.nanos_from_epoch,
            'date_str': self.date_str,
            'order_book_id': self.order_book_id,
            'tick_size': self.tick_size,
            'price_from': self.price_from,
            'price_to': self.price_to
        }

class Reference:
    
    # constructor
    def __init__(self, list_msg):
    
        assert 'R' == list_msg[0]
        self.msg_type = list_msg[0]
        self.nanos_from_epoch = int(list_msg[1][30:49])
        self.date_str = list_msg[1]
        self.order_book_id = list_msg[2]
        self.symbol = list_msg[3]
        self.long_name = list_msg[4]
        self.ISIN = list_msg[5]
        self.financial_product = list_msg[6]
        self.trading_currency = list_msg[7]
        self.n_decimals_in_price = list_msg[8]
        self.n_decimals_in_nominal_value = list_msg[9]
        self.odd_lot_size = list_msg[10]
        self.round_lot_size = list_msg[11]
        self.block_lot_size = list_msg[12]
        self.nominal_value = list_msg[13]
        self.n_legs = list_msg[14]
        self.underlying_order_book_id = list_msg[15]
        self.strike_price = list_msg[16]
        self.expiration_date = list_msg[17]
        self.n_decimals_in_strike_price = list_msg[18]
        self.put_or_call = list_msg[19]
                    
    def to_dict(self):
        
        return {
            'msg_type': self.msg_type,
            'nanos_from_epoch': self.nanos_from_epoch,
            'date_str': self.date_str,
            'order_book_id': self.order_book_id,
            'symbol': self.symbol,
            'long_name': self.long_name,
            'ISIN': self.ISIN,
            'financial_product': self.financial_product,
            'trading_currency': self.trading_currency,
            'n_decimals_in_price': self.n_decimals_in_price,
            'n_decimals_in_nominal_value': self.n_decimals_in_nominal_value,
            'odd_lot_size': self.odd_lot_size,
            'round_lot_size': self.round_lot_size,
            'block_lot_size': self.block_lot_size,
            'nominal_value': self.nominal_value,
            'n_legs': self.n_legs,
            'underlying_order_book_id': self.underlying_order_book_id,
            'strike_price': self.strike_price,
            'expiration_date': self.expiration_date,
            'n_decimals_in_strike_price': self.n_decimals_in_strike_price,
            'put_or_call': self.put_or_call
         }


def get_message_object(line: str) -> Union[Add, Delete, Execute, Trade, State, Seconds]:
    
    M = line.split(',')
    msg_type = M[0]

    if msg_type == 'A':
        obj = Add(M)
    elif msg_type == 'D':
        obj = Delete(M)
    elif msg_type == 'E':
        obj = Execute(M)
    elif msg_type == 'T':
        obj = Seconds(M)
    elif msg_type == 'P':
        obj = Trade(M)
    elif msg_type == 'O':
        obj = State(M)
    elif msg_type == 'Z':
        obj = Equilibrium(M)
    elif msg_type == 'S':
        obj = System(M)
    elif msg_type == 'L':
        obj = TickSize(M)
    elif msg_type == 'R':
        obj = Reference(M)
    else:
        obj = None
        
    return obj 


def create_object_add(nanos_from_epoch: int, side: str, price: float, shares: int):

    date_part = Timestamp(nanos_from_epoch).strftime('%Y-%m-%dT%H:%M:%S')
    nanos_part = str(nanos_from_epoch)[-9:]

    msg_type = 'A'
    date_str = f'{date_part}.{nanos_part}({nanos_from_epoch})'
    order_id = '999'
    order_book_id = '74836'
    side = side
    order_book_position = '1'
    shares = shares
    price=price * 1000 #since the source of price variable is some Add.price we must re-scale it

    M = f'{msg_type},{date_str},{order_id},{order_book_id},{side},{order_book_position},{shares},{price}'
    print('@ create_object_add', M)
    M = M.split(',')

    return Add(M)
